from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from src.backend.service import KnowledgeBaseService


def test_config(root: Path) -> dict:
    return {
        "backend": "ollama",
        "ollama": {"base_url": "http://localhost:11434", "model": "qwen2.5:7b-instruct"},
        "feature_flags": {
            "ENABLE_DENSE_RETRIEVAL": False,
            "ENABLE_HYBRID_RETRIEVAL": False,
            "ENABLE_RERANKER": True,
            "ENABLE_AGENTIC": False,
            "ENABLE_GRAPH_LAYER": False,
        },
        "storage": {
            "raw_dir": str(root / "raw"),
            "processed_dir": str(root / "processed"),
            "chunk_dir": str(root / "chunks"),
            "wiki_dir": str(root / "wiki"),
            "chunk_db": str(root / "chunks.db"),
        },
        "retrieval": {"top_k": 10, "dense_embedding_dim": 32, "rerank_top_n": 10, "min_score": 0.0},
        "ingestion": {"min_chunk_tokens": 1, "max_chunk_tokens": 80, "enable_wiki_stub": True},
    }


class KnowledgeTreeTests(unittest.TestCase):
    def test_tree_groups_chunks_by_document_and_type(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            service = KnowledgeBaseService(test_config(root))
            service.ingest_documents(
                [
                    {
                        "name": "bearing_case.md",
                        "content": "Symptom: startup vibration. Cause: bearing damage. Action: inspect the bearing.",
                    },
                    {
                        "name": "pump_rule.md",
                        "content": "Rule: if pressure drops under stable load, check pump inlet blockage.",
                    },
                ]
            )

            tree = service.get_knowledge_tree()
            documents = {child["name"]: child for child in tree["children"]}

            self.assertEqual(tree["document_count"], 2)
            self.assertIn("bearing_case.md", documents)
            self.assertGreater(documents["bearing_case.md"]["chunk_count"], 0)
            self.assertTrue(documents["bearing_case.md"]["children"])


if __name__ == "__main__":
    unittest.main()
