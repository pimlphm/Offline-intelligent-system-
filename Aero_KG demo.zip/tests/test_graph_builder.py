from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from knowledge.graph.graph_builder import GraphBuilder


class GraphBuilderTests(unittest.TestCase):
    def test_graph_builder_writes_graphml(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            chunk_dir = root / "chunks"
            chunk_dir.mkdir()
            graph_path = root / "graph.graphml"

            payload = {
                "chunk_id": "C_0001",
                "chunk_type": "symptom",
                "text": "bearing vibration after startup",
                "entities": ["bearing"],
                "conditions": ["after startup"],
                "relations": [{"type": "causes", "confidence": 0.7}],
                "source": "demo.md",
                "metadata": {"doc_name": "demo.md"},
            }
            (chunk_dir / "C_0001.json").write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

            result = GraphBuilder(chunk_dir, graph_path).build()
            self.assertTrue(graph_path.exists())
            self.assertGreater(result["nodes"], 0)


if __name__ == "__main__":
    unittest.main()
