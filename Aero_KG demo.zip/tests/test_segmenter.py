from __future__ import annotations

import unittest

from knowledge.ingestion.segmenter import segment_parsed_document


class SegmenterTests(unittest.TestCase):
    def test_segmenter_emits_typed_chunks(self) -> None:
        parsed = {
            "name": "diagnostic_note.md",
            "content": (
                "Symptom: high-frequency vibration after startup for 10 min.\n\n"
                "Cause: bearing lubrication loss causes temperature rise.\n\n"
                "Action: inspect the bearing and replace degraded grease.\n"
            ),
        }
        chunks = segment_parsed_document(parsed, {"ingestion": {"min_chunk_tokens": 1, "max_chunk_tokens": 80}})
        types = {chunk["chunk_type"] for chunk in chunks}
        self.assertIn("symptom", types)
        self.assertIn("cause", types)
        self.assertIn("action", types)


if __name__ == "__main__":
    unittest.main()
