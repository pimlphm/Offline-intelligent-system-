from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from orchestration.program_manager import ProgramManager


class ProgramManagerTests(unittest.TestCase):
    def test_render_phase_packet_contains_required_sections(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            manager = ProgramManager(tmp)
            packet = manager.render_phase_packet(0)
            self.assertIn("<Phase 0>", packet)
            self.assertIn("Assignments:", packet)
            self.assertIn("Deliverables:", packet)
            self.assertIn("AcceptanceCriteria:", packet)
            self.assertIn("Decision: REWAIT", packet)

    def test_record_instruction_and_result_write_log(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "as_is_system_audit.md").write_text("audit", encoding="utf-8")
            (root / "inventory.json").write_text("{}", encoding="utf-8")

            manager = ProgramManager(root)
            manager.record_instruction(0, note="phase0")
            manager.record_result(0, "PROCEED", artifacts=["as_is_system_audit.md"])

            payload = json.loads((root / "orchestrator_log.json").read_text(encoding="utf-8"))
            self.assertEqual(len(payload["records"]), 2)
            self.assertEqual(payload["records"][0]["record_type"], "instruction")
            self.assertEqual(payload["records"][1]["decision"], "PROCEED")
            self.assertTrue(payload["records"][1]["gate_check"]["passed"])


if __name__ == "__main__":
    unittest.main()
