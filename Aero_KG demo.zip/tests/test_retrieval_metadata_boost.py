from __future__ import annotations

import unittest

from src.retrieval.hybrid import HybridRetriever


class RetrievalMetadataBoostTests(unittest.TestCase):
    def test_document_title_terms_can_drive_retrieval(self) -> None:
        chunks = [
            {
                "chunk_id": "C_engine",
                "chunk_type": "evidence",
                "text": "This document describes control loops, certification context, and software behavior.",
                "source": "A320neo_Engine_Control_Software_Spec.md#1",
                "metadata": {"doc_name": "A320neo_Engine_Control_Software_Spec.md"},
                "entities": ["A320neo", "engine control"],
                "conditions": [],
            },
            {
                "chunk_id": "C_fbw",
                "chunk_type": "evidence",
                "text": "This document describes control loops, certification context, and software behavior.",
                "source": "A320neo_FBW_DO178C_Certification.md#1",
                "metadata": {"doc_name": "A320neo_FBW_DO178C_Certification.md"},
                "entities": ["A320neo", "fly by wire"],
                "conditions": [],
            },
        ]
        retriever = HybridRetriever(dense_enabled=False, reranker_enabled=True, dense_weight=0.0, sparse_weight=1.0)
        retriever.build(chunks)

        results = retriever.search("Which source should answer about engine control software specification?", top_k=1)

        self.assertEqual(results[0]["doc_name"], "A320neo_Engine_Control_Software_Spec.md")


if __name__ == "__main__":
    unittest.main()
