from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from src.backend.service import KnowledgeBaseService


class ServiceBootstrapTests(unittest.TestCase):
    def test_service_ingest_and_retrieve(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = {
                "backend": "ollama",
                "ollama": {"base_url": "http://localhost:11434", "model": "qwen2.5:7b-instruct"},
                "feature_flags": {
                    "ENABLE_DENSE_RETRIEVAL": False,
                    "ENABLE_HYBRID_RETRIEVAL": False,
                    "ENABLE_RERANKER": False,
                    "ENABLE_AGENTIC": False,
                    "ENABLE_GRAPH_LAYER": False,
                },
                "storage": {
                    "raw_dir": str(root / "raw"),
                    "processed_dir": str(root / "processed"),
                    "chunk_dir": str(root / "chunks"),
                    "wiki_dir": str(root / "wiki"),
                    "chunk_db": str(root / "chunks.db"),
                },
                "retrieval": {"top_k": 5, "dense_embedding_dim": 32, "rerank_top_n": 5, "min_score": 0.0},
                "ingestion": {"min_chunk_tokens": 1, "max_chunk_tokens": 80, "enable_wiki_stub": True},
            }

            service = KnowledgeBaseService(config)
            service.ingest_documents(
                [
                    {
                        "name": "bearing_case.md",
                        "content": "Symptom: startup vibration. Cause: bearing damage. Action: inspect the bearing.",
                    }
                ]
            )
            result = service.generate("What document mentions bearing damage?")
            self.assertGreater(len(result["retrieval_results"]), 0)
            self.assertIn("bearing_case.md", result["answer"])


if __name__ == "__main__":
    unittest.main()
