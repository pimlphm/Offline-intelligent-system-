from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from pipelines.run_current import run_current_pipeline


class RunCurrentPipelineTests(unittest.TestCase):
    def test_run_current_pipeline_indexes_docs_and_writes_report(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            doc1 = root / "bearing.md"
            doc2 = root / "control.md"
            report_path = root / "report.json"

            doc1.write_text(
                "# Bearing diagnostic note\n"
                "High-frequency vibration after startup often indicates lubrication loss.\n",
                encoding="utf-8",
            )
            doc2.write_text(
                "# Control note\n"
                "Flight control logic for the wing actuator is documented here.\n",
                encoding="utf-8",
            )

            result = run_current_pipeline(
                query="Which document mentions startup vibration?",
                document_paths=[doc1, doc2],
                output_path=report_path,
                use_llm=False,
            )

            self.assertEqual(result["status"], "ok")
            self.assertEqual(result["indexed_doc_count"], 2)
            self.assertGreater(len(result["retrieval_results"]), 0)
            self.assertTrue(report_path.exists())

            payload = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["indexed_doc_count"], 2)


if __name__ == "__main__":
    unittest.main()
