from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from src.agentic.agentic_retrieval import AgenticRetrievalEngine
from src.backend.service import KnowledgeBaseService


class AgenticStubTests(unittest.TestCase):
    def test_agentic_engine_runs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = {
                "backend": "ollama",
                "ollama": {"base_url": "http://localhost:11434", "model": "qwen2.5:7b-instruct"},
                "feature_flags": {
                    "ENABLE_DENSE_RETRIEVAL": False,
                    "ENABLE_HYBRID_RETRIEVAL": False,
                    "ENABLE_RERANKER": False,
                    "ENABLE_AGENTIC": False,
                    "ENABLE_GRAPH_LAYER": False,
                },
                "storage": {
                    "raw_dir": str(root / "raw"),
                    "processed_dir": str(root / "processed"),
                    "chunk_dir": str(root / "chunks"),
                    "wiki_dir": str(root / "wiki"),
                    "chunk_db": str(root / "chunks.db"),
                },
                "retrieval": {"top_k": 5, "dense_embedding_dim": 32, "rerank_top_n": 5, "min_score": 0.0},
                "ingestion": {"min_chunk_tokens": 1, "max_chunk_tokens": 80, "enable_wiki_stub": True},
            }

            service = KnowledgeBaseService(config)
            service.ingest_documents(
                [{"name": "case.md", "content": "Symptom: alarm. Cause: sensor drift. Action: inspect the sensor."}]
            )
            engine = AgenticRetrievalEngine(service)
            result = engine.run("Why is there an alarm in the sensor path?")
            self.assertTrue(result["steps"])
            self.assertIn("case.md", result["answer"])

    def test_service_uses_agentic_only_for_complex_queries(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = {
                "backend": "ollama",
                "ollama": {"base_url": "http://localhost:11434", "model": "qwen2.5:7b-instruct"},
                "feature_flags": {
                    "ENABLE_DENSE_RETRIEVAL": False,
                    "ENABLE_HYBRID_RETRIEVAL": False,
                    "ENABLE_RERANKER": True,
                    "ENABLE_AGENTIC": True,
                    "ENABLE_GRAPH_LAYER": False,
                },
                "storage": {
                    "raw_dir": str(root / "raw"),
                    "processed_dir": str(root / "processed"),
                    "chunk_dir": str(root / "chunks"),
                    "wiki_dir": str(root / "wiki"),
                    "chunk_db": str(root / "chunks.db"),
                },
                "retrieval": {"top_k": 5, "dense_embedding_dim": 32, "rerank_top_n": 5, "min_score": 0.0},
                "ingestion": {"min_chunk_tokens": 1, "max_chunk_tokens": 80, "enable_wiki_stub": True},
            }

            service = KnowledgeBaseService(config)
            service.ingest_documents(
                [
                    {"name": "case_a.md", "content": "Cause: sensor drift. Action: inspect the sensor."},
                    {"name": "case_b.md", "content": "Cause: wiring issue. Action: inspect the harness."},
                ]
            )

            simple = service.generate("What mentions sensor drift?")
            complex_result = service.generate("Compare sensor drift evidence versus wiring issue evidence.")

            self.assertFalse(simple["agentic_used"])
            self.assertTrue(complex_result["agentic_used"])
            self.assertTrue(complex_result["steps"])


if __name__ == "__main__":
    unittest.main()
