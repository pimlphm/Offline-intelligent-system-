#!/bin/bash
# ============================================================
#  航空知识库 Agent - 昇腾910B vLLM 部署脚本
#
#  在昇腾910B服务器上运行此脚本来启动LLM推理服务。
#  客户端(GUI)可以在任意机器上连接到此服务。
#
#  前置要求:
#    - 昇腾910B服务器已安装CANN 8.0+驱动
#    - Docker已安装
#    - NPU设备可用 (npu-smi info 可查看)
#
#  使用方法:
#    chmod +x deploy_ascend.sh
#    ./deploy_ascend.sh start             # 启动服务
#    ./deploy_ascend.sh stop              # 停止服务
#    ./deploy_ascend.sh status            # 查看状态
#    ./deploy_ascend.sh logs              # 查看日志
#    ./deploy_ascend.sh test              # 测试连接
# ============================================================

set -e

# ---- 配置区域 (按需修改) ----
CONTAINER_NAME="aviation-kb-vllm"
DOCKER_IMAGE="quay.io/ascend/vllm-ascend:v0.13.0"
MODEL_NAME="Qwen/Qwen2.5-7B-Instruct"
MODEL_CACHE="${HOME}/.cache/huggingface"
PORT=8000
NPU_DEVICE="0"                    # 单卡: "0", 多卡: "0,1,2,3"
TENSOR_PARALLEL=1                  # 张量并行数, 等于NPU卡数
MAX_MODEL_LEN=8192                 # 最大上下文长度
GPU_MEMORY_UTILIZATION=0.9         # NPU显存利用率
DTYPE="auto"                       # auto / float16 / bfloat16

# ---- 函数 ----

check_environment() {
    echo "[检查] 昇腾环境..."

    if ! command -v docker &> /dev/null; then
        echo "[错误] Docker未安装"
        exit 1
    fi

    if command -v npu-smi &> /dev/null; then
        echo "[OK] NPU设备:"
        npu-smi info -l
    else
        echo "[警告] npu-smi 不可用，尝试检查设备节点..."
        if ls /dev/davinci* &> /dev/null 2>&1; then
            echo "[OK] 找到NPU设备节点: $(ls /dev/davinci* 2>/dev/null)"
        else
            echo "[错误] 未找到NPU设备"
            exit 1
        fi
    fi
    echo ""
}

build_device_args() {
    # 根据NPU_DEVICE构建docker设备挂载参数
    local args=""
    IFS=',' read -ra DEVICES <<< "$NPU_DEVICE"
    for dev in "${DEVICES[@]}"; do
        args="$args --device /dev/davinci${dev}"
    done
    args="$args --device /dev/davinci_manager"
    args="$args --device /dev/devmm_svm"
    args="$args --device /dev/hisi_hdc"
    echo "$args"
}

start_service() {
    echo "============================================"
    echo "  昇腾910B vLLM 推理服务启动"
    echo "============================================"
    echo "  模型: $MODEL_NAME"
    echo "  NPU卡: $NPU_DEVICE"
    echo "  张量并行: $TENSOR_PARALLEL"
    echo "  端口: $PORT"
    echo "  最大上下文: $MAX_MODEL_LEN"
    echo "============================================"
    echo ""

    check_environment

    # 停掉旧容器
    if docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
        echo "[清理] 停止旧容器..."
        docker stop "$CONTAINER_NAME" 2>/dev/null || true
        docker rm "$CONTAINER_NAME" 2>/dev/null || true
    fi

    DEVICE_ARGS=$(build_device_args)

    echo "[启动] 拉取镜像 (首次较慢)..."
    docker pull "$DOCKER_IMAGE" 2>/dev/null || echo "[提示] 镜像已缓存"

    echo "[启动] 启动vLLM服务容器..."
    docker run -d \
        --name "$CONTAINER_NAME" \
        $DEVICE_ARGS \
        -v /usr/local/dcmi:/usr/local/dcmi \
        -v /usr/local/bin/npu-smi:/usr/local/bin/npu-smi \
        -v /usr/local/Ascend/driver/lib64/:/usr/local/Ascend/driver/lib64/ \
        -v /usr/local/Ascend/driver/version.info:/usr/local/Ascend/driver/version.info \
        -v /etc/ascend_install.info:/etc/ascend_install.info \
        -v "${MODEL_CACHE}:/root/.cache/huggingface" \
        -p "${PORT}:8000" \
        --ipc=host \
        --restart unless-stopped \
        "$DOCKER_IMAGE" \
        vllm serve "$MODEL_NAME" \
            --host 0.0.0.0 \
            --port 8000 \
            --tensor-parallel-size "$TENSOR_PARALLEL" \
            --max-model-len "$MAX_MODEL_LEN" \
            --gpu-memory-utilization "$GPU_MEMORY_UTILIZATION" \
            --dtype "$DTYPE" \
            --trust-remote-code

    echo ""
    echo "[启动] 容器已启动，等待模型加载..."
    echo "  查看日志: ./deploy_ascend.sh logs"
    echo "  测试连接: ./deploy_ascend.sh test"
    echo ""

    # 等待服务就绪
    echo -n "[等待] 模型加载中"
    for i in $(seq 1 60); do
        if curl -s "http://localhost:${PORT}/health" > /dev/null 2>&1; then
            echo ""
            echo "[OK] 服务已就绪！"
            echo ""
            echo "  API地址: http://$(hostname -I | awk '{print $1}'):${PORT}"
            echo "  健康检查: curl http://localhost:${PORT}/health"
            echo "  模型列表: curl http://localhost:${PORT}/v1/models"
            echo ""
            echo "  在客户端config.yaml中设置:"
            echo "    backend: \"vllm_ascend\""
            echo "    vllm_ascend:"
            echo "      base_url: \"http://$(hostname -I | awk '{print $1}'):${PORT}\""
            echo ""
            return 0
        fi
        echo -n "."
        sleep 5
    done
    echo ""
    echo "[警告] 服务启动超时(5分钟)，请查看日志: ./deploy_ascend.sh logs"
}

stop_service() {
    echo "[停止] 停止vLLM服务..."
    docker stop "$CONTAINER_NAME" 2>/dev/null || echo "容器未运行"
    docker rm "$CONTAINER_NAME" 2>/dev/null || true
    echo "[OK] 已停止"
}

show_status() {
    echo "=== 容器状态 ==="
    if docker ps --format '{{.Names}} {{.Status}}' | grep -q "^${CONTAINER_NAME}"; then
        docker ps --filter "name=${CONTAINER_NAME}" --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
        echo ""
        echo "=== 健康检查 ==="
        if curl -s "http://localhost:${PORT}/health" > /dev/null 2>&1; then
            echo "服务状态: 正常"
            echo "可用模型:"
            curl -s "http://localhost:${PORT}/v1/models" | python3 -m json.tool 2>/dev/null || echo "(解析失败)"
        else
            echo "服务状态: 加载中或异常"
        fi
    else
        echo "容器未运行"
    fi
}

show_logs() {
    docker logs -f "$CONTAINER_NAME" 2>/dev/null || echo "容器不存在"
}

test_connection() {
    echo "[测试] 发送测试请求到 http://localhost:${PORT}..."
    echo ""

    echo "--- 健康检查 ---"
    curl -s "http://localhost:${PORT}/health" && echo " OK" || echo " FAIL"
    echo ""

    echo "--- 模型列表 ---"
    curl -s "http://localhost:${PORT}/v1/models" | python3 -m json.tool 2>/dev/null
    echo ""

    echo "--- 对话测试 ---"
    RESPONSE=$(curl -s "http://localhost:${PORT}/v1/chat/completions" \
        -H "Content-Type: application/json" \
        -d "{
            \"model\": \"${MODEL_NAME}\",
            \"messages\": [{\"role\": \"user\", \"content\": \"请用一句话介绍DO-178C标准\"}],
            \"max_tokens\": 200
        }")
    echo "$RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$RESPONSE"
    echo ""
    echo "[OK] 测试完成"
}

# ---- 主逻辑 ----

case "${1:-}" in
    start)
        start_service
        ;;
    stop)
        stop_service
        ;;
    status)
        show_status
        ;;
    logs)
        show_logs
        ;;
    test)
        test_connection
        ;;
    *)
        echo "用法: $0 {start|stop|status|logs|test}"
        echo ""
        echo "  start   - 启动昇腾910B vLLM推理服务"
        echo "  stop    - 停止服务"
        echo "  status  - 查看服务状态"
        echo "  logs    - 查看实时日志"
        echo "  test    - 测试API连接"
        exit 1
        ;;
esac
