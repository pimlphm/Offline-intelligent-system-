const API_BASE = window.KNOWLEDGE_RAG_API || (location.protocol.startsWith("http") ? location.origin : "http://127.0.0.1:8010");
const LARGE_FILE_BYTES = 8 * 1024 * 1024;
const CHUNK_BYTES = 2 * 1024 * 1024;

const messages = document.querySelector("#messages");
const messageTemplate = document.querySelector("#messageTemplate");
const chatForm = document.querySelector("#chatForm");
const queryInput = document.querySelector("#queryInput");
const sendButton = document.querySelector("#sendButton");
const fileInput = document.querySelector("#fileInput");
const dropzone = document.querySelector("#dropzone");
const healthBadge = document.querySelector("#healthBadge");
const refreshTree = document.querySelector("#refreshTree");
const treeSearch = document.querySelector("#treeSearch");
const treeSummary = document.querySelector("#treeSummary");
const treeRoot = document.querySelector("#tree");

let treeData = null;
const collapsedNodes = new Set();

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function addMessage(role, html, tone = "") {
  const fragment = messageTemplate.content.cloneNode(true);
  const card = fragment.querySelector(".message");
  card.classList.add(role, tone);
  fragment.querySelector(".message-role").textContent = role;
  fragment.querySelector(".message-body").innerHTML = html;
  messages.appendChild(fragment);
  messages.scrollTop = messages.scrollHeight;
}

async function fetchJson(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, options);
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || `${response.status} ${response.statusText}`);
  }
  return response.json();
}

function summarizeCitations(results = []) {
  const seen = new Set();
  const citations = [];
  for (const item of results) {
    const label = item.doc_name || item.source || item.chunk_id;
    if (!label || seen.has(label)) continue;
    seen.add(label);
    citations.push(`<li>${escapeHtml(label)} <span class="node-meta">${escapeHtml(item.chunk_id || "")}</span></li>`);
  }
  if (!citations.length) return "";
  return `<p><strong>引用证据</strong></p><ul>${citations.slice(0, 8).join("")}</ul>`;
}

chatForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const query = queryInput.value.trim();
  if (!query) return;

  addMessage("user", escapeHtml(query));
  queryInput.value = "";
  sendButton.disabled = true;
  sendButton.textContent = "生成中";

  try {
    const result = await fetchJson("/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query, top_k: 10 }),
    });
    const route = result.route?.route ? `<p class="node-meta">Route: ${escapeHtml(result.route.route)}</p>` : "";
    addMessage("assistant", `${route}<p>${escapeHtml(result.answer || "未生成回答。")}</p>${summarizeCitations(result.retrieval_results)}`);
  } catch (error) {
    addMessage("system", `生成失败：${escapeHtml(error.message)}`, "system");
  } finally {
    sendButton.disabled = false;
    sendButton.textContent = "发送并生成引用答案";
  }
});

fileInput.addEventListener("change", () => {
  if (fileInput.files.length) uploadFiles([...fileInput.files]);
  fileInput.value = "";
});

["dragenter", "dragover"].forEach((name) => {
  dropzone.addEventListener(name, (event) => {
    event.preventDefault();
    dropzone.classList.add("dragging");
  });
});

["dragleave", "drop"].forEach((name) => {
  dropzone.addEventListener(name, (event) => {
    event.preventDefault();
    dropzone.classList.remove("dragging");
  });
});

dropzone.addEventListener("drop", (event) => {
  const files = [...event.dataTransfer.files];
  if (files.length) uploadFiles(files);
});

async function uploadFiles(files) {
  addMessage("system", `开始上传 ${files.length} 个文件，摄取完成后会刷新知识树。`, "system");
  const smallFiles = files.filter((file) => file.size <= LARGE_FILE_BYTES);
  const largeFiles = files.filter((file) => file.size > LARGE_FILE_BYTES);
  const summaries = [];

  try {
    if (smallFiles.length) summaries.push(await uploadBatch(smallFiles));
    for (const file of largeFiles) summaries.push(await uploadChunked(file));

    const docs = summaries.reduce((sum, item) => sum + (item.documents_processed || 0), 0);
    const chunks = summaries.reduce((sum, item) => sum + (item.chunks_written || 0), 0);
    addMessage("assistant", `上传摄取完成：处理 ${docs} 个文档，写入 ${chunks} 个 chunks。`);
    await loadTree();
  } catch (error) {
    addMessage("system", `上传失败：${escapeHtml(error.message)}`, "system");
  }
}

async function uploadBatch(files) {
  const form = new FormData();
  for (const file of files) form.append("files", file, file.name);
  return fetchJson("/upload", { method: "POST", body: form });
}

async function uploadChunked(file) {
  const totalChunks = Math.ceil(file.size / CHUNK_BYTES);
  const fileId = `${Date.now()}-${file.name}-${file.size}`.replace(/[^a-zA-Z0-9_-]/g, "_");
  let summary = { complete: false };

  for (let index = 0; index < totalChunks; index += 1) {
    const start = index * CHUNK_BYTES;
    const end = Math.min(start + CHUNK_BYTES, file.size);
    const form = new FormData();
    form.append("file_id", fileId);
    form.append("filename", file.name);
    form.append("chunk_index", String(index));
    form.append("total_chunks", String(totalChunks));
    form.append("chunk", file.slice(start, end), `${file.name}.part${index}`);
    summary = await fetchJson("/upload/chunk", { method: "POST", body: form });
    treeSummary.textContent = `${file.name}: ${index + 1}/${totalChunks} 分块已上传`;
  }

  return summary;
}

refreshTree.addEventListener("click", loadTree);
treeSearch.addEventListener("input", () => renderTree());

async function checkHealth() {
  try {
    const health = await fetchJson("/health");
    healthBadge.textContent = `在线 | chunks ${health.indexed_chunk_count}`;
  } catch {
    healthBadge.textContent = "未连接后端";
  }
}

async function loadTree() {
  treeSummary.textContent = "知识树加载中";
  try {
    treeData = await fetchJson("/tree");
    renderTree();
  } catch (error) {
    treeSummary.textContent = "知识树加载失败";
    treeRoot.innerHTML = `<p>${escapeHtml(error.message)}</p>`;
  }
}

function renderTree() {
  if (!treeData) return;
  const query = treeSearch.value.trim().toLowerCase();
  treeSummary.textContent = `${treeData.document_count || 0} 个文档，${treeData.chunk_count || 0} 个 chunks`;
  treeRoot.innerHTML = "";
  treeRoot.appendChild(renderNode(treeData, "root", query));
}

function renderNode(node, path, query) {
  const wrapper = document.createElement("ul");
  const item = document.createElement("li");
  const row = document.createElement("div");
  const nodePath = `${path}/${node.name}`;
  const hasChildren = Array.isArray(node.children) && node.children.length > 0;
  const isCollapsed = collapsedNodes.has(nodePath);
  const text = `${node.name || ""} ${node.kind || ""} ${node.preview || ""}`.toLowerCase();

  row.className = `tree-node ${node.kind || "node"}`;
  if (query && text.includes(query)) row.classList.add("highlight");

  if (hasChildren) {
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "node-toggle";
    toggle.textContent = isCollapsed ? "+" : "-";
    toggle.addEventListener("click", () => {
      if (collapsedNodes.has(nodePath)) collapsedNodes.delete(nodePath);
      else collapsedNodes.add(nodePath);
      renderTree();
    });
    row.appendChild(toggle);
  }

  const label = document.createElement(node.wiki_url ? "a" : "span");
  label.className = "node-label";
  label.textContent = node.name || "unnamed";
  if (node.wiki_url) {
    label.href = node.wiki_url;
    label.target = "_blank";
  }

  const meta = document.createElement("span");
  meta.className = "node-meta";
  meta.textContent = node.preview || `${node.kind || "node"}${node.chunk_count ? ` | ${node.chunk_count}` : ""}`;
  label.appendChild(meta);
  row.appendChild(label);
  item.appendChild(row);

  if (hasChildren && !isCollapsed) {
    const children = document.createElement("ul");
    node.children.forEach((child, index) => {
      children.appendChild(renderNode(child, `${nodePath}-${index}`, query).firstElementChild);
    });
    item.appendChild(children);
  }

  wrapper.appendChild(item);
  return wrapper;
}

addMessage("assistant", "控制台已就绪。可以先提问，也可以把文件拖进右侧上传区，摄取完成后知识树会自动生长。");
checkHealth();
loadTree();
