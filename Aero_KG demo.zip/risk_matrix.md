# Risk Matrix

| Risk ID | Area | Likelihood | Impact | Trigger | Mitigation | Rollback |
| --- | --- | --- | --- | --- | --- | --- |
| R-01 | Service migration | Medium | High | New API path diverges from desktop behavior | Keep desktop path intact until API benchmark passes | Switch clients back to legacy GUI path |
| R-02 | Retrieval regression | High | High | Hybrid retrieval lowers precision or increases latency too much | Gate all retrieval changes on Phase 2 benchmark reports | Disable `ENABLE_HYBRID_RETRIEVAL` and use sparse-only retrieval |
| R-03 | Embedding instability | Medium | Medium | Ollama embedding model missing or inconsistent | Add fallback hashed dense vectors and explicit provider health checks | Disable `ENABLE_DENSE_RETRIEVAL` |
| R-04 | Citation failure | Medium | High | Generator answers without evidence-backed citations | Keep citation enforcement in generator and evaluation suite | Fall back to retrieval-only output templates |
| R-05 | Chunk quality | High | High | Diagnostic segmentation merges unrelated failure modes | Use typed chunk schema, token bounds, and benchmark checks | Rebuild index from previous index version |
| R-06 | Knowledge graph overreach | Medium | Medium | Graph filtering reduces recall before proving lift | Keep graph layer optional and benchmark-gated | Disable `ENABLE_GRAPH_LAYER` |
| R-07 | Orchestrator drift | Low | Medium | Work proceeds without logs or gate decisions | Log every phase instruction and result via Program Manager | Re-run phase packet and freeze progression |
| R-08 | Dependency drift | Medium | Medium | FastAPI or provider dependencies are unavailable in runtime envs | Keep optional imports and wrapper scripts that find a usable interpreter | Continue using the Phase 0 smoke path and desktop app |
| R-09 | Performance ceiling | Medium | High | Dense retrieval or reranking pushes latency above target | Start with heuristic reranking and lightweight embeddings | Disable reranker and dense layer |
| R-10 | Security gap | Medium | High | Auto-generated knowledge writes bypass review | Add approval hooks before compiled knowledge is treated as trusted | Block write path and revert to read-only mode |

## Severity Rules

- High impact risks require a rollback path before deployment.
- Medium impact risks require a config flag boundary.
- Low impact risks may proceed with logging and monitoring.

## Current Recommendation

- Proceed with Phase 1 and Phase 2 immediately.
- Treat Phase 3 as a bootstrap implementation phase, not a production cutover.
- Do not enable graph or agentic flows in production until benchmark evidence exists.
