from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from orchestration.program_manager import ProgramManager


def main() -> int:
    parser = argparse.ArgumentParser(description="Record a phase instruction or result.")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--action", choices=["instruction", "result"], required=True)
    parser.add_argument("--decision", choices=["PROCEED", "REVERT", "REWAIT"], default="REWAIT")
    parser.add_argument("--artifact", action="append", default=[])
    parser.add_argument("--note", action="append", default=[])
    args = parser.parse_args()

    manager = ProgramManager(ROOT)
    if args.action == "instruction":
        payload = manager.record_instruction(args.phase, note="\n".join(args.note))
    else:
        payload = manager.record_result(
            args.phase,
            decision=args.decision,
            artifacts=args.artifact,
            notes=args.note,
        )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
