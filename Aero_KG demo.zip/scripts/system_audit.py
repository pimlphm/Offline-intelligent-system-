from __future__ import annotations

import json
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict

import yaml

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.doc_parser import PARSER_MAP


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def count_extensions(directory: Path) -> Dict[str, int]:
    counter: Counter[str] = Counter()
    if not directory.exists():
        return {}
    for path in directory.rglob("*"):
        if path.is_file():
            counter[path.suffix.lower() or "<no_ext>"] += 1
    return dict(sorted(counter.items()))


def read_requirements(requirements_path: Path) -> list[str]:
    return [
        line.strip()
        for line in requirements_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def collect_inventory(root: Path) -> dict:
    config = yaml.safe_load((root / "config.yaml").read_text(encoding="utf-8"))
    docs_dir = (root / "docs").resolve()
    standards_dir = (root / "standards").resolve()
    ontology_dir = (root / "ontology").resolve()

    inventory = {
        "generated_at": utc_now_iso(),
        "workspace_root": str(root.resolve()),
        "entrypoints": {
            "desktop_app": "main.py",
            "packaging": "build_app.py",
            "smoke_pipeline": "pipelines/run_current.py",
            "phase0_runner": "scripts/run_phase0.py",
            "test_suite": "test_all.py",
        },
        "runtime": {
            "ui_type": "PyQt5 desktop GUI",
            "configured_backend": config.get("backend"),
            "llm_backends": {
                "ollama": config.get("ollama", {}),
                "vllm_ascend": config.get("vllm_ascend", {}),
            },
        },
        "documents": {
            "watch_dir": config.get("documents", {}).get("watch_dir"),
            "supported_formats_in_config": config.get("documents", {}).get("supported_formats", []),
            "supported_formats_in_parser": sorted(PARSER_MAP.keys()),
            "docs_extension_counts": count_extensions(docs_dir),
            "standards_extension_counts": count_extensions(standards_dir),
        },
        "retrieval": {
            "chunking": {
                "implementation": "Character/paragraph chunking in core/rag_engine.py::_split_text",
                "default_chunk_size": 512,
                "default_overlap": 64,
            },
            "indexing": {
                "implementation": "In-process lexical index stored through core.rag_engine.RAGEngine",
                "persisted_index": "ontology/rag_index.json",
            },
            "ranking": [
                "BM25-style lexical scoring in core/rag_engine.py::search",
            ],
            "missing": [
                "Dense retrieval",
                "Hybrid dense+sparse fusion",
                "Dedicated reranker",
                "Query rewrite",
                "Retrieval routing",
            ],
            "source_files": [
                "core/rag_engine.py",
                "gui/main_window.py",
            ],
        },
        "knowledge_graph": {
            "ontology_store": "ontology/knowledge_graph.json",
            "graph_engine": "core/ontology_engine.py",
            "graph_builder_path": "core.llm_agent.AgentEngine.build_graph_from_analysis",
            "compiled_wiki_present": False,
            "graphml_present": False,
        },
        "storage": {
            "ontology_files": count_extensions(ontology_dir),
            "experience_store": "experience/_global/experience_index.json",
            "standards_store": "standards/standards_db.json",
            "audit_log": "orchestrator_log.json",
        },
        "frontend": {
            "implementation": "Desktop PyQt window in gui/main_window.py",
            "chat": True,
            "drag_drop_upload": True,
            "graph_visualization": True,
            "web_single_page_ui": False,
            "async_ingestion_pipeline": False,
            "ocr": False,
            "image_embeddings": False,
            "table_normalization": "Basic CSV/XLSX text extraction only",
        },
        "evaluation": {
            "current_tests": ["test_all.py"],
            "benchmark_suite_present": False,
            "retrieval_generation_error_split": False,
            "phase_eval_reports_present": False,
        },
        "operations": {
            "docker_compose_present": (root / "docker-compose.yml").exists(),
            "monitoring_present": (root / "monitoring").exists(),
            "rollback_script_present": (root / "scripts" / "rollback.sh").exists(),
            "feature_flags": config.get("feature_flags", {}),
            "versioning": config.get("versioning", {}),
        },
        "dependencies": read_requirements(root / "requirements.txt"),
        "gaps_vs_target": [
            "Current system is desktop-first, not API-first.",
            "Current retrieval is lexical only; no dense/hybrid/rerank stack exists.",
            "No compiled wiki/entity-topic knowledge layer is generated today.",
            "No phased orchestrator or gate-check existed before this upgrade slice.",
            "No benchmark/eval suite with gold sources and citation requirements exists yet.",
            "No Docker, monitoring, rollback, or write-approval security workflow exists yet.",
        ],
    }
    return inventory


def render_markdown(inventory: dict) -> str:
    lines = [
        "# As-Is System Audit",
        "",
        f"- Generated: {inventory['generated_at']}",
        f"- Workspace: `{inventory['workspace_root']}`",
        "",
        "## Summary",
        "",
        "The current repository is a desktop-first knowledge assistant built around a PyQt GUI, a local lexical RAG index,",
        "an ontology/graph store, and Ollama or vLLM-Ascend chat backends. It already parses multiple office/document formats",
        "and can build graph structures from LLM analysis, but it is not yet a production-grade, phased RAG platform.",
        "",
        "## Current Runtime",
        "",
        f"- Desktop entrypoint: `{inventory['entrypoints']['desktop_app']}`",
        f"- Packaging entrypoint: `{inventory['entrypoints']['packaging']}`",
        f"- Smoke pipeline: `{inventory['entrypoints']['smoke_pipeline']}`",
        f"- Configured backend: `{inventory['runtime']['configured_backend']}`",
        "",
        "## Retrieval Stack",
        "",
        "- Chunking is implemented in `core/rag_engine.py::_split_text` with character-oriented paragraph buffering.",
        "- Retrieval is implemented in `core/rag_engine.py::search` using a BM25-style lexical scorer over in-memory chunks.",
        "- The current persisted RAG index is `ontology/rag_index.json`.",
        "- Missing target capabilities: dense retrieval, hybrid fusion, reranker, query rewrite, routing.",
        "",
        "## Knowledge And Storage",
        "",
        "- Graph storage exists in `ontology/knowledge_graph.json` and is managed by `core/ontology_engine.py`.",
        "- Experience memory exists in `experience/_global/experience_index.json`.",
        "- Standards content exists in `standards/` with `standards/standards_db.json`.",
        "- No compiled wiki layer, entity pages, GraphML export pipeline, or layered retrieval path exists yet.",
        "",
        "## UI And Ingestion",
        "",
        "- The current interface is a PyQt desktop application in `gui/main_window.py`.",
        "- Drag-and-drop upload is supported for local files.",
        "- Document parsing covers PDF, DOCX, PPTX, XLSX, CSV, JSON, YAML, HTML, TXT, and Markdown through `core/doc_parser.py`.",
        "- Missing target capabilities: browser SPA UI, chunked async upload, OCR extraction, image embeddings, dynamic tree growth in the web client.",
        "",
        "## Evaluation And Operations",
        "",
        "- Current testing is concentrated in `test_all.py`.",
        "- No benchmark query set, eval suite, or phase-by-phase metric reports exist yet.",
        "- No Docker Compose, monitoring, rollback, or security approval pipeline exists yet.",
        "",
        "## Migration Gaps",
        "",
    ]
    lines.extend(f"- {item}" for item in inventory["gaps_vs_target"])
    lines.extend(
        [
            "",
            "## Immediate Next Step",
            "",
            "Phase 0 can be considered bootstrapped once `inventory.json`, `as_is_system_audit.md`, and a successful",
            "`pipelines/run_current` smoke report are all present. The next major work item is Phase 1: publish the target",
            "architecture, migration plan, and compatibility/rollback boundaries.",
            "",
        ]
    )
    return "\n".join(lines)


def write_audit_outputs(root: Path) -> dict:
    inventory = collect_inventory(root)
    inventory_path = root / "inventory.json"
    audit_path = root / "as_is_system_audit.md"
    inventory_path.write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
    audit_path.write_text(render_markdown(inventory), encoding="utf-8")
    return inventory


def main() -> int:
    inventory = write_audit_outputs(ROOT)
    print(json.dumps(
        {
            "inventory": "inventory.json",
            "audit": "as_is_system_audit.md",
            "gaps": inventory["gaps_vs_target"],
        },
        ensure_ascii=False,
        indent=2,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
