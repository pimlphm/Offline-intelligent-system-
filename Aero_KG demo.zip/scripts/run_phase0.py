from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from orchestration.program_manager import ProgramManager
from pipelines.run_current import run_current_pipeline
from scripts.system_audit import write_audit_outputs


def main() -> int:
    manager = ProgramManager(ROOT)
    instruction = manager.record_instruction(
        0,
        note="Bootstrap run: create Phase 0 audit artifacts and validate the current smoke pipeline.",
    )
    print(instruction["rendered"])
    print()

    write_audit_outputs(ROOT)
    smoke_result = run_current_pipeline(use_llm=False)

    report_rel = Path("output/reports/run_current_report.json")
    acceptance = {
        "audit_markdown_exists": (ROOT / "as_is_system_audit.md").exists(),
        "inventory_json_exists": (ROOT / "inventory.json").exists(),
        "run_current_report_exists": (ROOT / report_rel).exists(),
        "run_current_status": smoke_result["status"],
        "indexed_doc_count": smoke_result["indexed_doc_count"],
    }
    artifacts = ["as_is_system_audit.md", "inventory.json", str(report_rel)]
    notes = [
        "Phase 0 bootstrap executed in offline-safe mode.",
        "run_current.py uses the existing lexical RAG path and optional LLM generation.",
    ]
    decision = (
        "PROCEED"
        if acceptance["audit_markdown_exists"]
        and acceptance["inventory_json_exists"]
        and acceptance["run_current_report_exists"]
        and acceptance["run_current_status"] == "ok"
        else "REWAIT"
    )
    result = manager.record_result(
        0,
        decision=decision,
        artifacts=artifacts,
        notes=notes,
        acceptance_results=acceptance,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if decision == "PROCEED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
