from __future__ import annotations

import sys
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.yaml"


def main() -> int:
    config = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
    versioning = config.setdefault("versioning", {})

    active_index = versioning.get("active_index_version")
    previous_index = versioning.get("previous_index_version")
    active_model = versioning.get("active_model_version")
    previous_model = versioning.get("previous_model_version")

    if not previous_index and not previous_model:
        print("No previous versions available for rollback.")
        return 1

    if previous_index:
        versioning["active_index_version"], versioning["previous_index_version"] = previous_index, active_index
    if previous_model:
        versioning["active_model_version"], versioning["previous_model_version"] = previous_model, active_model
        config.setdefault("ollama", {})["model"] = versioning["active_model_version"]

    CONFIG_PATH.write_text(yaml.safe_dump(config, sort_keys=False, allow_unicode=True), encoding="utf-8")
    print("Rollback complete.")
    print(f"Active index version: {versioning.get('active_index_version')}")
    print(f"Active model version: {versioning.get('active_model_version')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
