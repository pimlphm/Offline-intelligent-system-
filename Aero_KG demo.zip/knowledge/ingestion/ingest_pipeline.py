from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from core.doc_parser import parse_document
from knowledge.ingestion.extractor import enrich_chunk
from knowledge.ingestion.segmenter import segment_parsed_document
from src.backend.utils import ensure_dir, resolve_repo_path


class IngestPipeline:
    def __init__(self, config: dict) -> None:
        self.config = config
        storage = config.get("storage", {})
        self.chunk_dir = ensure_dir(storage.get("chunk_dir", "./knowledge/chunks"))
        self.wiki_dir = ensure_dir(storage.get("wiki_dir", "./knowledge/wiki"))
        self.db_path = resolve_repo_path(storage.get("chunk_db", "./knowledge/chunks.db"))
        self._init_db()

    def ingest_paths(self, paths: list[str]) -> dict:
        parsed_documents = []
        for path in paths:
            parsed = parse_document(path)
            if parsed and parsed.get("content", "").strip():
                parsed_documents.append(parsed)
        return self.ingest_document_payloads(parsed_documents)

    def ingest_document_payloads(self, payloads: list[dict]) -> dict:
        doc_count = 0
        chunk_count = 0
        wiki_count = 0
        for payload in payloads:
            if not payload or not payload.get("content", "").strip():
                continue
            doc_count += 1
            chunks = [enrich_chunk(chunk) for chunk in segment_parsed_document(payload, self.config)]
            for chunk in chunks:
                self._write_chunk(chunk)
                self._insert_chunk_row(chunk)
            chunk_count += len(chunks)
            if self.config.get("ingestion", {}).get("enable_wiki_stub", True):
                self._write_wiki_stub(payload, chunks)
                wiki_count += 1
        return {
            "documents_processed": doc_count,
            "chunks_written": chunk_count,
            "wiki_pages_written": wiki_count,
        }

    def _write_chunk(self, chunk: dict) -> None:
        path = self.chunk_dir / f"{chunk['chunk_id']}.json"
        path.write_text(json.dumps(chunk, ensure_ascii=False, indent=2), encoding="utf-8")

    def _write_wiki_stub(self, payload: dict, chunks: list[dict]) -> None:
        chunk_types = {}
        for chunk in chunks:
            chunk_types[chunk["chunk_type"]] = chunk_types.get(chunk["chunk_type"], 0) + 1
        lines = [
            f"# {payload['name']}",
            "",
            f"- Chunk count: {len(chunks)}",
            f"- Types: {json.dumps(chunk_types, ensure_ascii=False)}",
            f"- Source: {payload['name']}",
            "",
            "## Summary",
            "",
            (payload.get("content", "")[:1200] + "...") if len(payload.get("content", "")) > 1200 else payload.get("content", ""),
        ]
        path = self.wiki_dir / f"{Path(payload['name']).stem}.md"
        path.write_text("\n".join(lines), encoding="utf-8")

    def _init_db(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS chunks (
                    chunk_id TEXT PRIMARY KEY,
                    doc_name TEXT NOT NULL,
                    source TEXT NOT NULL,
                    chunk_type TEXT NOT NULL,
                    text TEXT NOT NULL,
                    entities_json TEXT NOT NULL,
                    conditions_json TEXT NOT NULL,
                    relations_json TEXT NOT NULL,
                    metadata_json TEXT NOT NULL
                )
                """
            )

    def _insert_chunk_row(self, chunk: dict) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO chunks (
                    chunk_id, doc_name, source, chunk_type, text,
                    entities_json, conditions_json, relations_json, metadata_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    chunk["chunk_id"],
                    chunk.get("metadata", {}).get("doc_name", chunk.get("source", "")),
                    chunk.get("source", ""),
                    chunk.get("chunk_type", ""),
                    chunk.get("text", ""),
                    json.dumps(chunk.get("entities", []), ensure_ascii=False),
                    json.dumps(chunk.get("conditions", []), ensure_ascii=False),
                    json.dumps(chunk.get("relations", []), ensure_ascii=False),
                    json.dumps(chunk.get("metadata", {}), ensure_ascii=False),
                ),
            )
