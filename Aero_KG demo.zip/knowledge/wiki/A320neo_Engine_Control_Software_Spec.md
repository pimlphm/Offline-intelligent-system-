# A320neo_Engine_Control_Software_Spec.md

- Chunk count: 2
- Types: {"evidence": 2}
- Source: A320neo_Engine_Control_Software_Spec.md

## Summary

# Airbus A320neo - 发动机控制软件需求规格 (公开资料整理)

**文档编号**: A320N-ECS-SRS-001  
**版本**: Issue 3  
**日期**: 2026-01-28  
**参考标准**: DO-178C, ARP4754A, FAR 33.28

---

## 1. 概述

A320neo系列配备LEAP-1A (CFM International) 和 PW1100G (Pratt & Whitney) 两款新一代发动机。本文档针对发动机数字控制系统(FADEC)的软件需求。

## 2. FADEC软件需求

### REQ-FADEC-001: 推力控制精度
- **描述**: FADEC应将推力控制偏差控制在设定值的±1%以内(稳态)
- **优先级**: Critical
- **DAL等级**: DAL A

### REQ-FADEC-002: 发动机启动序列
- **描述**: 自动启动序列应管理点火、加速到地面慢车全过程，用时<60s
- **优先级**: High
- **DAL等级**: DAL A

### REQ-FADEC-003: 超转保护
- **描述**: N1/N2超转保护应在检测到超转后50ms内启动燃油切断
- **优先级**: Critical
- **安全要求**: 发动机非包容故障概率 < 10⁻⁸/飞行小时

### REQ-FADEC-004: 推力反推控制
- **描述**: 反推激活仅在地面且WOW(Weight-on-Wheels)信号有效时允许
- **优先级**: Critical

### REQ-FADEC-005: 发动机健康监控(EHM)
- **描述**: FADEC应持续采集和处理以下参数用于趋势监控:
  - 振动 (Fan, Core)
  - EGT裕度
  - 燃油流量偏差
  - 滑油温度/压力
- **优先级**: High

### REQ-FADEC-006: 通道切换
- **描述**: 双通道FADEC应在主通道故障后自动切换到备用通道，切换时间<20ms
- **优先级**: Critical

## 3. 软件设计

### DES-FADEC-001: 推力控制器设计
- **实现需求**: REQ-FADEC-001
- **方案**: PID + 前馈补偿 + 自适应增益调度
- **控制周期**: 10ms

### DES-FADEC-002: 保护逻辑设计
- **实现需求**: REQ-FADEC-003, REQ-FADEC-004
- **方案**: 硬件看门狗 + 软件多级保护

### DES-FADEC-003: EHM算法设计
- **实现需求**: REQ-FADEC-005
- *...