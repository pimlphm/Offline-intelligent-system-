# A350_Flight_Control_System_Design.md

- Chunk count: 4
- Types: {"evidence": 3, "cause": 1}
- Source: A350_Flight_Control_System_Design.md

## Summary

# Airbus A350 XWB - 飞行控制系统设计文档 (公开资料整理)

**文档编号**: A350-FCS-DD-001  
**版本**: Issue 4  
**日期**: 2026-02-20  
**分类**: 系统设计描述 (System Design Description)  
**参考标准**: ARP4754A, DO-178C, DO-254, EUROCAE ED-12C

---

## 1. 系统架构概述

A350 XWB飞行控制系统采用全数字电传飞控(Fly-By-Wire, FBW)架构，继承并优化了A380的设计经验。

### 1.1 架构特征
- **三余度飞行控制计算机**: 3台FCPC (Flight Control Primary Computer)
- **双余度备份**: 2台FCSC (Flight Control Secondary Computer)
- **异构冗余**: FCPC和FCSC采用不同处理器架构和不同供应商
- **通讯总线**: AFDX (Avionics Full-Duplex Switched Ethernet)

## 2. 系统需求

### REQ-FCS-001: 正常控制律
- **描述**: 正常法则下，系统应提供C*控制律，飞行员输入与飞机响应之间满足特性时间常数<1.5s
- **优先级**: Critical
- **DAL等级**: DAL A
- **依据**: CS 25.143 Controllability and Manoeuvrability

### REQ-FCS-002: 飞行包线保护
- **描述**: 系统应提供以下保护功能：
  - 迎角保护 (Alpha Protection)
  - 过载保护 (Load Factor Protection): -1g ~ +2.5g
  - 俯仰姿态保护 (Pitch Attitude Protection)
  - 坡度保护 (Bank Angle Protection): ±67°
  - 速度保护 (High/Low Speed Protection)
- **优先级**: Critical
- **DAL等级**: DAL A

### REQ-FCS-003: 故障降级
- **描述**: 系统应支持以下降级模式:
  1. 正常法则 (Normal Law) → 备用法则 (Alternate Law) → 直接法则 (Direct Law)
  2. 任何单一故障不应导致从正常法则直接降级到直接法则
- **优先级**: Critical
- **DAL等级**: DAL A
- **安全要求**: 极度危险故障概率 < 10⁻⁹/飞行小时

### REQ-FCS-00...