# B787_Electrical_Power_System_Requirements.md

- Chunk count: 4
- Types: {"evidence": 3, "rule": 1}
- Source: B787_Electrical_Power_System_Requirements.md

## Summary

# Boeing 787 Dreamliner - 电气功率系统需求规格书 (公开资料整理)

**文档编号**: B787-EPS-SRS-001  
**版本**: Rev C  
**日期**: 2026-01-15  
**分类**: 系统需求规格 (System Requirements Specification)  
**参考标准**: ARP4754A, DO-178C, DO-254, MIL-STD-704F

---

## 1. 系统概述

Boeing 787采用革命性的全电气架构(More Electric Aircraft, MEA)，用电气系统取代了传统的液压和气动系统。电气功率系统是787架构的核心创新。

### 1.1 架构特点
- **无引气系统**: 取消传统发动机引气，采用电动压缩机
- **功率容量**: 总装机容量约1.45MW，是传统飞机的5倍
- **配电架构**: 两级配电 (270VDC + 115VAC/28VDC)

## 2. 功能需求

### REQ-EPS-001: 主发电机功率输出
- **描述**: 每台主发电机应提供不低于250kVA的连续功率输出
- **优先级**: Critical
- **验证方法**: 测试 (DO-178C DAL A)
- **来源**: ARP4754A 系统级需求分解

### REQ-EPS-002: 配电切换
- **描述**: 主配电总线之间应支持自动无缝切换，切换时间不超过50ms
- **优先级**: Critical
- **安全等级**: DAL A
- **验证方法**: 测试 + 分析

### REQ-EPS-003: 功率管理控制
- **描述**: 功率管理控制器(PMC)应实时监控所有电气负载，支持优先级卸载策略
- **优先级**: High
- **验证方法**: 测试 + 仿真

### REQ-EPS-004: 电池备份系统
- **描述**: 锂电池系统应在所有发电机失效后提供至少30分钟的关键负载供电
- **优先级**: Critical
- **安全等级**: DAL A
- **来源**: FAR 25.1353, CS 25.1353

### REQ-EPS-005: 电磁兼容性
- **描述**: 电气系统应满足DO-160G Section 20/21/22的电磁兼容性要求
- **优先级**: High
- **验证方法**: 测试

### REQ-EPS-006: 过电压保护
- **描述**: 系统应对270VDC总线提供过电压保护，触发阈值为290VDC±5%
- **优先级**: Critical
- **安全等级**: DAL B

### REQ-EPS-007: 接地故障检测
- *...