# A320neo_FBW_DO178C_Certification.md

- Chunk count: 7
- Types: {"evidence": 5, "cause": 1, "symptom": 1}
- Source: A320neo_FBW_DO178C_Certification.md

## Summary

# A320neo 电传飞控系统 DO-178C适航认证包
## 需求-设计-代码-测试 完整追溯文档

**文档编号**: A320-FBW-CERT-002  
**版本**: Issue 5  
**ATA章节**: ATA 27 - 飞行控制  
**适用型号**: A320neo/A321neo/A319neo  
**认证基础**: CS 25.1309, CS 25.671, CS 25.672  
**编制单位**: Airbus - Flight Control System Design Authority  
**DAL等级**: **DAL A** (灾难级失效状态)

---

## 1. 系统概述

A320neo电传飞控系统(FBW)由以下计算机组成：
- **ELAC** (Elevator Aileron Computer) × 2
- **SEC** (Spoiler Elevator Computer) × 3  
- **FAC** (Flight Augmentation Computer) × 2

### 1.1 法则降级策略
| 优先级 | 控制法则 | 可用计算机 | 保护功能 |
|--------|----------|-----------|----------|
| 1 | Normal Law正常法则 | ELAC1或ELAC2 | 全包线保护 |
| 2 | Alternate Law备选法则 | SEC1/2/3 | 部分保护 |
| 3 | Direct Law直接法则 | 任一SEC | 无自动保护 |
| 4 | Mechanical Backup机械备份 | 无 | 仅俯仰配平+方向舵 |

---

## 2. 需求层级体系 (DOORS中的层级)

### 2.1 飞机级需求 (来自CS-25条款)
| 需求编号 | 来源条款 | 需求描述 |
|----------|----------|----------|
| AREQ-27-001 | CS 25.671(a) | 飞行控制系统应确保安全飞行和着陆 |
| AREQ-27-002 | CS 25.672(a) | 主飞行控制系统的故障不得导致飞机不可控 |
| AREQ-27-003 | CS 25.672(b) | 任何单一失效不得导致主飞控功能完全丧失 |
| AREQ-27-004 | CS 25.1309(b) | 灾难性失效概率<1×10⁻⁹/fh |

### 2.2 系统级需求 (ARP4754A分解)
| 需求编号 | 上游追溯 | 需求描述 | DAL |
|----------|----------|----------|-----|
| SYSREQ-FBW-001 | AREQ-27-001 | EL...