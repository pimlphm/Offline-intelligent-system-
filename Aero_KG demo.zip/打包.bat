@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion
title AeroKB Agent - Build
cd /d "%~dp0"

echo ============================================
echo   AeroKB Agent - Build Installer
echo ============================================
echo.

echo [1/3] Finding Python...
set PY=
if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PY=C:\ProgramData\anaconda3\python.exe"
    echo   Using Anaconda Python
) else (
    where python >nul 2>&1
    if !errorlevel! equ 0 (
        set "PY=python"
        echo   Using system Python
    ) else (
        echo   [ERROR] Python not found
        pause
        exit /b 1
    )
)

echo.
echo [2/3] Installing PyInstaller...
"!PY!" -m pip install pyinstaller -q

echo.
echo [3/3] Building application...
echo       (This may take 3-10 minutes)
echo.
"!PY!" build_app.py --inno

echo.
echo ============================================
if !errorlevel! equ 0 (
    echo   Build complete!
    echo   Portable: dist\AeroKnowledgeAgent\
    echo   Installer: installer_output\
) else (
    echo   Build error occurred
)
echo ============================================
echo.
pause
endlocal