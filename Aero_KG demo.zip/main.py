"""
民机适航知识库Agent
========================================
面向空客/波音民机设计团队的适航知识图谱系统
集成经验积累与审计引擎
启动时自动检测硬件配置，智能选择模型
"""
import sys
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
os.chdir(str(BASE_DIR))
sys.path.insert(0, str(BASE_DIR))

import yaml
from PyQt5.QtWidgets import QApplication, QSplashScreen, QMessageBox
from PyQt5.QtGui import QPixmap, QFont, QPainter, QColor
from PyQt5.QtCore import Qt


def load_config():
    config_path = BASE_DIR / "config.yaml"
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    return {
        "backend": "ollama",
        "ollama": {"base_url": "http://localhost:11434",
                   "model": "qwen2.5:7b-instruct",
                   "temperature": 0.3, "max_tokens": 4096},
        "vllm_ascend": {"base_url": "http://localhost:8000",
                        "model": "Qwen/Qwen2.5-7B-Instruct",
                        "temperature": 0.3, "max_tokens": 4096,
                        "api_key": "EMPTY"},
        "ontology": {"graph_db": "ontology/knowledge_graph.json"},
    }


def create_splash(hw_info=None):
    pix = QPixmap(600, 420)
    pix.fill(QColor("#0d1117"))
    p = QPainter(pix)

    p.setPen(QColor("#58a6ff"))
    p.setFont(QFont("Microsoft YaHei", 24, QFont.Bold))
    p.drawText(pix.rect().adjusted(0, 25, 0, -300), Qt.AlignCenter,
               "民机适航知识库 Agent")

    p.setPen(QColor("#8b949e"))
    p.setFont(QFont("Microsoft YaHei", 10))
    p.drawText(pix.rect().adjusted(0, 70, 0, -280), Qt.AlignCenter,
               "IOF/BFO Ontology · ARP4754A/DO-178C/ARP4761")

    if hw_info:
        p.setPen(QColor("#30363d"))
        p.fillRect(30, 110, 540, 120, QColor("#161b22"))
        p.drawRect(30, 110, 540, 120)

        p.setPen(QColor("#58a6ff"))
        p.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        p.drawText(45, 132, "硬件检测")

        p.setFont(QFont("Microsoft YaHei", 9))
        p.setPen(QColor("#c9d1d9"))
        p.drawText(45, 152, f"GPU: {hw_info.get('gpu_summary', '检测中...')}")
        p.drawText(45, 170, f"内存: {hw_info.get('ram_gb', '?')} GB")
        p.drawText(45, 188,
                   f"CPU: {hw_info.get('cpu', {}).get('name', '?')[:45]}"
                   f" ({hw_info.get('cpu', {}).get('cores', '?')}核)")

        tier = hw_info.get("recommended_tier", {})
        p.setPen(QColor("#3fb950"))
        p.setFont(QFont("Microsoft YaHei", 9, QFont.Bold))
        p.drawText(45, 220,
                   f"推荐模型: {tier.get('label', '?')} — "
                   f"{tier.get('models', ['?'])[0]}")

    colors = ["#FF0000", "#FF6600", "#FFCC00", "#33CC33",
              "#00CCCC", "#3366FF", "#9933FF"]
    labels = ["赤", "橙", "黄", "绿", "青", "蓝", "紫"]
    start_x = (600 - 7 * 36) // 2
    p.setFont(QFont("Microsoft YaHei", 9))
    for i, (c, l) in enumerate(zip(colors, labels)):
        x = start_x + i * 36
        p.fillRect(x, 250, 30, 16, QColor(c))
        p.setPen(QColor("#ffffff"))
        p.drawText(x, 250, 30, 16, Qt.AlignCenter, l)

    p.setPen(QColor("#484f58"))
    p.setFont(QFont("Microsoft YaHei", 9))
    p.drawText(pix.rect().adjusted(0, 280, 0, -80), Qt.AlignCenter,
               "关联强度色谱: 赤(极强) → 紫(极弱)")

    p.setPen(QColor("#30363d"))
    p.setFont(QFont("Microsoft YaHei", 9))
    p.drawText(pix.rect().adjusted(0, 340, 0, -30), Qt.AlignCenter,
               "正在初始化...")
    p.end()
    return QSplashScreen(pix)


def main():
    app = QApplication(sys.argv)
    app.setFont(QFont("Microsoft YaHei", 10))

    config = load_config()

    # ---- 1. 硬件检测 ----
    from core.hardware_detect import detect_all, find_best_model
    hw_info = detect_all()

    splash = create_splash(hw_info)
    splash.show()
    app.processEvents()

    splash.showMessage("正在连接推理后端...",
                       Qt.AlignBottom | Qt.AlignCenter, QColor("#58a6ff"))
    app.processEvents()

    # ---- 2. 创建LLM客户端 ----
    from core.llm_agent import create_llm_client, AgentEngine
    llm = create_llm_client(config)

    # ---- 3. 自动检测模型并选择最优 ----
    tier = hw_info["recommended_tier"]
    connected = llm.check_connection()

    if connected:
        available = llm.list_models()
        if available:
            best = find_best_model(available, tier)
            llm.set_model(best)
            config.setdefault("ollama", {})["model"] = best
            splash.showMessage(
                f"已自动选择模型: {best} (基于 {hw_info['gpu_summary']})",
                Qt.AlignBottom | Qt.AlignCenter, QColor("#3fb950"))
        else:
            splash.showMessage(
                f"Ollama已连接但无可用模型，请运行: ollama pull {tier['models'][0]}",
                Qt.AlignBottom | Qt.AlignCenter, QColor("#d29922"))
        app.processEvents()
    else:
        splash.close()
        backend = config.get("backend", "ollama")
        if backend == "vllm_ascend":
            url = config.get("vllm_ascend", {}).get("base_url", "")
            QMessageBox.warning(None, "vLLM-Ascend 未连接",
                f"无法连接到昇腾910B vLLM推理服务: {url}\n\n"
                "请运行 deploy_ascend.sh start 启动服务。\n"
                "系统将以离线模式启动。")
        else:
            url = config.get("ollama", {}).get("base_url", "")
            suggest_model = tier["models"][0]
            QMessageBox.warning(None, "Ollama 未连接",
                f"无法连接到Ollama: {url}\n\n"
                f"检测到您的硬件: {hw_info['gpu_summary']}\n"
                f"推荐模型: {suggest_model}\n\n"
                f"请执行:\n"
                f"  1. ollama serve\n"
                f"  2. ollama pull {suggest_model}\n\n"
                "系统将以离线模式启动。")
        splash = create_splash(hw_info)
        splash.show()
        app.processEvents()

    # ---- 4. 初始化各引擎 ----
    splash.showMessage("初始化知识图谱引擎...",
                       Qt.AlignBottom | Qt.AlignCenter, QColor("#58a6ff"))
    app.processEvents()

    from core.ontology_engine import OntologyEngine
    ontology = OntologyEngine(
        db_path=config.get("ontology", {}).get("graph_db",
                                                "ontology/knowledge_graph.json")
    )

    splash.showMessage("初始化经验引擎...",
                       Qt.AlignBottom | Qt.AlignCenter, QColor("#58a6ff"))
    app.processEvents()

    from core.experience_engine import ExperienceEngine
    experience = ExperienceEngine(str(BASE_DIR), llm_client=llm)

    splash.showMessage("初始化适航标准库...",
                       Qt.AlignBottom | Qt.AlignCenter, QColor("#58a6ff"))
    app.processEvents()

    from core.standards_library import StandardsLibrary
    standards = StandardsLibrary(str(BASE_DIR))

    agent = AgentEngine(llm, ontology, experience_engine=experience,
                        standards_library=standards)

    # ---- 5. 注入小模型skills ----
    agent._hw_info = hw_info
    agent._model_tier = tier["tier"]
    agent._skills_prompt = hw_info.get("skills_prompt", "")

    splash.showMessage("启动界面...",
                       Qt.AlignBottom | Qt.AlignCenter, QColor("#58a6ff"))
    app.processEvents()

    from gui.main_window import MainWindow
    window = MainWindow(agent, ontology, config, experience, standards,
                        hw_info=hw_info)
    window.show()
    splash.finish(window)

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
