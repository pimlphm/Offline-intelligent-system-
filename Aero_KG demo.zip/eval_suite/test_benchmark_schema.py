from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
BENCHMARK_PATH = ROOT / "eval" / "benchmark_queries.json"
REQUIRED_KEYS = {
    "id",
    "query",
    "gold_sources",
    "expected_answer_type",
    "citation_requirement",
    "complexity",
    "query_family",
}


def test_benchmark_schema() -> None:
    benchmark = json.loads(BENCHMARK_PATH.read_text(encoding="utf-8"))
    assert len(benchmark) >= 50
    for item in benchmark:
        assert REQUIRED_KEYS.issubset(item.keys())
        assert item["gold_sources"]
        assert item["complexity"] in {"simple", "medium", "complex"}
