from __future__ import annotations

from eval.run_all import citation_precision, reciprocal_rank


def test_reciprocal_rank_hits_first_match() -> None:
    docs = ["a.md", "b.md", "c.md"]
    assert reciprocal_rank(docs, ["b.md"]) == 0.5


def test_citation_precision_counts_gold_hits() -> None:
    answer = "Use a.md and b.md for the final response."
    assert citation_precision(answer, ["a.md", "b.md"]) == 1.0
