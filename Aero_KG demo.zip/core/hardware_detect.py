"""
硬件自动检测与模型推荐引擎
==========================================
启动时自动检测: GPU型号/显存, 系统内存, CPU
根据硬件配置自动推荐最优Ollama模型尺寸
"""
import subprocess
import re
import os
import platform
import json


def detect_gpu():
    """
    检测GPU信息, 返回列表:
    [{"name": "NVIDIA GeForce RTX 5060", "vram_mb": 8192, "driver": "..."}]
    """
    gpus = []

    # --- NVIDIA (nvidia-smi) ---
    try:
        out = subprocess.check_output(
            ["nvidia-smi",
             "--query-gpu=name,memory.total,driver_version",
             "--format=csv,noheader,nounits"],
            timeout=10, stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        ).decode("utf-8", errors="replace")
        for line in out.strip().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 2:
                name = parts[0]
                try:
                    vram_mb = int(float(parts[1]))
                except ValueError:
                    vram_mb = 0
                driver = parts[2] if len(parts) > 2 else ""
                gpus.append({"name": name, "vram_mb": vram_mb,
                             "driver": driver, "vendor": "NVIDIA"})
    except (FileNotFoundError, subprocess.SubprocessError):
        pass

    if not gpus:
        no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            out = subprocess.check_output(
                ["powershell", "-Command",
                 "Get-CimInstance Win32_VideoController | "
                 "Select-Object Name,AdapterRAM | "
                 "ForEach-Object { $_.Name + '|' + $_.AdapterRAM }"],
                timeout=10, stderr=subprocess.DEVNULL,
                creationflags=no_window,
            ).decode("utf-8", errors="replace")
            for line in out.strip().splitlines():
                parts = line.split("|")
                if len(parts) >= 1 and parts[0].strip():
                    name = parts[0].strip()
                    ram_bytes = int(parts[1].strip()) if len(parts) > 1 and parts[1].strip().isdigit() else 0
                    vendor = "NVIDIA" if "nvidia" in name.lower() else (
                        "AMD" if "amd" in name.lower() or "radeon" in name.lower()
                        else "Intel" if "intel" in name.lower() else "Unknown")
                    gpus.append({"name": name, "vram_mb": ram_bytes // (1024*1024),
                                 "driver": "", "vendor": vendor})
        except (FileNotFoundError, subprocess.SubprocessError):
            pass

    return gpus


def detect_system_memory_mb():
    """检测系统总内存 (MB)"""
    no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    if platform.system() == "Windows":
        for cmd in [
            ["powershell", "-Command",
             "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory"],
            ["wmic", "ComputerSystem", "get", "TotalPhysicalMemory",
             "/format:value"],
        ]:
            try:
                out = subprocess.check_output(
                    cmd, timeout=10, stderr=subprocess.DEVNULL,
                    creationflags=no_window,
                ).decode("utf-8", errors="replace").strip()
                for line in out.splitlines():
                    val = line.split("=")[-1].strip() if "=" in line else line.strip()
                    if val.isdigit() and int(val) > 1_000_000:
                        return int(val) // (1024 * 1024)
            except (FileNotFoundError, subprocess.SubprocessError):
                continue
    else:
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal"):
                        kb = int(re.search(r"\d+", line).group())
                        return kb // 1024
        except Exception:
            pass
    return 0


def detect_cpu():
    """检测CPU信息"""
    info = {"name": platform.processor() or "Unknown", "cores": os.cpu_count() or 0}
    no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    if platform.system() == "Windows":
        for cmd in [
            ["powershell", "-Command",
             "(Get-CimInstance Win32_Processor).Name"],
            ["wmic", "cpu", "get", "Name", "/format:value"],
        ]:
            try:
                out = subprocess.check_output(
                    cmd, timeout=10, stderr=subprocess.DEVNULL,
                    creationflags=no_window,
                ).decode("utf-8", errors="replace").strip()
                for line in out.splitlines():
                    val = line.split("=", 1)[-1].strip() if "=" in line else line.strip()
                    if val and len(val) > 3 and "Name" not in val:
                        info["name"] = val
                        break
                if info["name"] != (platform.processor() or "Unknown"):
                    break
            except (FileNotFoundError, subprocess.SubprocessError):
                continue
    return info


# ==============================================================
#  模型推荐矩阵
# ==============================================================

MODEL_TIERS = [
    {
        "tier": "tiny",
        "min_vram_mb": 0,
        "max_vram_mb": 4096,
        "min_ram_mb": 0,
        "models": [
            "qwen2.5:1.5b-instruct",
            "qwen2.5:0.5b-instruct",
            "phi3:mini",
            "gemma2:2b",
        ],
        "label": "轻量级 (1.5B参数)",
        "max_tokens": 2048,
        "temperature": 0.2,
    },
    {
        "tier": "small",
        "min_vram_mb": 4096,
        "max_vram_mb": 6144,
        "min_ram_mb": 8192,
        "models": [
            "qwen2.5:3b-instruct",
            "qwen2.5:1.5b-instruct",
            "phi3:mini",
            "llama3.2:3b",
        ],
        "label": "小型 (3B参数)",
        "max_tokens": 3072,
        "temperature": 0.25,
    },
    {
        "tier": "medium",
        "min_vram_mb": 6144,
        "max_vram_mb": 12288,
        "min_ram_mb": 16384,
        "models": [
            "qwen2.5:7b-instruct",
            "qwen2.5:3b-instruct",
            "llama3.1:8b-instruct",
            "gemma2:9b",
        ],
        "label": "中型 (7B参数, 适合8GB显卡)",
        "max_tokens": 4096,
        "temperature": 0.3,
    },
    {
        "tier": "large",
        "min_vram_mb": 12288,
        "max_vram_mb": 24576,
        "min_ram_mb": 32768,
        "models": [
            "qwen2.5:14b-instruct",
            "qwen2.5:7b-instruct",
            "llama3.1:8b-instruct",
            "deepseek-coder-v2:16b",
        ],
        "label": "大型 (14B参数)",
        "max_tokens": 4096,
        "temperature": 0.3,
    },
    {
        "tier": "xlarge",
        "min_vram_mb": 24576,
        "max_vram_mb": 999999,
        "min_ram_mb": 65536,
        "models": [
            "qwen2.5:32b-instruct",
            "qwen2.5:14b-instruct",
            "llama3.1:70b-instruct",
            "deepseek-v2.5",
        ],
        "label": "超大 (32B+参数)",
        "max_tokens": 8192,
        "temperature": 0.3,
    },
]


def recommend_tier(vram_mb: int, ram_mb: int) -> dict:
    """根据显存和内存推荐最佳模型层级"""
    effective = vram_mb if vram_mb > 0 else (ram_mb // 2)
    best = MODEL_TIERS[0]
    for tier in MODEL_TIERS:
        if effective >= tier["min_vram_mb"]:
            best = tier
    return best


def find_best_model(available_models: list, tier: dict) -> str:
    """从Ollama可用模型列表中匹配推荐tier的最佳模型"""
    available_lower = {m.lower(): m for m in available_models}

    for candidate in tier["models"]:
        cl = candidate.lower()
        if cl in available_lower:
            return available_lower[cl]
        base = cl.split(":")[0]
        for al, orig in available_lower.items():
            if al.startswith(base):
                return orig

    if available_models:
        for m in available_models:
            ml = m.lower()
            if any(kw in ml for kw in ["qwen", "llama", "phi", "gemma", "deepseek"]):
                return m
        return available_models[0]
    return tier["models"][0]


# ==============================================================
#  小模型增强 Skills (思维链/结构化输出保障)
# ==============================================================

SMALL_MODEL_SKILLS = """
重要约束 (小型模型执行规范):
1. 每次回答前先在内心列出要点，再按序输出
2. JSON输出必须是合法JSON，不要添加额外的文字解释在JSON之外
3. 提取实体时宁少勿错：只提取确定存在的实体和关系
4. 每次最多处理5个实体和8条关系，分批输出
5. 如果文档内容超出理解能力，明确回答"此部分超出当前分析范围"
6. 强度评估采用简化规则:
   - 直接追溯/实现 → 0.9
   - 同层级关联 → 0.7
   - 跨层级关联 → 0.5
   - 间接引用 → 0.3
   - 泛化关联 → 0.1
"""

MEDIUM_MODEL_SKILLS = """
执行规范:
1. 提取实体时注意区分层级关系，保持追溯链完整
2. JSON输出严格符合schema，不添加额外字段
3. 每批次最多处理10个实体和15条关系
4. 不确定的关系标注strength为0.3，后续可人工审核
"""

LARGE_MODEL_SKILLS = ""


def get_skills_prompt(tier_name: str) -> str:
    """根据模型层级返回增强skills提示词"""
    if tier_name in ("tiny", "small"):
        return SMALL_MODEL_SKILLS
    elif tier_name == "medium":
        return MEDIUM_MODEL_SKILLS
    return LARGE_MODEL_SKILLS


# ==============================================================
#  一键检测
# ==============================================================

def detect_all():
    """
    一键检测全部硬件信息，返回:
    {
        "gpus": [...],
        "gpu_summary": "NVIDIA RTX 5060 (8GB)",
        "ram_mb": 32768,
        "ram_gb": 32,
        "cpu": {"name": "...", "cores": 16},
        "recommended_tier": {...},
        "platform": "Windows-10..."
    }
    """
    gpus = detect_gpu()
    ram_mb = detect_system_memory_mb()
    cpu = detect_cpu()

    max_vram = max((g["vram_mb"] for g in gpus), default=0)

    gpu_summary = "未检测到独立显卡"
    if gpus:
        primary = gpus[0]
        vram_gb = primary["vram_mb"] / 1024
        gpu_summary = f"{primary['name']} ({vram_gb:.0f}GB)"

    tier = recommend_tier(max_vram, ram_mb)

    return {
        "gpus": gpus,
        "gpu_summary": gpu_summary,
        "vram_mb": max_vram,
        "ram_mb": ram_mb,
        "ram_gb": round(ram_mb / 1024, 1),
        "cpu": cpu,
        "recommended_tier": tier,
        "platform": platform.platform(),
        "skills_prompt": get_skills_prompt(tier["tier"]),
    }
