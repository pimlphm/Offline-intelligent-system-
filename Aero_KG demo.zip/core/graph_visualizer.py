"""
专业级知识图谱可视化
===================
- 赤橙黄绿青蓝紫 七级关联强度色谱
- IOF/BFO分层节点样式
- 力导向布局 + 层级布局可切换
- 军工/航空航天研究人员友好的暗色方案
"""
import json
import os
from pathlib import Path
from core.ontology_engine import (
    TYPE_HIERARCHY, RELATION_TYPES, STRENGTH_SPECTRUM,
    strength_to_color, strength_to_width,
)

GRAPH_HTML_TEMPLATE = """<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<title>{title}</title>
<script src="https://cdn.jsdelivr.net/npm/vis-network@9.1.6/standalone/umd/vis-network.min.js"></script>
<style>
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ background:#0d1117; color:#c9d1d9; font-family:'Microsoft YaHei','Source Han Sans',sans-serif; }}
  #header {{ background:linear-gradient(135deg,#161b22,#0d1117);
             padding:12px 24px; border-bottom:1px solid #21262d;
             display:flex; align-items:center; justify-content:space-between; }}
  #header h1 {{ font-size:16px; color:#58a6ff; font-weight:600; }}
  #header .meta {{ font-size:11px; color:#8b949e; }}
  #graph-container {{ width:100%; height:calc(100vh - 44px); }}
  #legend {{ position:fixed; top:56px; right:12px; background:#161b22;
             border:1px solid #21262d; border-radius:8px; padding:14px;
             z-index:999; width:200px; font-size:11px; }}
  #legend h3 {{ color:#58a6ff; font-size:13px; margin-bottom:8px;
                border-bottom:1px solid #21262d; padding-bottom:6px; }}
  .legend-item {{ display:flex; align-items:center; margin:4px 0; }}
  .legend-dot {{ width:10px; height:10px; border-radius:50%; margin-right:8px;
                 flex-shrink:0; }}
  .legend-line {{ width:24px; height:3px; margin-right:8px; border-radius:2px;
                  flex-shrink:0; }}
  #strength-bar {{ position:fixed; bottom:12px; left:50%; transform:translateX(-50%);
                   background:#161b22; border:1px solid #21262d; border-radius:8px;
                   padding:10px 20px; z-index:999; display:flex; align-items:center;
                   gap:4px; font-size:11px; }}
  .spectrum-block {{ width:28px; height:14px; border-radius:2px; text-align:center;
                     font-size:9px; line-height:14px; color:white;
                     text-shadow:0 0 2px rgba(0,0,0,0.8); }}
  #controls {{ position:fixed; top:56px; left:12px; background:#161b22;
               border:1px solid #21262d; border-radius:8px; padding:10px;
               z-index:999; font-size:11px; }}
  #controls button {{ background:#21262d; color:#c9d1d9; border:1px solid #30363d;
                      padding:4px 10px; border-radius:4px; cursor:pointer;
                      margin:2px; font-size:11px; }}
  #controls button:hover {{ background:#30363d; }}
  #controls button.active {{ background:#1f6feb; border-color:#58a6ff; }}
</style></head>
<body>
<div id="header">
  <h1>{title}</h1>
  <div class="meta">{meta}</div>
</div>
<div id="graph-container"></div>

<div id="controls">
  <div style="color:#58a6ff;font-weight:bold;margin-bottom:6px;">操作</div>
  <button onclick="network.fit()">全局视图</button>
  <button onclick="togglePhysics()" id="physBtn" class="active">物理引擎</button>
  <button onclick="filterByStrength(0.5)">仅强关联</button>
  <button onclick="filterByStrength(0)">显示全部</button>
  <div style="margin-top:8px;color:#8b949e;">
    滚轮缩放 | 拖拽平移 | 点击节点查看详情
  </div>
</div>

<div id="legend">
  <h3>节点类型</h3>
  {legend_nodes}
  <h3 style="margin-top:10px;">关系类型</h3>
  {legend_edges}
</div>

<div id="strength-bar">
  <span style="color:#8b949e;">关联强度:</span>
  {spectrum_bar}
  <span style="color:#8b949e;margin-left:4px;">强→弱</span>
</div>

<script>
var nodesData = {nodes_json};
var edgesData = {edges_json};

var nodes = new vis.DataSet(nodesData);
var edges = new vis.DataSet(edgesData);
var allEdges = edgesData.slice();

var container = document.getElementById('graph-container');
var data = {{ nodes: nodes, edges: edges }};
var options = {{
  physics: {{
    enabled: {physics_init},
    solver: 'forceAtlas2Based',
    forceAtlas2Based: {{
      gravitationalConstant: -120,
      centralGravity: 0.008,
      springLength: 180,
      springConstant: 0.04,
      damping: 0.5,
      avoidOverlap: 0.3
    }},
    stabilization: {{ iterations: 300 }},
  }},
  interaction: {{
    hover: true, tooltipDelay: 80,
    navigationButtons: true, keyboard: true,
    zoomView: true, dragView: true,
  }},
  edges: {{
    smooth: {{ type: 'continuous' }},
    font: {{ size: 9, color: '#8b949e', strokeWidth: 0 }},
    arrows: {{ to: {{ scaleFactor: 0.6 }} }},
  }},
  nodes: {{
    font: {{ size: 12, color: '#c9d1d9', face: 'Microsoft YaHei' }},
    borderWidth: 2, shadow: {{ enabled: true, color: 'rgba(0,0,0,0.3)' }},
  }},
}};

var network = new vis.Network(container, data, options);
var physicsOn = {physics_init};

function togglePhysics() {{
  physicsOn = !physicsOn;
  network.setOptions({{ physics: {{ enabled: physicsOn }} }});
  document.getElementById('physBtn').className = physicsOn ? 'active' : '';
}}

function filterByStrength(min) {{
  var filtered = allEdges.filter(function(e) {{ return (e.strength || 0) >= min; }});
  edges.clear();
  edges.add(filtered);
}}

network.on("click", function(params) {{
  if (params.nodes.length > 0) {{
    var nodeId = params.nodes[0];
    var node = nodes.get(nodeId);
    var connected = network.getConnectedEdges(nodeId);
    var info = node.title || node.label;
    console.log(info);
  }}
}});
</script>
</body></html>"""


def generate_graph_html(ontology_engine, output_path: str,
                        title="知识图谱 | Knowledge Ontology Graph",
                        physics: bool = True) -> str:
    stats = ontology_engine.get_statistics()
    meta = (f"节点: {stats['total_nodes']} | 边: {stats['total_edges']} | "
            f"平均强度: {stats['avg_strength']:.2f} | "
            f"连通分量: {stats['connected_components']}")

    vis_data = ontology_engine.to_vis_json()

    # Legend: 按layer分组的节点类型
    type_groups = {}
    for n in ontology_engine.nodes.values():
        t = n["type"]
        if t not in type_groups:
            info = TYPE_HIERARCHY.get(t, {})
            type_groups[t] = info
    legend_nodes_html = ""
    for t, info in sorted(type_groups.items(), key=lambda x: x[1].get("layer", "")):
        color = info.get("base_color", "#999")
        label = info.get("label", t)
        legend_nodes_html += (
            f'<div class="legend-item">'
            f'<div class="legend-dot" style="background:{color};"></div>'
            f'{label}</div>\n'
        )

    # Legend: 使用过的关系类型
    used_rels = set(e["relation"] for e in ontology_engine.edges)
    legend_edges_html = ""
    for rel in sorted(used_rels):
        info = RELATION_TYPES.get(rel, {})
        legend_edges_html += (
            f'<div class="legend-item">'
            f'<div class="legend-line" style="background:#58a6ff;"></div>'
            f'{info.get("label", rel)}</div>\n'
        )

    # Spectrum bar
    spectrum_html = ""
    for threshold, color, name, desc in STRENGTH_SPECTRUM:
        spectrum_html += (
            f'<div class="spectrum-block" style="background:{color};" '
            f'title="{desc} (>={threshold})">{name}</div>\n'
        )

    # Add strength to edge data for filtering
    for e in vis_data["edges"]:
        matched = [edge for edge in ontology_engine.edges
                   if edge["source"] == e["from"] and edge["target"] == e["to"]]
        if matched:
            e["strength"] = matched[0].get("strength", 0.5)

    html = GRAPH_HTML_TEMPLATE.format(
        title=title,
        meta=meta,
        nodes_json=json.dumps(vis_data["nodes"], ensure_ascii=False),
        edges_json=json.dumps(vis_data["edges"], ensure_ascii=False),
        legend_nodes=legend_nodes_html,
        legend_edges=legend_edges_html,
        spectrum_bar=spectrum_html,
        physics_init="true" if physics else "false",
    )

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    return output_path


def generate_traceability_html(ontology_engine, output_path: str) -> str:
    matrix = ontology_engine.get_traceability_matrix()
    stats = ontology_engine.get_statistics()
    missing = ontology_engine.suggest_missing_links()
    nextgen = ontology_engine.suggest_next_gen()

    rows = ""
    for rid, info in matrix.items():
        req = info["requirement"]
        cov = info["coverage"]
        c_color = {"full": "#3fb950", "partial": "#d29922", "none": "#f85149"}[cov]
        c_text = {"full": "完整", "partial": "部分", "none": "缺失"}[cov]
        rows += f"""<tr>
          <td>{rid}</td><td>{req['label']}</td><td>{req.get('type','')}</td>
          <td>{', '.join(d.get('label','') for d in info['designs']) or '—'}</td>
          <td>{', '.join(c.get('label','') for c in info['codes']) or '—'}</td>
          <td>{', '.join(t.get('label','') for t in info['tests']) or '—'}</td>
          <td style="color:{c_color};font-weight:bold;">{c_text}</td></tr>"""

    issues = ""
    for m in missing:
        sc = {"critical": "#f85149", "high": "#f0883e", "medium": "#d29922",
              "low": "#3fb950"}.get(m.get("severity", ""), "#8b949e")
        issues += (f'<div style="margin:6px 0;padding:10px;background:#161b22;'
                   f'border-left:3px solid {sc};border-radius:4px;">'
                   f'<b style="color:{sc};">[{m.get("severity","")}]</b> '
                   f'{m["message"]}</div>')

    html = f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<title>追溯矩阵</title>
<style>
body {{ background:#0d1117; color:#c9d1d9; font-family:'Microsoft YaHei',sans-serif; padding:20px; }}
h1 {{ color:#58a6ff; border-bottom:1px solid #21262d; padding-bottom:10px; }}
.stats {{ display:flex; gap:12px; margin:16px 0; }}
.stat {{ background:#161b22; border:1px solid #21262d; border-radius:8px; padding:12px 20px;
         text-align:center; flex:1; }}
.stat .num {{ font-size:24px; font-weight:bold; color:#58a6ff; }}
.stat .lbl {{ font-size:11px; color:#8b949e; }}
table {{ width:100%; border-collapse:collapse; margin:16px 0; }}
th {{ background:#161b22; color:#58a6ff; padding:10px; text-align:left; font-size:12px;
      border-bottom:2px solid #21262d; }}
td {{ padding:8px 10px; border-bottom:1px solid #21262d; font-size:12px; }}
tr:hover {{ background:#161b22; }}
h2 {{ color:#c9d1d9; font-size:16px; margin-top:24px; }}
</style></head><body>
<h1>需求追溯矩阵 | Traceability Matrix</h1>
<div class="stats">
  <div class="stat"><div class="num">{stats['total_nodes']}</div><div class="lbl">知识节点</div></div>
  <div class="stat"><div class="num">{stats['total_edges']}</div><div class="lbl">关系连接</div></div>
  <div class="stat"><div class="num">{len(matrix)}</div><div class="lbl">需求条目</div></div>
  <div class="stat"><div class="num">{sum(1 for v in matrix.values() if v['coverage']=='full')}</div>
       <div class="lbl">完整追溯</div></div>
</div>
<table><tr><th>ID</th><th>需求</th><th>类型</th><th>设计</th><th>代码</th><th>测试</th><th>覆盖</th></tr>
{rows}</table>
<h2>问题与风险</h2>{issues or '<p style="color:#8b949e;">暂无</p>'}
<h2>下一代知识方向</h2>{''.join(f'<div style="margin:6px 0;padding:10px;background:#161b22;border-left:3px solid #58a6ff;border-radius:4px;"><b style="color:#58a6ff;">[{ng.get("priority","?")}]</b> {ng.get("direction","")}: {ng.get("detail","")}</div>' for ng in nextgen) or '<p style="color:#8b949e;">暂无</p>'}
</body></html>"""

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    return output_path
