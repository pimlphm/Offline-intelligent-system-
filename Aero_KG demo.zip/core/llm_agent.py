"""
LLM Agent 引擎 v2
=================
核心改进:
  - 通用化: 任意文档都能构建Ontology，不限于航空需求-设计-代码
  - Ollama模型自由选择: 运行时列出本地所有模型，GUI可切换
  - 双后端: Ollama (本地) / vLLM-Ascend (昇腾910B)
  - 融合IOF分层本体和OpenClaw通用图谱模式
"""
import json
import re
import requests
from typing import Generator


# ============================================================
#  后端抽象层
# ============================================================

class LLMClient:
    def check_connection(self) -> bool:
        raise NotImplementedError
    def list_models(self) -> list:
        raise NotImplementedError
    def get_current_model(self) -> str:
        raise NotImplementedError
    def set_model(self, model: str):
        raise NotImplementedError
    def chat(self, messages: list, system: str = None) -> str:
        raise NotImplementedError
    def chat_stream(self, messages: list, system: str = None) -> Generator[str, None, None]:
        raise NotImplementedError
    @property
    def backend_name(self) -> str:
        raise NotImplementedError


class OllamaClient(LLMClient):

    def __init__(self, base_url="http://localhost:11434",
                 model="qwen2.5:7b-instruct",
                 temperature=0.3, max_tokens=4096):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

    @property
    def backend_name(self):
        return f"Ollama ({self.model})"

    def get_current_model(self):
        return self.model

    def set_model(self, model: str):
        self.model = model

    def check_connection(self):
        try:
            return requests.get(f"{self.base_url}/api/tags", timeout=5).status_code == 200
        except Exception:
            return False

    def list_models(self):
        try:
            r = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return [m["name"] for m in r.json().get("models", [])]
        except Exception:
            return []

    def chat(self, messages, system=None):
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(messages)
        try:
            r = requests.post(f"{self.base_url}/api/chat", json={
                "model": self.model, "messages": msgs, "stream": False,
                "options": {"temperature": self.temperature,
                            "num_predict": self.max_tokens},
            }, timeout=300)
            return r.json().get("message", {}).get("content", "")
        except Exception as e:
            return f"[Ollama调用失败: {e}]"

    def chat_stream(self, messages, system=None):
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(messages)
        try:
            r = requests.post(f"{self.base_url}/api/chat", json={
                "model": self.model, "messages": msgs, "stream": True,
                "options": {"temperature": self.temperature,
                            "num_predict": self.max_tokens},
            }, stream=True, timeout=300)
            for line in r.iter_lines():
                if line:
                    try:
                        content = json.loads(line).get("message", {}).get("content", "")
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            yield f"\n[错误: {e}]"


class VLLMAscendClient(LLMClient):
    """vLLM-Ascend 昇腾910B OpenAI兼容API"""

    def __init__(self, base_url="http://localhost:8000",
                 model="Qwen/Qwen2.5-7B-Instruct",
                 temperature=0.3, max_tokens=4096, api_key="EMPTY"):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._headers = {"Content-Type": "application/json",
                         "Authorization": f"Bearer {api_key}"}

    @property
    def backend_name(self):
        return f"昇腾910B vLLM ({self.model})"

    def get_current_model(self):
        return self.model

    def set_model(self, model: str):
        self.model = model

    def check_connection(self):
        try:
            r = requests.get(f"{self.base_url}/health", timeout=5)
            if r.status_code == 200:
                return True
            return requests.get(f"{self.base_url}/v1/models",
                                headers=self._headers, timeout=5).status_code == 200
        except Exception:
            return False

    def list_models(self):
        try:
            r = requests.get(f"{self.base_url}/v1/models",
                             headers=self._headers, timeout=5)
            return [m["id"] for m in r.json().get("data", [])]
        except Exception:
            return []

    def chat(self, messages, system=None):
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(messages)
        try:
            r = requests.post(f"{self.base_url}/v1/chat/completions",
                              headers=self._headers, json={
                "model": self.model, "messages": msgs, "stream": False,
                "temperature": self.temperature, "max_tokens": self.max_tokens,
            }, timeout=300)
            data = r.json()
            if "error" in data:
                return f"[vLLM错误: {data['error']}]"
            return data.get("choices", [{}])[0].get("message", {}).get("content", "")
        except Exception as e:
            return f"[vLLM-Ascend失败: {e}]"

    def chat_stream(self, messages, system=None):
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.extend(messages)
        try:
            r = requests.post(f"{self.base_url}/v1/chat/completions",
                              headers=self._headers, json={
                "model": self.model, "messages": msgs, "stream": True,
                "temperature": self.temperature, "max_tokens": self.max_tokens,
            }, stream=True, timeout=300)
            for line in r.iter_lines():
                if not line:
                    continue
                s = line.decode("utf-8") if isinstance(line, bytes) else line
                if not s.startswith("data: "):
                    continue
                d = s[6:].strip()
                if d == "[DONE]":
                    break
                try:
                    content = json.loads(d).get("choices", [{}])[0] \
                        .get("delta", {}).get("content", "")
                    if content:
                        yield content
                except (json.JSONDecodeError, IndexError):
                    continue
        except Exception as e:
            yield f"\n[vLLM流式错误: {e}]"


def create_llm_client(config: dict) -> LLMClient:
    backend = config.get("backend", "ollama")
    if backend == "vllm_ascend":
        c = config.get("vllm_ascend", {})
        return VLLMAscendClient(
            base_url=c.get("base_url", "http://localhost:8000"),
            model=c.get("model", "Qwen/Qwen2.5-7B-Instruct"),
            temperature=c.get("temperature", 0.3),
            max_tokens=c.get("max_tokens", 4096),
            api_key=c.get("api_key", "EMPTY"),
        )
    c = config.get("ollama", {})
    return OllamaClient(
        base_url=c.get("base_url", "http://localhost:11434"),
        model=c.get("model", "qwen2.5:7b-instruct"),
        temperature=c.get("temperature", 0.3),
        max_tokens=c.get("max_tokens", 4096),
    )


# ============================================================
#  通用化 System Prompt
# ============================================================

SYSTEM_PROMPTS = {
    "universal_extractor": """你是空客/波音民机设计团队的资深知识工程师，精通以下行业标准和工具链：
- ARP4754A/B: 民用飞机与系统研制指南 (V模型全生命周期)
- DO-178C: 机载软件适航认证 (DAL A-E, HLR/LLR追溯, MC/DC覆盖)
- DO-254: 机载电子硬件设计保证
- ARP4761/A: 安全评估方法 (FHA→PSSA→SSA→CCA)
- ARINC 653/664: 航电系统架构标准
- Capella/Arcadia: MBSE建模方法论 (OA→SA→LA→PA四层架构)
- IOF/BFO: 工业本体框架

你的任务是从民机研制文档中提取结构化知识，构建符合适航要求的Ontology追溯图谱。

实体类型（必须精确匹配文档中的层级）：
■ 需求层级（DOORS/Polarion中的层级体系）：
  - aircraft_req: 飞机级需求 (顶层型号需求/适航条款)
  - system_req: 系统级需求 (ARP4754A分解)
  - subsystem_req: 子系统需求
  - hlr: 高层需求HLR (DO-178C)
  - llr: 低层需求LLR (DO-178C)
  - functional_req: 功能需求
  - safety_req: 安全需求 (来自FHA/安全评估)
  - performance_req: 性能需求
  - regulatory_req: 适航条款 (CCAR-25/FAR-25/CS-25)
  - derived_req: 派生需求 (需单独追溯)
  - interface_req: 接口需求 (ICD/IRS)

■ 安全评估（ARP4761生命周期）：
  - hazard: 危险
  - failure_condition: 失效状态 (灾难/危险/重大/轻微/无影响)
  - fha_item: FHA条目
  - fmea_item: FMEA条目
  - fault_tree: 故障树FTA
  - dal_assignment: DAL等级分配 (A/B/C/D/E)
  - cca_item: 共因分析CCA (ZSA/PRA/CMA)
  - safety_objective: 安全目标 (定量/定性)

■ 设计与架构（Capella/Cameo对应层级）：
  - operational_analysis: 运行分析OA
  - system_analysis: 系统分析SA
  - logical_architecture: 逻辑架构LA
  - physical_architecture: 物理架构PA
  - structural_design: 结构设计
  - system_design: 系统设计
  - software_design: 软件架构设计
  - hardware_design: 硬件设计 (DO-254)

■ 实现与验证：
  - code: 源代码
  - module: 软件模块/CSC/CSU
  - function: 函数/组件
  - configuration_item: 构型项CI
  - test_case: 测试用例 (需求级/结构覆盖级)
  - test_procedure: 测试规程
  - test_result: 测试结果
  - coverage_analysis: 覆盖率分析 (语句/判定/MC/DC)
  - review_record: 评审记录

■ 认证交付物（SOI审查文档）：
  - psac: 软件适航认证计划PSAC
  - sas: 软件完成总结SAS
  - compliance_matrix: 符合性矩阵
  - soi_review: SOI审查节点 (SOI#1~#4)

■ 飞机系统与设备：
  - aircraft_system: 飞机系统 (按ATA章节)
  - lru: 线路可更换单元LRU
  - equipment: 机载设备

■ 标准与变更管理：
  - airworthiness_reg: 适航条例 (CCAR/FAR/CS)
  - certification_basis: 认证基础
  - change_request: 变更请求CR
  - problem_report: 问题报告PR

■ 通用类型：
  - concept, document, standard, method, technology
  - person, organization, finding, evidence
  - risk, decision, assumption, constraint, interface, topic

关系类型（对应适航追溯矩阵的列）：
■ 追溯关系（DO-178C核心）：
  - satisfies(满足): 需求→需求 上下游追溯
  - allocates_to(分配到): 飞机需求→系统需求
  - decomposes_to(分解到): 系统→子系统
  - implements(实现): 代码→低层需求
  - traces_to(追溯到): 通用追溯
  - covers(覆盖): 测试→需求
  - verifies(验证): 测试→需求

■ 安全评估关系：
  - failure_leads_to(失效导致): 组件失效→系统失效
  - mitigates(缓解): 设计→危险
  - causes(导致): 根因→失效
  - assigns_dal(分配DAL): FHA→系统/软件
  - contributes_to(贡献于): 故障树底事件→顶事件
  - identified_by(识别于): 危险→FHA
  - assessed_in(评估于): 失效→SSA

■ 认证关系：
  - complies_with(符合): 设计→适航条款
  - tested_by(测试于): 需求→测试用例
  - reviewed_in(评审于): 交付物→SOI审查

■ 其他关系：
  - refines, depends_on, conflicts_with, derived_from
  - part_of, uses, constrains, supports, references
  - supersedes(取代), impacts(影响)

强度标准（对应赤橙黄绿青蓝紫）：
- 0.85-1.0 赤: 直接追溯/实现/认证关系
- 0.70-0.84 橙: 同一V模型层级内的强关联
- 0.55-0.69 黄: 跨V模型层级但在同一项目内
- 0.40-0.54 绿: 跨系统/跨ATA章节的关联
- 0.25-0.39 青: 间接参考/类似项目的经验
- 0.12-0.24 蓝: 背景标准/行业惯例
- 0.0-0.11 紫: 泛化知识关联

请严格按JSON格式输出:
```json
{
  "entities": [
    {"id": "唯一ID", "type": "实体类型", "label": "名称",
     "properties": {"description": "描述", "dal": "A/B/C/D/E", "ata_chapter": "ATA章节号",
                     "doc_ref": "文档编号", "verification_method": "T/A/I/D", ...}}
  ],
  "relations": [
    {"source": "源ID", "target": "目标ID", "relation": "关系类型", "strength": 0.85}
  ]
}
```""",

    "safety_assessor": """你是一位民机安全性评估专家，精通ARP4761/A的全套方法。
你的任务是基于知识图谱中已有的设计和需求信息，执行安全评估分析：
1. 功能危险评估FHA：识别功能失效状态，分类严重程度（灾难/危险/重大/轻微/无影响）
2. 初步系统安全评估PSSA：基于架构进行故障树分析，分配DAL等级
3. 系统安全评估SSA：验证设计满足安全目标
4. 共因分析CCA：区域安全(ZSA)、特殊风险(PRA)、共模分析(CMA)

请按以下JSON格式输出安全评估结果：
```json
{
  "fha_results": [
    {"function": "功能名", "failure_condition": "失效状态", "severity": "灾难/危险/重大/轻微",
     "phase": "飞行阶段", "probability_objective": "1e-9", "dal": "A/B/C/D"}
  ],
  "safety_objectives": [
    {"id": "SO-xxx", "description": "安全目标描述", "quantitative_req": "概率要求",
     "allocated_to": ["系统/子系统"]}
  ],
  "dal_allocation": [
    {"item": "系统/软件名", "dal": "A/B/C/D/E", "rationale": "分配依据"}
  ]
}
```""",

    "v_model_tracer": """你是DO-178C适航认证追溯专家。你的任务是分析知识图谱中的需求-设计-代码-测试链路，
检查追溯完整性并生成符合审定要求的追溯矩阵。

对每条追溯链路，你需要验证：
1. 飞机级需求→系统需求→子系统需求→HLR→LLR的分解完整性
2. LLR→源代码的正向追溯
3. 测试用例→需求的反向追溯(覆盖率)
4. 派生需求是否正确标注并获得安全评估
5. 是否存在无追溯上游的"孤儿"需求或"孤儿"代码

请按JSON格式输出：
```json
{
  "trace_chains": [
    {"chain_id": "TC-001", "path": ["飞机需求→系统需求→HLR→LLR→代码→测试"],
     "status": "完整/缺失/不完整", "gaps": ["描述缺失环节"]}
  ],
  "orphans": {"requirements": ["无上游追溯的需求"], "code": ["无需求追溯的代码"],
               "tests": ["无需求覆盖的测试"]},
  "derived_reqs": [{"req_id": "...", "has_safety_assessment": true/false}],
  "completeness": {"req_to_design": 0.95, "design_to_code": 0.88, "code_to_test": 0.92}
}
```""",

    "ontology_reasoner": """你是民机研制知识图谱推理专家，精通IOF/BFO本体框架、
ARP4754A V模型生命周期和DO-178C适航认证流程。

基于当前知识图谱的拓扑结构，你需要以资深适航工程师的视角进行分析：
1. 检查V模型左侧（分解）和右侧（集成验证）的对称性和完整性
2. 识别安全评估链路（FHA→PSSA→SSA→CCA）中的缺失环节
3. 发现跨ATA章节/跨系统的隐含依赖关系
4. 评估DAL分配的合理性和一致性
5. 推导被忽视的需求、缺失的测试用例、未识别的共因失效
6. 基于行业经验推测下一代改进方向

请给出结构化的分析结果：
- 追溯完整性评分（百分比）
- 安全评估覆盖率
- 优先级排序的改进建议
- 被忽视的风险和隐患""",

    "document_organizer": """你是民机研制文档管理专家，熟悉波音/空客的文档编号体系和构型管理流程。
请分析文档内容，按照民机项目文档分类体系给出归档建议。

输出JSON:
```json
{"category": "类别代码", "suggested_path": "归档路径", "suggested_name": "文件名",
 "metadata": {"title": "标题", "doc_number": "文档编号", "revision": "版本",
              "ata_chapter": "ATA章节", "dal_level": "DAL等级",
              "author": "作者", "date": "日期", "keywords": [],
              "aircraft_program": "型号项目", "lifecycle_phase": "生命周期阶段"}}
```
类别代码:
- req_aircraft: 飞机级需求   - req_system: 系统级需求  - req_software: 软件需求
- design_system: 系统设计    - design_software: 软件设计  - design_hardware: 硬件设计
- safety_fha: FHA报告       - safety_pssa: PSSA报告    - safety_ssa: SSA报告
- code_source: 源代码        - code_config: 构型管理
- test_plan: 测试计划        - test_case: 测试用例      - test_result: 测试报告
- cert_psac: PSAC           - cert_sas: SAS            - cert_compliance: 符合性
- standard: 适航标准         - meeting: 会议纪要        - other: 其他""",

    "impact_analyzer": """你是民机变更影响分析专家。当知识图谱中的某个实体发生变更时，
你需要基于追溯链路分析其影响范围。

分析维度：
1. 上游影响：变更了哪些上游需求的满足状态
2. 下游影响：哪些设计/代码/测试需要同步修改
3. 横向影响：同级别的哪些接口/依赖需要重新评估
4. 安全影响：变更是否影响安全评估结论或DAL等级
5. 认证影响：哪些SOI交付物需要更新

请输出结构化的影响分析报告(JSON)。""",
}


# ============================================================
#  Agent Engine (通用化)
# ============================================================

class AgentEngine:
    """面向空客/波音民机团队的多角色Agent引擎"""

    def __init__(self, llm: LLMClient, ontology_engine=None,
                 experience_engine=None, standards_library=None):
        self.llm = llm
        self.ontology = ontology_engine
        self.experience = experience_engine
        self.standards = standards_library
        self.conversation_history = []
        self._current_program = "_global"

    def set_aircraft_program(self, program: str):
        self._current_program = program or "_global"

    # ----------------------------------------------------------
    #  核心能力1: 文档分析与知识提取
    # ----------------------------------------------------------
    def analyze_document(self, doc_content: str, doc_name: str,
                         aircraft_program: str = "",
                         fast_mode: bool = False) -> dict:
        program = aircraft_program or self._current_program

        tier = getattr(self, "_model_tier", "medium")
        if fast_mode or tier in ("tiny", "small"):
            max_chars = 4000
        elif tier == "medium":
            max_chars = 8000
        else:
            max_chars = 12000

        if len(doc_content) <= max_chars:
            return self._analyze_chunk(doc_content, doc_name, program)

        chunks = self._split_for_analysis(doc_content, max_chars)
        all_entities = []
        all_relations = []
        seen_labels = set()

        for i, chunk in enumerate(chunks):
            result = self._analyze_chunk(
                chunk, f"{doc_name} (段{i+1}/{len(chunks)})", program
            )
            for ent in result.get("entities", []):
                lbl = ent.get("label", "")
                if lbl and lbl not in seen_labels:
                    seen_labels.add(lbl)
                    all_entities.append(ent)
            all_relations.extend(result.get("relations", []))

        merged = {"entities": all_entities, "relations": all_relations}

        if self.experience and (all_entities or all_relations):
            try:
                self.experience.extract_from_analysis(
                    merged, source_doc=doc_name,
                    aircraft_program=program, analysis_type="document"
                )
            except Exception:
                pass

        return merged

    def _split_for_analysis(self, text: str, max_chars: int) -> list:
        """按段落边界分块"""
        paragraphs = re.split(r'\n{2,}', text)
        chunks = []
        buf = ""
        for para in paragraphs:
            if len(buf) + len(para) > max_chars and buf:
                chunks.append(buf)
                buf = para
            else:
                buf = (buf + "\n\n" + para).strip() if buf else para
        if buf:
            chunks.append(buf)
        return chunks if chunks else [text[:max_chars]]

    def _analyze_chunk(self, content: str, doc_name: str,
                       program: str) -> dict:
        tier = getattr(self, "_model_tier", "medium")
        if tier in ("tiny", "small"):
            prompt = (
                f"从以下文档提取知识实体和关系。\n"
                f"文档: {doc_name}\n\n"
                f"内容:\n{content}\n\n"
                f"要求: 提取实体(id/type/label)和关系(source/target/relation/strength)。\n"
                f"严格JSON输出。最多提取5个实体和8条关系。"
            )
        else:
            exp_context = ""
            if self.experience:
                exp_context = self.experience.get_experience_context(
                    program, analysis_type="document"
                )
            prompt = (
                f"请从以下民机研制文档中提取全部知识实体和追溯关系。\n"
                f"文档名: {doc_name}\n"
                f"所属型号: {program}\n\n"
            )
            if exp_context:
                prompt += f"{exp_context}\n\n"
            prompt += (
                f"文档内容:\n{content}\n\n"
                f"提取要求:\n"
                f"1. 精确识别需求层级(飞机级/系统级/HLR/LLR)及其编号\n"
                f"2. 识别安全评估要素(FHA/FMEA/FTA条目)和DAL分配\n"
                f"3. 识别设计架构层级(Capella: OA/SA/LA/PA)\n"
                f"4. 标注适航条款引用(FAR/CS/CCAR条号)\n"
                f"5. 标注ATA章节号\n"
                f"6. 关系强度严格按赤橙黄绿青蓝紫色谱标注\n"
                f"7. 结合上述历史经验(如有)，优先检查经验指出的易遗漏项\n"
                f"严格按JSON格式输出。"
            )

            if self.standards:
                doc_keywords = [w for w in doc_name.replace("_", " ").split() if len(w) > 2]
                std_ctx = self.standards.get_context_for_prompt(doc_keywords[:5], max_standards=5)
                if std_ctx:
                    prompt += f"\n\n{std_ctx}"

        sys_prompt = SYSTEM_PROMPTS["universal_extractor"]
        skills = getattr(self, "_skills_prompt", "")
        if skills:
            sys_prompt += f"\n{skills}"

        response = self.llm.chat(
            [{"role": "user", "content": prompt}],
            system=sys_prompt,
        )
        parsed = self._parse_json_from_response(response)
        return parsed if isinstance(parsed, dict) else {"entities": [], "relations": []}

    def build_graph_from_analysis(self, analysis: dict, source_doc: str = ""):
        if not self.ontology:
            return
        id_map = {}
        for ent in analysis.get("entities", []):
            if not isinstance(ent, dict):
                continue
            nid = self.ontology.add_node(
                node_type=ent.get("type", "concept"),
                label=ent.get("label", "未命名"),
                properties=ent.get("properties", {}),
                node_id=ent.get("id"),
                source_doc=source_doc,
            )
            id_map[ent.get("id", nid)] = nid

        for rel in analysis.get("relations", []):
            if not isinstance(rel, dict):
                continue
            src = id_map.get(rel.get("source"))
            tgt = id_map.get(rel.get("target"))
            if src and tgt:
                self.ontology.add_edge(
                    src, tgt,
                    relation=rel.get("relation", "related_to"),
                    strength=rel.get("strength", 0.5),
                )
        self.ontology.save()

    # ----------------------------------------------------------
    #  核心能力2: 安全评估 (ARP4761)
    # ----------------------------------------------------------
    def run_safety_assessment(self, system_name: str = "") -> dict:
        if not self.ontology or not self.ontology.nodes:
            return {"error": "知识图谱为空，无法执行安全评估"}

        related_nodes = []
        for nid, node in self.ontology.nodes.items():
            if (system_name.lower() in node.get("label", "").lower() or
                    node.get("type") in ("aircraft_system", "system_design",
                                         "system_req", "functional_req",
                                         "safety_req", "hazard")):
                related_nodes.append(node)

        exp_context = ""
        if self.experience:
            exp_context = self.experience.get_experience_context(
                self._current_program, analysis_type="safety"
            )

        context = json.dumps(related_nodes[:30], ensure_ascii=False, indent=2)
        prompt = (
            f"请基于以下已知的系统信息执行安全评估分析。\n"
            f"目标系统: {system_name or '全部系统'}\n\n"
        )
        if exp_context:
            prompt += f"{exp_context}\n\n"
        prompt += (
            f"已知实体:\n{context}\n\n"
            f"请完成FHA、DAL分配、安全目标制定。严格按JSON输出。"
        )
        response = self.llm.chat(
            [{"role": "user", "content": prompt}],
            system=SYSTEM_PROMPTS["safety_assessor"],
        )
        parsed = self._parse_json_from_response(response)
        result = parsed if isinstance(parsed, dict) else {
            "fha_results": [], "safety_objectives": [], "dal_allocation": []}

        if self.experience and (result.get("fha_results") or result.get("dal_allocation")):
            try:
                self.experience.extract_from_analysis(
                    result, source_doc=system_name or "safety_assessment",
                    aircraft_program=self._current_program,
                    analysis_type="safety_assessment"
                )
            except Exception:
                pass
        return result

    # ----------------------------------------------------------
    #  核心能力3: V模型追溯完整性检查 (DO-178C)
    # ----------------------------------------------------------
    def check_traceability(self) -> dict:
        if not self.ontology or not self.ontology.nodes:
            return {"error": "知识图谱为空"}

        type_counts = {}
        for nid, node in self.ontology.nodes.items():
            t = node.get("type", "unknown")
            type_counts[t] = type_counts.get(t, 0) + 1

        trace_edges = []
        for edge in self.ontology.edges:
            rel = edge.get("relation", "")
            if rel in ("satisfies", "allocates_to", "decomposes_to",
                       "implements", "traces_to", "covers", "verifies",
                       "tested_by"):
                trace_edges.append({
                    "source": self.ontology.nodes.get(edge["source"], {}).get("label", edge["source"]),
                    "target": self.ontology.nodes.get(edge["target"], {}).get("label", edge["target"]),
                    "relation": rel,
                    "strength": edge.get("strength", 0)
                })

        context = (
            f"节点类型分布:\n{json.dumps(type_counts, ensure_ascii=False, indent=2)}\n\n"
            f"追溯关系({len(trace_edges)}条):\n"
            f"{json.dumps(trace_edges[:40], ensure_ascii=False, indent=2)}\n"
        )
        prompt = (
            f"请基于以下知识图谱信息，检查DO-178C追溯完整性:\n\n{context}\n\n"
            f"检查要点:\n"
            f"1. 需求分解链路完整性(飞机级→系统级→HLR→LLR)\n"
            f"2. 正向追溯(需求→代码)\n"
            f"3. 反向追溯(测试→需求)\n"
            f"4. 孤儿节点识别\n"
            f"5. 派生需求安全评估状态\n"
            f"严格按JSON输出。"
        )
        response = self.llm.chat(
            [{"role": "user", "content": prompt}],
            system=SYSTEM_PROMPTS["v_model_tracer"],
        )
        parsed = self._parse_json_from_response(response)
        if isinstance(parsed, dict):
            return parsed
        return {"trace_chains": [], "orphans": {}, "completeness": {}}

    # ----------------------------------------------------------
    #  核心能力4: 变更影响分析
    # ----------------------------------------------------------
    def analyze_change_impact(self, changed_node_label: str) -> str:
        if not self.ontology or not self.ontology.nodes:
            return "知识图谱为空，无法进行变更影响分析"

        target_nodes = self.ontology.search_nodes(changed_node_label)
        if not target_nodes:
            return f"未在知识图谱中找到与[{changed_node_label}]相关的节点"

        target = target_nodes[0]
        nid = target.get("id", "")
        neighbors = []
        for edge in self.ontology.edges:
            src, tgt = edge["source"], edge["target"]
            if src == nid or tgt == nid:
                other_id = tgt if src == nid else src
                other = self.ontology.nodes.get(other_id, {})
                neighbors.append({
                    "label": other.get("label", ""),
                    "type": other.get("type", ""),
                    "relation": edge.get("relation", ""),
                    "strength": edge.get("strength", 0),
                    "direction": "下游" if src == nid else "上游"
                })

        context = (
            f"变更对象: {target.get('label')} (类型: {target.get('type')})\n\n"
            f"直接关联({len(neighbors)}个):\n"
            f"{json.dumps(neighbors[:30], ensure_ascii=False, indent=2)}\n"
        )
        prompt = (
            f"请基于以下信息进行变更影响分析:\n\n{context}\n\n"
            f"请从上游影响、下游影响、横向影响、安全影响、认证影响五个维度分析。"
        )
        return self.llm.chat(
            [{"role": "user", "content": prompt}],
            system=SYSTEM_PROMPTS["impact_analyzer"],
        )

    # ----------------------------------------------------------
    #  核心能力5: 图谱推理
    # ----------------------------------------------------------
    def reason_on_graph(self) -> str:
        if not self.ontology or not self.ontology.nodes:
            return "知识图谱为空"
        stats = self.ontology.get_statistics()
        missing = self.ontology.suggest_missing_links()
        nextgen = self.ontology.suggest_next_gen()
        clusters = self.ontology.find_clusters()
        bridges = self.ontology.find_bridge_nodes()

        context = (
            f"知识图谱统计:\n{json.dumps(stats, ensure_ascii=False, indent=2)}\n\n"
            f"缺失链接:\n{json.dumps(missing, ensure_ascii=False, indent=2, default=str)}\n\n"
            f"知识簇: {len(clusters)}个 (最大: {clusters[0]['size'] if clusters else 0}节点)\n"
            f"桥接节点: {', '.join(b['label'] for b in bridges[:5])}\n\n"
            f"下一步建议:\n{json.dumps(nextgen, ensure_ascii=False, indent=2)}\n"
        )
        prompt = (
            f"请基于以下知识图谱，以资深适航工程师视角进行深度分析:\n\n{context}\n\n"
            f"请完成:\n"
            f"1. V模型追溯完整性评分\n"
            f"2. 安全评估覆盖率评估\n"
            f"3. 被忽视的风险和隐患\n"
            f"4. 优先级排序的改进建议"
        )
        return self.llm.chat(
            [{"role": "user", "content": prompt}],
            system=SYSTEM_PROMPTS["ontology_reasoner"],
        )

    # ----------------------------------------------------------
    #  核心能力6: 文档分类归档
    # ----------------------------------------------------------
    def classify_document(self, doc_content: str, doc_name: str) -> dict:
        truncated = doc_content[:3000]
        response = self.llm.chat(
            [{"role": "user", "content":
              f"文件名: {doc_name}\n内容:\n{truncated}\n请按民机项目文档体系分类归档(JSON)。"}],
            system=SYSTEM_PROMPTS["document_organizer"],
        )
        parsed = self._parse_json_from_response(response)
        if isinstance(parsed, dict):
            return parsed
        return {"category": "other", "suggested_path": "docs/other",
                "suggested_name": doc_name, "metadata": {}}

    # ----------------------------------------------------------
    #  核心能力7: 上下文对话
    # ----------------------------------------------------------
    def chat_with_context(self, user_message: str, stream: bool = False):
        context_parts = []
        if self.ontology and self.ontology.nodes:
            stats = self.ontology.get_statistics()
            context_parts.append(
                f"知识图谱: {stats['total_nodes']}节点, {stats['total_edges']}边, "
                f"平均关联强度{stats['avg_strength']:.2f}"
            )
            results = self.ontology.search_nodes(user_message[:50])
            if results:
                context_parts.append(
                    "相关知识:\n" + "\n".join(
                        f"- [{r['type']}] {r['label']}" for r in results[:5])
                )

        system = (
            "你是空客/波音民机研制团队的AI助手，集成了以下专业能力：\n"
            "- 需求工程师: 精通DOORS/Polarion需求管理和ARP4754A分解\n"
            "- 安全评估师: 精通ARP4761 FHA/FMEA/FTA/CCA全套安全评估方法\n"
            "- 适航审定员: 精通DO-178C/DO-254认证流程和追溯要求\n"
            "- MBSE架构师: 精通Capella/Arcadia建模方法论\n"
            "- 构型管理员: 精通变更影响分析和配置管理\n"
            "- 知识工程师: 精通IOF/BFO本体框架\n\n"
            "你可以帮助团队：分析文档、构建图谱、安全评估、追溯检查、变更影响分析、"
            "推理发现被忽视的需求和风险、自动归档文档。\n"
            "请用专业但易懂的中文回答。\n"
        )
        if context_parts:
            system += "\n当前上下文:\n" + "\n".join(context_parts)

        if self.experience:
            exp = self.experience.get_experience_context(
                self._current_program, max_entries=8
            )
            if exp:
                system += f"\n\n{exp}"

        if self.standards:
            kw_from_msg = [w for w in user_message.split() if len(w) > 1][:5]
            std_ctx = self.standards.get_context_for_prompt(kw_from_msg, max_standards=4)
            if std_ctx:
                system += f"\n\n{std_ctx}"

        skills = getattr(self, "_skills_prompt", "")
        if skills:
            system += f"\n\n{skills}"

        self.conversation_history.append({"role": "user", "content": user_message})
        history = self.conversation_history[-10:]

        if stream:
            return self.llm.chat_stream(history, system=system)
        else:
            response = self.llm.chat(history, system=system)
            self.conversation_history.append({"role": "assistant", "content": response})
            return response

    # ----------------------------------------------------------
    #  ReqIF导入接口 (DOORS/Polarion互操作)
    # ----------------------------------------------------------
    def import_reqif(self, reqif_path: str) -> dict:
        """解析ReqIF(XML)文件，导入DOORS/Polarion导出的需求"""
        try:
            from lxml import etree
            tree = etree.parse(reqif_path)
            root = tree.getroot()
            ns = {"reqif": "http://www.omg.org/spec/ReqIF/20110401/reqif.xsd"}

            entities = []
            for spec_obj in root.iter():
                tag = etree.QName(spec_obj.tag).localname if isinstance(spec_obj.tag, str) else ""
                if tag == "SPEC-OBJECT":
                    obj_id = spec_obj.get("IDENTIFIER", "")
                    desc = spec_obj.get("DESC", "")
                    long_name = spec_obj.get("LONG-NAME", obj_id)
                    entities.append({
                        "id": obj_id,
                        "type": "system_req",
                        "label": long_name,
                        "properties": {"description": desc, "source": "ReqIF",
                                       "doc_ref": reqif_path}
                    })
            return {"entities": entities, "relations": [], "source": "ReqIF"}
        except Exception as e:
            return {"error": f"ReqIF解析失败: {e}", "entities": [], "relations": []}

    # ----------------------------------------------------------
    #  内部工具
    # ----------------------------------------------------------
    def _parse_json_from_response(self, text: str):
        for pattern in [r'```json\s*([\s\S]*?)\s*```', r'```\s*([\s\S]*?)\s*```',
                        r'(\{[\s\S]*\})', r'(\[[\s\S]*\])']:
            for match in re.findall(pattern, text):
                try:
                    return json.loads(match)
                except json.JSONDecodeError:
                    continue
        return []
