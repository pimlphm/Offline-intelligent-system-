"""
经验积累与审计引擎
===================
核心设计理念:
  - 每次分析自动提炼经验，写入.md文件供人审核
  - 永久经验 vs 临时经验 分级管理
  - 按机型(B787/A320neo/A350等)分文件夹组织
  - 中英文双版自动生成
  - Agent下次分析时自动加载历史经验作为上下文
  - 所有经验可审计、可追溯、可编辑

文件结构:
  知识库/experience/
  ├── _global/                    # 跨型号通用经验
  │   ├── permanent_zh.md         # 永久经验(中文)
  │   ├── permanent_en.md         # 永久经验(英文)
  │   ├── temporary_zh.md         # 临时经验(中文)
  │   ├── temporary_en.md         # 临时经验(英文)
  │   └── experience_index.json   # 索引
  ├── B787/
  │   ├── permanent_zh.md
  │   ├── permanent_en.md
  │   ├── temporary_zh.md
  │   ├── temporary_en.md
  │   └── experience_index.json
  ├── A320neo/
  │   └── ...
  └── summary_report.md           # 全型号审计汇总
"""
import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Optional


EXPERIENCE_PROMPT_ZH = """你是民机适航经验提炼专家。请从本次分析结果中提炼可复用的经验教训。

分析上下文:
{context}

请严格按以下JSON格式输出:
```json
{{
  "permanent": [
    {{
      "title": "经验标题(简洁精确)",
      "category": "safety/traceability/design/certification/test/process/tool",
      "content": "经验详细描述(200字内，可复用的方法论/规律/检查要点)",
      "applicable_standards": ["ARP4761", "DO-178C"],
      "applicable_systems": ["ECS", "FBW"],
      "confidence": 0.85,
      "rationale": "为什么这是永久经验(普适性说明)"
    }}
  ],
  "temporary": [
    {{
      "title": "临时经验标题",
      "category": "safety/traceability/design/certification/test/process/tool",
      "content": "临时经验描述(待验证的观察/假设/特殊情况)",
      "applicable_standards": [],
      "applicable_systems": [],
      "confidence": 0.50,
      "conditions": "在什么条件下此经验成立/失效"
    }}
  ]
}}
```

永久经验判定标准: 基于适航标准的通用规律、多型号验证过的方法论、行业公认的最佳实践
临时经验判定标准: 单次分析中发现的特殊模式、待更多数据验证的假设、特定构型下的观察"""

EXPERIENCE_PROMPT_EN = """You are a civil aircraft airworthiness experience extraction expert.
Extract reusable lessons learned from this analysis.

Analysis context:
{context}

Output strictly in JSON:
```json
{{
  "permanent": [
    {{
      "title_en": "Concise experience title",
      "category": "safety/traceability/design/certification/test/process/tool",
      "content_en": "Detailed description (reusable methodology/pattern/checklist, <200 words)",
      "applicable_standards": ["ARP4761", "DO-178C"],
      "applicable_systems": ["ECS", "FBW"],
      "confidence": 0.85,
      "rationale_en": "Why this is a permanent lesson"
    }}
  ],
  "temporary": [
    {{
      "title_en": "Temporary finding title",
      "category": "safety/traceability/design/certification/test/process/tool",
      "content_en": "Observation to be verified",
      "applicable_standards": [],
      "applicable_systems": [],
      "confidence": 0.50,
      "conditions_en": "Under what conditions this holds/fails"
    }}
  ]
}}
```"""


class ExperienceEntry:
    """单条经验记录"""

    def __init__(self, title_zh: str, title_en: str, category: str,
                 content_zh: str, content_en: str,
                 level: str = "permanent",
                 applicable_standards: list = None,
                 applicable_systems: list = None,
                 confidence: float = 0.5,
                 rationale_zh: str = "", rationale_en: str = "",
                 conditions_zh: str = "", conditions_en: str = "",
                 source_doc: str = "", source_analysis: str = "",
                 aircraft_program: str = "_global",
                 entry_id: str = "", created: str = "",
                 review_status: str = "pending",
                 review_comment: str = "",
                 usage_count: int = 0):
        self.entry_id = entry_id or f"EXP-{datetime.now().strftime('%Y%m%d%H%M%S')}-{id(self) % 10000:04d}"
        self.title_zh = title_zh
        self.title_en = title_en
        self.category = category
        self.content_zh = content_zh
        self.content_en = content_en
        self.level = level
        self.applicable_standards = applicable_standards or []
        self.applicable_systems = applicable_systems or []
        self.confidence = confidence
        self.rationale_zh = rationale_zh
        self.rationale_en = rationale_en
        self.conditions_zh = conditions_zh
        self.conditions_en = conditions_en
        self.source_doc = source_doc
        self.source_analysis = source_analysis
        self.aircraft_program = aircraft_program
        self.created = created or datetime.now().isoformat()
        self.last_updated = datetime.now().isoformat()
        self.review_status = review_status
        self.review_comment = review_comment
        self.usage_count = usage_count

    def to_dict(self) -> dict:
        return {
            "entry_id": self.entry_id,
            "title_zh": self.title_zh,
            "title_en": self.title_en,
            "category": self.category,
            "content_zh": self.content_zh,
            "content_en": self.content_en,
            "level": self.level,
            "applicable_standards": self.applicable_standards,
            "applicable_systems": self.applicable_systems,
            "confidence": self.confidence,
            "rationale_zh": self.rationale_zh,
            "rationale_en": self.rationale_en,
            "conditions_zh": self.conditions_zh,
            "conditions_en": self.conditions_en,
            "source_doc": self.source_doc,
            "source_analysis": self.source_analysis,
            "aircraft_program": self.aircraft_program,
            "created": self.created,
            "last_updated": self.last_updated,
            "review_status": self.review_status,
            "review_comment": self.review_comment,
            "usage_count": self.usage_count,
        }

    @staticmethod
    def from_dict(d: dict) -> "ExperienceEntry":
        return ExperienceEntry(
            title_zh=d.get("title_zh", ""),
            title_en=d.get("title_en", ""),
            category=d.get("category", "process"),
            content_zh=d.get("content_zh", ""),
            content_en=d.get("content_en", ""),
            level=d.get("level", "permanent"),
            applicable_standards=d.get("applicable_standards", []),
            applicable_systems=d.get("applicable_systems", []),
            confidence=d.get("confidence", 0.5),
            rationale_zh=d.get("rationale_zh", ""),
            rationale_en=d.get("rationale_en", ""),
            conditions_zh=d.get("conditions_zh", ""),
            conditions_en=d.get("conditions_en", ""),
            source_doc=d.get("source_doc", ""),
            source_analysis=d.get("source_analysis", ""),
            aircraft_program=d.get("aircraft_program", "_global"),
            entry_id=d.get("entry_id", ""),
            created=d.get("created", ""),
            review_status=d.get("review_status", "pending"),
            review_comment=d.get("review_comment", ""),
            usage_count=d.get("usage_count", 0),
        )


CATEGORY_LABELS = {
    "safety": ("安全评估", "Safety Assessment"),
    "traceability": ("需求追溯", "Requirements Traceability"),
    "design": ("设计架构", "Design & Architecture"),
    "certification": ("适航认证", "Airworthiness Certification"),
    "test": ("验证测试", "Verification & Testing"),
    "process": ("流程管理", "Process Management"),
    "tool": ("工具方法", "Tools & Methods"),
}


class ExperienceEngine:
    """经验积累与审计引擎"""

    def __init__(self, base_dir: str, llm_client=None):
        self.base_dir = Path(base_dir) / "experience"
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.llm = llm_client
        self.entries: dict[str, ExperienceEntry] = {}
        self._load_all_indexes()

    # ----------------------------------------------------------
    #  加载与存储
    # ----------------------------------------------------------
    def _get_program_dir(self, program: str) -> Path:
        d = self.base_dir / self._safe_dirname(program)
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _safe_dirname(self, name: str) -> str:
        safe = re.sub(r'[<>:"/\\|?*]', '_', name.strip())
        return safe or "_global"

    def _index_path(self, program: str) -> Path:
        return self._get_program_dir(program) / "experience_index.json"

    def _load_all_indexes(self):
        self.entries.clear()
        if not self.base_dir.exists():
            return
        for subdir in self.base_dir.iterdir():
            if subdir.is_dir():
                idx = subdir / "experience_index.json"
                if idx.exists():
                    try:
                        with open(idx, "r", encoding="utf-8") as f:
                            data = json.load(f)
                        for d in data:
                            entry = ExperienceEntry.from_dict(d)
                            self.entries[entry.entry_id] = entry
                    except Exception:
                        pass

    def _save_index(self, program: str):
        entries_for_prog = [
            e.to_dict() for e in self.entries.values()
            if e.aircraft_program == program
        ]
        idx_path = self._index_path(program)
        with open(idx_path, "w", encoding="utf-8") as f:
            json.dump(entries_for_prog, f, ensure_ascii=False, indent=2)

    def _save_all(self):
        programs = set(e.aircraft_program for e in self.entries.values())
        programs.add("_global")
        for prog in programs:
            self._save_index(prog)
            self._generate_md_files(prog)

    # ----------------------------------------------------------
    #  经验CRUD
    # ----------------------------------------------------------
    def add_entry(self, entry: ExperienceEntry) -> str:
        self.entries[entry.entry_id] = entry
        self._save_index(entry.aircraft_program)
        self._generate_md_files(entry.aircraft_program)
        return entry.entry_id

    def promote_to_permanent(self, entry_id: str):
        if entry_id in self.entries:
            self.entries[entry_id].level = "permanent"
            self.entries[entry_id].last_updated = datetime.now().isoformat()
            prog = self.entries[entry_id].aircraft_program
            self._save_index(prog)
            self._generate_md_files(prog)

    def set_review_status(self, entry_id: str, status: str, comment: str = ""):
        if entry_id in self.entries:
            self.entries[entry_id].review_status = status
            self.entries[entry_id].review_comment = comment
            self.entries[entry_id].last_updated = datetime.now().isoformat()
            prog = self.entries[entry_id].aircraft_program
            self._save_index(prog)
            self._generate_md_files(prog)

    def increment_usage(self, entry_id: str):
        if entry_id in self.entries:
            self.entries[entry_id].usage_count += 1

    def get_entries_for_program(self, program: str,
                                level: str = None) -> list[ExperienceEntry]:
        results = []
        for e in self.entries.values():
            if e.aircraft_program == program or e.aircraft_program == "_global":
                if level is None or e.level == level:
                    results.append(e)
        results.sort(key=lambda x: (-x.confidence, -x.usage_count))
        return results

    def get_all_programs(self) -> list[str]:
        programs = set()
        for e in self.entries.values():
            programs.add(e.aircraft_program)
        return sorted(programs)

    # ----------------------------------------------------------
    #  从分析结果自动提炼经验
    # ----------------------------------------------------------
    def extract_from_analysis(self, analysis_result: dict,
                              source_doc: str, aircraft_program: str,
                              analysis_type: str = "document") -> list[str]:
        if not self.llm:
            return []

        context = self._build_extraction_context(
            analysis_result, source_doc, analysis_type
        )

        zh_response = self.llm.chat(
            [{"role": "user", "content": EXPERIENCE_PROMPT_ZH.format(context=context)}],
            system="你是民机适航经验提炼专家。只输出JSON。",
        )
        en_response = self.llm.chat(
            [{"role": "user", "content": EXPERIENCE_PROMPT_EN.format(context=context)}],
            system="You are a civil aircraft airworthiness experience expert. Output JSON only.",
        )

        zh_data = self._parse_json(zh_response)
        en_data = self._parse_json(en_response)

        new_ids = []
        zh_perm = zh_data.get("permanent", []) if isinstance(zh_data, dict) else []
        en_perm = en_data.get("permanent", []) if isinstance(en_data, dict) else []
        zh_temp = zh_data.get("temporary", []) if isinstance(zh_data, dict) else []
        en_temp = en_data.get("temporary", []) if isinstance(en_data, dict) else []

        for i, zh_item in enumerate(zh_perm):
            if not isinstance(zh_item, dict):
                continue
            en_item = en_perm[i] if i < len(en_perm) and isinstance(en_perm[i], dict) else {}
            entry = ExperienceEntry(
                title_zh=zh_item.get("title", ""),
                title_en=en_item.get("title_en", zh_item.get("title", "")),
                category=zh_item.get("category", "process"),
                content_zh=zh_item.get("content", ""),
                content_en=en_item.get("content_en", zh_item.get("content", "")),
                level="permanent",
                applicable_standards=zh_item.get("applicable_standards", []),
                applicable_systems=zh_item.get("applicable_systems", []),
                confidence=zh_item.get("confidence", 0.7),
                rationale_zh=zh_item.get("rationale", ""),
                rationale_en=en_item.get("rationale_en", ""),
                source_doc=source_doc,
                source_analysis=analysis_type,
                aircraft_program=aircraft_program,
            )
            if not self._is_duplicate(entry):
                eid = self.add_entry(entry)
                new_ids.append(eid)

        for i, zh_item in enumerate(zh_temp):
            if not isinstance(zh_item, dict):
                continue
            en_item = en_temp[i] if i < len(en_temp) and isinstance(en_temp[i], dict) else {}
            entry = ExperienceEntry(
                title_zh=zh_item.get("title", ""),
                title_en=en_item.get("title_en", zh_item.get("title", "")),
                category=zh_item.get("category", "process"),
                content_zh=zh_item.get("content", ""),
                content_en=en_item.get("content_en", zh_item.get("content", "")),
                level="temporary",
                applicable_standards=zh_item.get("applicable_standards", []),
                applicable_systems=zh_item.get("applicable_systems", []),
                confidence=zh_item.get("confidence", 0.4),
                conditions_zh=zh_item.get("conditions", ""),
                conditions_en=en_item.get("conditions_en", ""),
                source_doc=source_doc,
                source_analysis=analysis_type,
                aircraft_program=aircraft_program,
            )
            if not self._is_duplicate(entry):
                eid = self.add_entry(entry)
                new_ids.append(eid)

        self._save_index(aircraft_program)
        self._generate_md_files(aircraft_program)
        return new_ids

    def _is_duplicate(self, new_entry: ExperienceEntry) -> bool:
        for existing in self.entries.values():
            if (existing.aircraft_program == new_entry.aircraft_program and
                    existing.title_zh == new_entry.title_zh and
                    existing.level == new_entry.level):
                return True
        return False

    def _build_extraction_context(self, result: dict, source_doc: str,
                                   analysis_type: str) -> str:
        parts = [f"分析类型: {analysis_type}", f"源文档: {source_doc}"]
        if isinstance(result, dict):
            entities = result.get("entities", [])
            relations = result.get("relations", [])
            if entities:
                parts.append(f"提取实体: {len(entities)} 个")
                for e in entities[:15]:
                    if isinstance(e, dict):
                        parts.append(f"  [{e.get('type','')}] {e.get('label','')}")
            if relations:
                parts.append(f"提取关系: {len(relations)} 条")
                for r in relations[:10]:
                    if isinstance(r, dict):
                        parts.append(
                            f"  {r.get('source','')} --{r.get('relation','')}-->"
                            f" {r.get('target','')} (强度{r.get('strength',0)})"
                        )
            for key in ("fha_results", "dal_allocation", "safety_objectives",
                        "trace_chains", "orphans", "completeness"):
                if key in result:
                    parts.append(f"{key}: {json.dumps(result[key], ensure_ascii=False)[:500]}")
        return "\n".join(parts)

    # ----------------------------------------------------------
    #  为Agent提供经验上下文 (注入到prompt)
    # ----------------------------------------------------------
    def get_experience_context(self, aircraft_program: str,
                                analysis_type: str = "",
                                max_entries: int = 15) -> str:
        entries = self.get_entries_for_program(aircraft_program)
        if not entries:
            entries = self.get_entries_for_program("_global")
        if not entries:
            return ""

        for e in entries:
            self.increment_usage(e.entry_id)

        perm = [e for e in entries if e.level == "permanent"]
        temp = [e for e in entries if e.level == "temporary"]

        lines = ["[历史经验 - 请在分析中参考以下已积累的经验教训]"]
        if perm:
            lines.append("\n## 永久经验 (已验证的通用规律)")
            for e in perm[:max_entries]:
                status_mark = {"approved": "✓", "rejected": "✗"}.get(
                    e.review_status, "○")
                lines.append(
                    f"- {status_mark} [{e.category}] {e.title_zh}\n"
                    f"  {e.content_zh}\n"
                    f"  适用标准: {', '.join(e.applicable_standards) or '通用'} | "
                    f"适用系统: {', '.join(e.applicable_systems) or '通用'} | "
                    f"置信度: {e.confidence:.0%} | 使用次数: {e.usage_count}"
                )
        if temp:
            lines.append("\n## 临时经验 (待验证的观察)")
            for e in temp[:max_entries - len(perm)]:
                lines.append(
                    f"- ○ [{e.category}] {e.title_zh}\n"
                    f"  {e.content_zh}\n"
                    f"  适用条件: {e.conditions_zh or '待确认'} | "
                    f"置信度: {e.confidence:.0%}"
                )
        return "\n".join(lines)

    # ----------------------------------------------------------
    #  生成.md文件 (中英文双版, 供人审核)
    # ----------------------------------------------------------
    def _generate_md_files(self, program: str):
        prog_dir = self._get_program_dir(program)
        entries = [e for e in self.entries.values() if e.aircraft_program == program]
        perm = [e for e in entries if e.level == "permanent"]
        temp = [e for e in entries if e.level == "temporary"]

        perm.sort(key=lambda x: (x.category, -x.confidence))
        temp.sort(key=lambda x: (x.category, -x.confidence))

        prog_label = program if program != "_global" else "跨型号通用"
        now = datetime.now().strftime("%Y-%m-%d %H:%M")

        # --- 中文版 ---
        self._write_md_zh(prog_dir / "permanent_zh.md", perm, prog_label, now, "永久经验")
        self._write_md_zh(prog_dir / "temporary_zh.md", temp, prog_label, now, "临时经验")

        # --- 英文版 ---
        self._write_md_en(prog_dir / "permanent_en.md", perm, prog_label, now, "Permanent Lessons")
        self._write_md_en(prog_dir / "temporary_en.md", temp, prog_label, now, "Temporary Findings")

    def _write_md_zh(self, path: Path, entries: list, program: str,
                     timestamp: str, level_label: str):
        lines = [
            f"# {program} — {level_label}",
            f"",
            f"> 自动生成时间: {timestamp}",
            f"> 经验条目: {len(entries)} 条",
            f"> 此文件由Agent自动维护，人工审核后标记状态",
            f"",
            f"---",
            f"",
        ]

        by_cat = {}
        for e in entries:
            cat = e.category
            if cat not in by_cat:
                by_cat[cat] = []
            by_cat[cat].append(e)

        for cat, cat_entries in sorted(by_cat.items()):
            cat_zh, _ = CATEGORY_LABELS.get(cat, (cat, cat))
            lines.append(f"## {cat_zh}")
            lines.append("")
            for e in cat_entries:
                status_map = {
                    "approved": "已审核通过",
                    "rejected": "已驳回",
                    "pending": "待审核",
                }
                status = status_map.get(e.review_status, e.review_status)
                lines.append(f"### {e.title_zh}")
                lines.append(f"")
                lines.append(f"- **ID**: `{e.entry_id}`")
                lines.append(f"- **审核状态**: {status}")
                if e.review_comment:
                    lines.append(f"- **审核意见**: {e.review_comment}")
                lines.append(f"- **置信度**: {e.confidence:.0%}")
                lines.append(f"- **适用标准**: {', '.join(e.applicable_standards) or '通用'}")
                lines.append(f"- **适用系统**: {', '.join(e.applicable_systems) or '通用'}")
                lines.append(f"- **来源文档**: {e.source_doc or '—'}")
                lines.append(f"- **分析类型**: {e.source_analysis or '—'}")
                lines.append(f"- **使用次数**: {e.usage_count}")
                lines.append(f"- **创建时间**: {e.created}")
                lines.append(f"- **最后更新**: {e.last_updated}")
                lines.append(f"")
                lines.append(f"**内容**:")
                lines.append(f"")
                lines.append(f"{e.content_zh}")
                lines.append(f"")
                if e.level == "permanent" and e.rationale_zh:
                    lines.append(f"**永久性依据**: {e.rationale_zh}")
                    lines.append(f"")
                if e.level == "temporary" and e.conditions_zh:
                    lines.append(f"**适用条件**: {e.conditions_zh}")
                    lines.append(f"")
                lines.append(f"---")
                lines.append(f"")

        if not entries:
            lines.append(f"_暂无{level_label}。随着分析积累，经验将自动沉淀到此文件。_")
            lines.append("")

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_md_en(self, path: Path, entries: list, program: str,
                     timestamp: str, level_label: str):
        prog_en = program if program != "_global" else "Cross-Program (Global)"
        lines = [
            f"# {prog_en} — {level_label}",
            f"",
            f"> Auto-generated: {timestamp}",
            f"> Entries: {len(entries)}",
            f"> This file is maintained by Agent. Mark review status after human audit.",
            f"",
            f"---",
            f"",
        ]

        by_cat = {}
        for e in entries:
            cat = e.category
            if cat not in by_cat:
                by_cat[cat] = []
            by_cat[cat].append(e)

        for cat, cat_entries in sorted(by_cat.items()):
            _, cat_en = CATEGORY_LABELS.get(cat, (cat, cat))
            lines.append(f"## {cat_en}")
            lines.append("")
            for e in cat_entries:
                status_map = {
                    "approved": "Approved",
                    "rejected": "Rejected",
                    "pending": "Pending Review",
                }
                status = status_map.get(e.review_status, e.review_status)
                lines.append(f"### {e.title_en or e.title_zh}")
                lines.append(f"")
                lines.append(f"- **ID**: `{e.entry_id}`")
                lines.append(f"- **Review Status**: {status}")
                if e.review_comment:
                    lines.append(f"- **Review Comment**: {e.review_comment}")
                lines.append(f"- **Confidence**: {e.confidence:.0%}")
                lines.append(f"- **Applicable Standards**: {', '.join(e.applicable_standards) or 'General'}")
                lines.append(f"- **Applicable Systems**: {', '.join(e.applicable_systems) or 'General'}")
                lines.append(f"- **Source Document**: {e.source_doc or '—'}")
                lines.append(f"- **Analysis Type**: {e.source_analysis or '—'}")
                lines.append(f"- **Usage Count**: {e.usage_count}")
                lines.append(f"- **Created**: {e.created}")
                lines.append(f"- **Last Updated**: {e.last_updated}")
                lines.append(f"")
                lines.append(f"**Content**:")
                lines.append(f"")
                lines.append(f"{e.content_en or e.content_zh}")
                lines.append(f"")
                if e.level == "permanent" and e.rationale_en:
                    lines.append(f"**Rationale**: {e.rationale_en}")
                    lines.append(f"")
                if e.level == "temporary" and e.conditions_en:
                    lines.append(f"**Conditions**: {e.conditions_en}")
                    lines.append(f"")
                lines.append(f"---")
                lines.append(f"")

        if not entries:
            lines.append(f"_No {level_label.lower()} yet. Lessons will accumulate with analysis._")
            lines.append("")

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    # ----------------------------------------------------------
    #  全型号审计汇总报告
    # ----------------------------------------------------------
    def generate_audit_summary(self) -> str:
        programs = self.get_all_programs()
        now = datetime.now().strftime("%Y-%m-%d %H:%M")

        lines_zh = [
            "# 全型号经验审计汇总",
            "",
            f"> 生成时间: {now}",
            f"> 覆盖型号: {len(programs)} 个",
            f"> 总经验条目: {len(self.entries)} 条",
            "",
            "---",
            "",
        ]

        lines_en = [
            "# Cross-Program Experience Audit Summary",
            "",
            f"> Generated: {now}",
            f"> Programs: {len(programs)}",
            f"> Total Entries: {len(self.entries)}",
            "",
            "---",
            "",
        ]

        for prog in programs:
            entries = [e for e in self.entries.values() if e.aircraft_program == prog]
            perm = [e for e in entries if e.level == "permanent"]
            temp = [e for e in entries if e.level == "temporary"]
            approved = [e for e in entries if e.review_status == "approved"]

            prog_label = prog if prog != "_global" else "跨型号通用"
            prog_label_en = prog if prog != "_global" else "Cross-Program (Global)"

            lines_zh.append(f"## {prog_label}")
            lines_zh.append(f"")
            lines_zh.append(f"| 指标 | 数值 |")
            lines_zh.append(f"|------|------|")
            lines_zh.append(f"| 永久经验 | {len(perm)} 条 |")
            lines_zh.append(f"| 临时经验 | {len(temp)} 条 |")
            lines_zh.append(f"| 已审核通过 | {len(approved)} 条 |")
            lines_zh.append(f"| 待审核 | {len(entries) - len(approved)} 条 |")
            if perm:
                avg_conf = sum(e.confidence for e in perm) / len(perm)
                lines_zh.append(f"| 平均置信度 | {avg_conf:.0%} |")
            lines_zh.append(f"")

            if perm:
                lines_zh.append(f"### 永久经验概要")
                for e in perm[:10]:
                    cat_zh, _ = CATEGORY_LABELS.get(e.category, (e.category, e.category))
                    lines_zh.append(f"- [{cat_zh}] {e.title_zh} (置信度{e.confidence:.0%}, 使用{e.usage_count}次)")
                lines_zh.append("")

            lines_en.append(f"## {prog_label_en}")
            lines_en.append(f"")
            lines_en.append(f"| Metric | Value |")
            lines_en.append(f"|--------|-------|")
            lines_en.append(f"| Permanent | {len(perm)} |")
            lines_en.append(f"| Temporary | {len(temp)} |")
            lines_en.append(f"| Approved | {len(approved)} |")
            lines_en.append(f"| Pending | {len(entries) - len(approved)} |")
            lines_en.append(f"")

            if perm:
                lines_en.append(f"### Permanent Lessons Summary")
                for e in perm[:10]:
                    _, cat_en = CATEGORY_LABELS.get(e.category, (e.category, e.category))
                    lines_en.append(f"- [{cat_en}] {e.title_en or e.title_zh} ({e.confidence:.0%}, used {e.usage_count}x)")
                lines_en.append("")

        zh_path = self.base_dir / "audit_summary_zh.md"
        en_path = self.base_dir / "audit_summary_en.md"

        with open(zh_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines_zh))
        with open(en_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines_en))

        return str(zh_path)

    # ----------------------------------------------------------
    #  工具方法
    # ----------------------------------------------------------
    def _parse_json(self, text: str):
        for pattern in [r'```json\s*([\s\S]*?)\s*```', r'```\s*([\s\S]*?)\s*```',
                        r'(\{[\s\S]*\})', r'(\[[\s\S]*\])']:
            for match in re.findall(pattern, text):
                try:
                    return json.loads(match)
                except json.JSONDecodeError:
                    continue
        return {}

    def get_statistics(self) -> dict:
        programs = self.get_all_programs()
        total_perm = sum(1 for e in self.entries.values() if e.level == "permanent")
        total_temp = sum(1 for e in self.entries.values() if e.level == "temporary")
        approved = sum(1 for e in self.entries.values() if e.review_status == "approved")
        return {
            "total_entries": len(self.entries),
            "permanent": total_perm,
            "temporary": total_temp,
            "approved": approved,
            "pending": len(self.entries) - approved,
            "programs": programs,
            "program_count": len(programs),
        }
