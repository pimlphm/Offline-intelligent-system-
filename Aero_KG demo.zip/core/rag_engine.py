"""
RAG (Retrieval-Augmented Generation) 引擎
==========================================
功能:
  - 文档分块 + TF-IDF向量化 (纯本地, 无需外部embedding服务)
  - BM25 + 余弦相似度 混合检索
  - 检索增强问答: 先检索相关文档段落, 再结合LLM回答
  - 支持增量添加文档
"""
import re
import math
import json
import hashlib
from pathlib import Path
from collections import Counter, defaultdict
from typing import List, Optional


class TextChunk:
    __slots__ = ("doc_name", "chunk_id", "text", "tokens", "tf")

    def __init__(self, doc_name: str, chunk_id: int, text: str):
        self.doc_name = doc_name
        self.chunk_id = chunk_id
        self.text = text
        self.tokens = _tokenize(text)
        self.tf = Counter(self.tokens)


def _tokenize(text: str) -> list:
    text = text.lower()
    cjk = re.findall(r'[\u4e00-\u9fff\u3400-\u4dbf]+', text)
    cjk_chars = []
    for seg in cjk:
        cjk_chars.extend(list(seg))
        for i in range(len(seg) - 1):
            cjk_chars.append(seg[i:i+2])
    ascii_tokens = re.findall(r'[a-z0-9][\w\-\.]*[a-z0-9]|[a-z0-9]', text)
    return ascii_tokens + cjk_chars


def _split_text(text: str, chunk_size: int = 512, overlap: int = 64) -> list:
    """按字符数分块, 带重叠"""
    paragraphs = re.split(r'\n{2,}', text)
    chunks = []
    buf = ""
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(buf) + len(para) > chunk_size and buf:
            chunks.append(buf)
            tail = buf[-overlap:] if overlap else ""
            buf = tail + "\n" + para
        else:
            buf = (buf + "\n" + para).strip() if buf else para
    if buf.strip():
        chunks.append(buf.strip())
    if not chunks and text.strip():
        chunks = [text[:chunk_size]]
    return chunks


class RAGEngine:
    """纯本地 RAG 引擎 (TF-IDF + BM25)"""

    def __init__(self, persist_path: str = ""):
        self.chunks: List[TextChunk] = []
        self.df = Counter()
        self.doc_names = set()
        self._persist_path = persist_path
        if persist_path:
            self._load_index()

    @property
    def total_chunks(self):
        return len(self.chunks)

    @property
    def total_docs(self):
        return len(self.doc_names)

    def add_document(self, doc_name: str, text: str,
                     chunk_size: int = 512, overlap: int = 64):
        if doc_name in self.doc_names:
            return 0
        parts = _split_text(text, chunk_size, overlap)
        start_id = len(self.chunks)
        for i, part in enumerate(parts):
            chunk = TextChunk(doc_name, start_id + i, part)
            self.chunks.append(chunk)
            unique_tokens = set(chunk.tokens)
            for tok in unique_tokens:
                self.df[tok] += 1
        self.doc_names.add(doc_name)
        if self._persist_path:
            self._save_index()
        return len(parts)

    def search(self, query: str, top_k: int = 5,
               min_score: float = 0.01) -> list:
        q_tokens = _tokenize(query)
        if not q_tokens or not self.chunks:
            return []

        N = len(self.chunks)
        k1, b = 1.5, 0.75
        avg_dl = sum(len(c.tokens) for c in self.chunks) / max(N, 1)

        scores = []
        for chunk in self.chunks:
            score = 0.0
            dl = len(chunk.tokens)
            for qt in q_tokens:
                tf = chunk.tf.get(qt, 0)
                df = self.df.get(qt, 0)
                if tf == 0 or df == 0:
                    continue
                idf = math.log((N - df + 0.5) / (df + 0.5) + 1.0)
                tf_norm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / avg_dl))
                score += idf * tf_norm
            if score >= min_score:
                scores.append((score, chunk))

        scores.sort(key=lambda x: -x[0])
        results = []
        for score, chunk in scores[:top_k]:
            results.append({
                "doc_name": chunk.doc_name,
                "chunk_id": chunk.chunk_id,
                "text": chunk.text,
                "score": round(score, 4),
            })
        return results

    def build_context(self, query: str, top_k: int = 3,
                      max_chars: int = 3000) -> str:
        results = self.search(query, top_k=top_k)
        if not results:
            return ""
        parts = []
        total = 0
        for r in results:
            snippet = r["text"]
            if total + len(snippet) > max_chars:
                snippet = snippet[:max_chars - total]
            parts.append(f"[来源: {r['doc_name']}]\n{snippet}")
            total += len(snippet)
            if total >= max_chars:
                break
        return "\n\n---\n\n".join(parts)

    def get_statistics(self) -> dict:
        return {
            "total_docs": self.total_docs,
            "total_chunks": self.total_chunks,
            "vocab_size": len(self.df),
            "doc_names": sorted(self.doc_names),
        }

    def _save_index(self):
        if not self._persist_path:
            return
        Path(self._persist_path).parent.mkdir(parents=True, exist_ok=True)
        data = {
            "doc_names": sorted(self.doc_names),
            "chunks": [
                {"doc": c.doc_name, "id": c.chunk_id, "text": c.text}
                for c in self.chunks
            ],
        }
        with open(self._persist_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)

    def _load_index(self):
        p = Path(self._persist_path)
        if not p.exists():
            return
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.doc_names = set(data.get("doc_names", []))
            for item in data.get("chunks", []):
                chunk = TextChunk(item["doc"], item["id"], item["text"])
                self.chunks.append(chunk)
                for tok in set(chunk.tokens):
                    self.df[tok] += 1
        except Exception:
            pass
