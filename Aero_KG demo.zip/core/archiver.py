"""
文档自动归档整理模块
功能：
  - 监控文档目录变化
  - 自动分类并归档文档
  - 维护归档日志
"""
import os
import shutil
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


CATEGORY_DIRS = {
    "requirement": "需求文档",
    "design": "设计文档",
    "code": "代码文档",
    "test": "测试文档",
    "standard": "标准规范",
    "meeting": "会议纪要",
    "other": "其他文档",
}


class ArchiveLog:

    def __init__(self, log_path: str):
        self.log_path = log_path
        self.entries = []
        self._load()

    def _load(self):
        if os.path.exists(self.log_path):
            try:
                with open(self.log_path, "r", encoding="utf-8") as f:
                    self.entries = json.load(f)
            except (json.JSONDecodeError, IOError):
                self.entries = []

    def add_entry(self, original_path: str, archived_path: str,
                  category: str, metadata: dict = None):
        entry = {
            "original_path": original_path,
            "archived_path": archived_path,
            "category": category,
            "metadata": metadata or {},
            "timestamp": datetime.now().isoformat(),
        }
        self.entries.append(entry)
        self._save()

    def _save(self):
        os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
        with open(self.log_path, "w", encoding="utf-8") as f:
            json.dump(self.entries, f, ensure_ascii=False, indent=2)

    def get_recent(self, n: int = 20) -> list:
        return self.entries[-n:]


class DocumentArchiver:

    def __init__(self, watch_dir: str, archive_dir: str,
                 agent=None, supported_exts: list = None):
        self.watch_dir = Path(watch_dir).resolve()
        self.archive_dir = Path(archive_dir).resolve()
        self.agent = agent
        self.supported_exts = supported_exts or [
            ".pdf", ".docx", ".doc", ".txt", ".md",
            ".xlsx", ".xls", ".csv", ".pptx",
            ".html", ".xml", ".json", ".yaml", ".yml",
        ]
        self.log = ArchiveLog(str(self.archive_dir / "archive_log.json"))
        self._ensure_dirs()

    def _ensure_dirs(self):
        self.archive_dir.mkdir(parents=True, exist_ok=True)
        for subdir in CATEGORY_DIRS.values():
            (self.archive_dir / subdir).mkdir(exist_ok=True)

    def archive_file(self, file_path: str,
                     classification: dict = None) -> Optional[str]:
        """归档单个文件"""
        src = Path(file_path)
        if not src.exists():
            return None
        if src.suffix.lower() not in self.supported_exts:
            return None

        if classification is None:
            category = "other"
            metadata = {}
        else:
            category = classification.get("category", "other")
            metadata = classification.get("metadata", {})

        subdir = CATEGORY_DIRS.get(category, "其他文档")
        dest_dir = self.archive_dir / subdir
        dest_dir.mkdir(exist_ok=True)

        suggested_name = classification.get("suggested_name") if classification else None
        dest_name = suggested_name or src.name
        dest = dest_dir / dest_name

        counter = 1
        while dest.exists():
            stem = Path(dest_name).stem
            suffix = Path(dest_name).suffix
            dest = dest_dir / f"{stem}_{counter}{suffix}"
            counter += 1

        shutil.copy2(str(src), str(dest))
        self.log.add_entry(str(src), str(dest), category, metadata)
        return str(dest)

    def auto_archive_directory(self, callback=None) -> list:
        """自动归档目录中所有文件"""
        from .doc_parser import parse_document
        results = []
        for root, _, files in os.walk(str(self.watch_dir)):
            if str(self.archive_dir) in root:
                continue
            for fname in files:
                fpath = os.path.join(root, fname)
                ext = Path(fpath).suffix.lower()
                if ext not in self.supported_exts:
                    continue
                classification = None
                if self.agent:
                    try:
                        doc = parse_document(fpath)
                        if doc and doc["content"] and "[解析失败" not in doc["content"]:
                            classification = self.agent.classify_document(
                                doc["content"], fname
                            )
                    except Exception:
                        pass
                archived = self.archive_file(fpath, classification)
                if archived:
                    result = {
                        "original": fpath,
                        "archived": archived,
                        "classification": classification,
                    }
                    results.append(result)
                    if callback:
                        callback(result)
        return results


class DocWatchHandler(FileSystemEventHandler):
    """文件系统监控处理器"""

    def __init__(self, archiver: DocumentArchiver, callback=None):
        self.archiver = archiver
        self.callback = callback
        self._pending = {}

    def on_created(self, event):
        if event.is_directory:
            return
        self._pending[event.src_path] = time.time()

    def on_modified(self, event):
        if event.is_directory:
            return
        if event.src_path in self._pending:
            elapsed = time.time() - self._pending[event.src_path]
            if elapsed > 2:
                del self._pending[event.src_path]
                self._process_file(event.src_path)

    def _process_file(self, file_path: str):
        from .doc_parser import parse_document
        classification = None
        if self.archiver.agent:
            try:
                doc = parse_document(file_path)
                if doc and doc["content"]:
                    classification = self.archiver.agent.classify_document(
                        doc["content"], Path(file_path).name
                    )
            except Exception:
                pass
        archived = self.archiver.archive_file(file_path, classification)
        if archived and self.callback:
            self.callback({
                "original": file_path,
                "archived": archived,
                "classification": classification,
            })


class DirectoryWatcher:

    def __init__(self, archiver: DocumentArchiver, callback=None):
        self.archiver = archiver
        self.handler = DocWatchHandler(archiver, callback)
        self.observer = Observer()
        self.running = False

    def start(self):
        self.observer.schedule(
            self.handler, str(self.archiver.watch_dir), recursive=True
        )
        self.observer.start()
        self.running = True

    def stop(self):
        if self.running:
            self.observer.stop()
            self.observer.join()
            self.running = False
