"""
民机适航标准库
===================
涵盖中(CAAC)、美(FAA)、欧(EASA)三大适航当局的完整开发标准体系。
标准库按层级组织: 适航当局 → 标准领域 → 具体标准 → 条款/章节。

每条标准记录包含:
  - 中英文标题/描述
  - 适用范围
  - 与其他标准的交叉引用
  - 关键条款摘要
  - DAL相关性
  - 在项目中的使用频次

文件结构:
  知识库/standards/
  ├── standards_db.json           # 完整标准数据库
  ├── FAA/                        # 美国FAA标准详情
  │   ├── DO-178C.md
  │   ├── DO-254.md
  │   └── ...
  ├── EASA/                       # 欧洲EASA标准详情
  │   ├── CS-25.md
  │   └── ...
  ├── CAAC/                       # 中国CAAC标准详情
  │   ├── CCAR-25.md
  │   └── ...
  └── cross_reference.md          # 三方标准交叉引用表
"""
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional


# ============================================================
#  标准数据库: 中/美/欧 完整体系
# ============================================================

STANDARDS_DATABASE = {

    # ========================================================
    #  FAA (美国联邦航空管理局) 标准体系
    # ========================================================
    "FAA": {
        "authority_zh": "美国联邦航空管理局",
        "authority_en": "Federal Aviation Administration",
        "country": "美国",
        "standards": {
            # --- 适航规章 ---
            "14CFR25": {
                "id": "14 CFR Part 25",
                "title_zh": "运输类飞机适航标准",
                "title_en": "Airworthiness Standards: Transport Category Airplanes",
                "category": "airworthiness_regulation",
                "scope_zh": "运输类飞机型号合格审定的最低安全标准",
                "scope_en": "Minimum safety standards for type certification of transport category airplanes",
                "key_sections": {
                    "25.1309": {
                        "title_zh": "设备、系统和安装",
                        "title_en": "Equipment, Systems, and Installations",
                        "content_zh": "要求系统设计使得单一失效不会导致灾难性后果。"
                                      "灾难性失效概率<1×10⁻⁹/飞行小时。"
                                      "建立失效严重性分类: 灾难/危险/重大/轻微/无影响。",
                        "dal_relevance": "定义了DAL分配的基础框架",
                    },
                    "25.671": {
                        "title_zh": "飞行控制系统通则",
                        "title_en": "General (Flight Controls)",
                        "content_zh": "飞行控制系统应确保在正常和故障条件下安全飞行和着陆。",
                    },
                    "25.831": {
                        "title_zh": "通风",
                        "title_en": "Ventilation",
                        "content_zh": "座舱新鲜空气流量不低于4.7升/秒/人。CO₂浓度限制。",
                    },
                    "25.841": {
                        "title_zh": "增压座舱",
                        "title_en": "Pressurized Cabins",
                        "content_zh": "正常运行时座舱高度不超过8000英尺(2438米)。",
                    },
                    "25.981": {
                        "title_zh": "燃油箱点火防护",
                        "title_en": "Fuel Tank Ignition Prevention",
                        "content_zh": "燃油箱区域不得存在电弧、热源等点火源。",
                    },
                    "25.1353": {
                        "title_zh": "电气设备和安装",
                        "title_en": "Electrical Equipment and Installations",
                        "content_zh": "电气系统设计、安装和维护应防止危险。",
                    },
                    "25.1703-1733": {
                        "title_zh": "电气线路互联系统(EWIS)",
                        "title_en": "Electrical Wiring Interconnection System",
                        "content_zh": "EWIS作为型号设计的一部分，需满足防火、分离、标识等要求。",
                    },
                },
                "cross_references": ["CS-25", "CCAR-25"],
            },

            # --- 软件标准 ---
            "DO-178C": {
                "id": "DO-178C",
                "title_zh": "机载系统和设备中的软件考虑",
                "title_en": "Software Considerations in Airborne Systems and Equipment Certification",
                "category": "software_certification",
                "publisher": "RTCA",
                "year": 2011,
                "scope_zh": "机载软件开发和验证的适航认证指南。定义DAL A~E五级软件开发保证等级，"
                            "规定了从计划、需求、设计、编码、集成到验证的完整生命周期活动和目标。",
                "scope_en": "Guidance for airborne software development and verification certification. "
                            "Defines DAL A-E and full lifecycle objectives.",
                "key_sections": {
                    "Section 4": {
                        "title_zh": "软件计划过程",
                        "title_en": "Software Planning Process",
                        "content_zh": "制定PSAC、SDP、SVP、SCMP、SQAP五大计划文档。",
                    },
                    "Section 5": {
                        "title_zh": "软件开发过程",
                        "title_en": "Software Development Processes",
                        "content_zh": "需求过程(5.1)、设计过程(5.2)、编码过程(5.3)、集成过程(5.4)。"
                                      "高层需求(HLR)→低层需求(LLR)→源代码。",
                    },
                    "Section 6": {
                        "title_zh": "软件验证过程",
                        "title_en": "Software Verification Process",
                        "content_zh": "需求审查、设计审查、代码审查、测试(需求级+结构覆盖)。"
                                      "DAL A要求MC/DC覆盖。6.3.4条: 派生需求需追溯和安全评估。",
                    },
                    "Section 11": {
                        "title_zh": "软件生命周期数据",
                        "title_en": "Software Life Cycle Data",
                        "content_zh": "SRS、SDD、源代码、SVD、STR、SAS等交付物清单。",
                    },
                    "DAL_objectives": {
                        "title_zh": "各DAL等级目标数",
                        "content_zh": "DAL A: 71个目标 | DAL B: 69个 | DAL C: 62个 | DAL D: 26个 | DAL E: 无",
                    },
                    "SOI_reviews": {
                        "title_zh": "阶段审查节点",
                        "content_zh": "SOI#1计划评审 → SOI#2开发评审 → SOI#3验证评审 → SOI#4认证评审",
                    },
                },
                "supplements": ["DO-330(工具鉴定)", "DO-331(基于模型)", "DO-332(面向对象)", "DO-333(形式化方法)"],
                "cross_references": ["ED-12C", "CTSO-C153"],
            },

            "DO-254": {
                "id": "DO-254",
                "title_zh": "机载电子硬件的设计保证指南",
                "title_en": "Design Assurance Guidance for Airborne Electronic Hardware",
                "category": "hardware_certification",
                "publisher": "RTCA",
                "year": 2000,
                "scope_zh": "可编程逻辑器件(FPGA/CPLD/ASIC)等机载电子硬件的开发保证。",
                "key_sections": {
                    "Planning": {"content_zh": "硬件计划(PHAC)、硬件方面认证计划。"},
                    "Design": {"content_zh": "概念设计、详细设计、HDL编码、综合、实现。"},
                    "Verification": {"content_zh": "需求验证、设计验证、功能验证、时序分析。"},
                },
                "cross_references": ["ED-80"],
            },

            # --- 安全评估标准 ---
            "ARP4754A": {
                "id": "ARP4754A",
                "title_zh": "民用飞机和系统研制指南",
                "title_en": "Guidelines for Development of Civil Aircraft and Systems",
                "category": "system_development",
                "publisher": "SAE International",
                "year": 2010,
                "scope_zh": "民用飞机和系统研制的V模型生命周期指南。覆盖从飞机级功能到系统/子系统的"
                            "需求分解、设计综合、集成验证的全流程。定义了研制保证等级(DAL)分配。",
                "key_sections": {
                    "V-Model": {
                        "title_zh": "V模型生命周期",
                        "content_zh": "左半: 飞机功能→系统需求→子系统需求(分解)\n"
                                      "右半: 子系统验证→系统确认→飞机认证(集成)",
                    },
                    "DAL_Assignment": {
                        "title_zh": "DAL等级分配",
                        "content_zh": "基于FHA失效严重性和概率分配: "
                                      "灾难→DAL A | 危险→DAL B | 重大→DAL C | 轻微→DAL D",
                    },
                    "Req_Capture": {
                        "title_zh": "需求获取与分解",
                        "content_zh": "飞机级需求→系统级需求→子系统需求→HLR→LLR的逐层分解与追溯。",
                    },
                },
                "cross_references": ["ARP4761", "ED-79A"],
            },

            "ARP4761": {
                "id": "ARP4761",
                "title_zh": "安全评估方法和指南",
                "title_en": "Guidelines and Methods for Conducting the Safety Assessment Process on Civil Airborne Systems and Equipment",
                "category": "safety_assessment",
                "publisher": "SAE International",
                "year": 1996,
                "scope_zh": "民机安全评估全套方法: FHA(功能危险评估)、PSSA(初步系统安全评估)、"
                            "SSA(系统安全评估)、CCA(共因分析)。包含FTA/FMEA/DD/MA等分析技术。",
                "key_sections": {
                    "FHA": {
                        "title_zh": "功能危险评估",
                        "title_en": "Functional Hazard Assessment",
                        "content_zh": "识别系统功能失效状态，分类严重等级(灾难/危险/重大/轻微/无影响)，"
                                      "分配概率目标和DAL等级。必须覆盖全飞行阶段。",
                    },
                    "PSSA": {
                        "title_zh": "初步系统安全评估",
                        "title_en": "Preliminary System Safety Assessment",
                        "content_zh": "在系统架构设计阶段进行故障树分析(FTA)，分解安全目标到子系统。",
                    },
                    "SSA": {
                        "title_zh": "系统安全评估",
                        "title_en": "System Safety Assessment",
                        "content_zh": "验证实际设计满足安全目标。FMEA(失效模式与影响分析)自底向上验证。",
                    },
                    "CCA": {
                        "title_zh": "共因分析",
                        "title_en": "Common Cause Analysis",
                        "content_zh": "ZSA(区域安全分析)、PRA(特殊风险分析)、CMA(共模分析)。"
                                      "识别可能导致多个独立系统同时失效的共同原因。",
                    },
                },
                "cross_references": ["ARP4754A", "ED-135"],
            },

            # --- 环境与EMC ---
            "DO-160G": {
                "id": "DO-160G",
                "title_zh": "机载设备环境条件和试验程序",
                "title_en": "Environmental Conditions and Test Procedures for Airborne Equipment",
                "category": "environmental_test",
                "publisher": "RTCA",
                "year": 2010,
                "scope_zh": "定义机载设备的环境鉴定试验: 温度、振动、冲击、湿度、高度、"
                            "电源瞬态(Section 16)、雷击(Section 22)、HIRF(Section 20)等。",
                "key_sections": {
                    "Section 16": {"content_zh": "供电输入: 正常/异常/应急条件下的电压/频率/瞬态要求。"},
                    "Section 20": {"content_zh": "射频敏感度(HIRF): 抗辐射场强要求。"},
                    "Section 22": {"content_zh": "雷击: 直接/间接雷击波形和能量等级。"},
                },
                "cross_references": ["ED-14G"],
            },

            # --- 数据总线/航电 ---
            "ARINC_653": {
                "id": "ARINC 653",
                "title_zh": "航电应用标准软件接口(APEX)",
                "title_en": "Avionics Application Standard Software Interface",
                "category": "avionics_standard",
                "publisher": "AEEC / SAE ITC",
                "scope_zh": "IMA(综合模块化航电)的分区操作系统标准。定义时间和空间分区，"
                            "保证不同DAL等级的软件在同一硬件上运行的安全隔离。",
                "cross_references": ["DO-297"],
            },

            "DO-297": {
                "id": "DO-297",
                "title_zh": "IMA综合模块化航电开发指南",
                "title_en": "Integrated Modular Avionics Development Guidance and Certification Considerations",
                "category": "avionics_standard",
                "publisher": "RTCA",
                "scope_zh": "IMA系统的开发、验证和认证指南。模块化可更换的航电架构。",
                "cross_references": ["ARINC 653", "ED-124"],
            },

            "DO-326A": {
                "id": "DO-326A",
                "title_zh": "机载信息安全过程规范",
                "title_en": "Airworthiness Security Process Specification",
                "category": "cybersecurity",
                "publisher": "RTCA",
                "year": 2014,
                "scope_zh": "机载系统网络安全评估。威胁分析、风险评估、安全需求制定。",
                "cross_references": ["ED-202A"],
            },
        },
    },

    # ========================================================
    #  EASA (欧洲航空安全局) 标准体系
    # ========================================================
    "EASA": {
        "authority_zh": "欧洲航空安全局",
        "authority_en": "European Union Aviation Safety Agency",
        "country": "欧盟",
        "standards": {
            "CS-25": {
                "id": "CS-25",
                "title_zh": "大型飞机认证规范",
                "title_en": "Certification Specifications for Large Aeroplanes",
                "category": "airworthiness_regulation",
                "scope_zh": "对应FAA 14 CFR Part 25。欧洲大型飞机型号合格审定标准。"
                            "条款编号与FAA基本对应(CS 25.1309 ↔ 14 CFR 25.1309)。",
                "key_sections": {
                    "CS 25.1309": {
                        "title_zh": "设备、系统和安装",
                        "content_zh": "与FAR 25.1309等效。系统安全性要求和失效概率目标。",
                    },
                    "AMC 25.1309": {
                        "title_zh": "可接受的符合性方法",
                        "content_zh": "提供25.1309条款的详细符合性指南(原JAR 25.1309)。"
                                      "定量安全评估方法、失效分类标准。",
                    },
                },
                "cross_references": ["14CFR25", "CCAR-25"],
            },

            "ED-12C": {
                "id": "ED-12C",
                "title_zh": "机载系统和设备中的软件考虑",
                "title_en": "Software Considerations in Airborne Systems and Equipment Certification",
                "category": "software_certification",
                "publisher": "EUROCAE",
                "scope_zh": "DO-178C的欧洲等效文件。EASA认可的软件适航标准。内容与DO-178C完全一致。",
                "cross_references": ["DO-178C"],
                "note_zh": "ED-12C与DO-178C技术内容完全相同，是中欧联合制定的双标准号文件。",
            },

            "ED-80": {
                "id": "ED-80",
                "title_zh": "机载电子硬件的设计保证指南",
                "title_en": "Design Assurance Guidance for Airborne Electronic Hardware",
                "category": "hardware_certification",
                "publisher": "EUROCAE",
                "scope_zh": "DO-254的欧洲等效文件。",
                "cross_references": ["DO-254"],
            },

            "ED-79A": {
                "id": "ED-79A",
                "title_zh": "民用飞机和系统研制指南",
                "title_en": "Guidelines for Development of Civil Aircraft and Systems",
                "category": "system_development",
                "publisher": "EUROCAE",
                "scope_zh": "ARP4754A的EASA认可等效文件。",
                "cross_references": ["ARP4754A"],
            },

            "ED-135": {
                "id": "ED-135",
                "title_zh": "安全评估方法和指南",
                "title_en": "Guidelines and Methods for Conducting the Safety Assessment Process",
                "category": "safety_assessment",
                "publisher": "EUROCAE",
                "scope_zh": "ARP4761的EASA认可等效文件。",
                "cross_references": ["ARP4761"],
            },

            "ED-14G": {
                "id": "ED-14G",
                "title_zh": "机载设备环境条件和试验程序",
                "title_en": "Environmental Conditions and Test Procedures for Airborne Equipment",
                "category": "environmental_test",
                "publisher": "EUROCAE",
                "scope_zh": "DO-160G的欧洲等效文件。",
                "cross_references": ["DO-160G"],
            },

            "ED-202A": {
                "id": "ED-202A",
                "title_zh": "机载信息安全过程规范",
                "title_en": "Airworthiness Security Process Specification",
                "category": "cybersecurity",
                "publisher": "EUROCAE",
                "scope_zh": "DO-326A的欧洲等效文件。机载系统网络安全。",
                "cross_references": ["DO-326A"],
            },

            "ED-124": {
                "id": "ED-124",
                "title_zh": "IMA综合模块化航电开发指南",
                "category": "avionics_standard",
                "publisher": "EUROCAE",
                "scope_zh": "DO-297的欧洲等效文件。",
                "cross_references": ["DO-297"],
            },
        },
    },

    # ========================================================
    #  CAAC (中国民用航空局) 标准体系
    # ========================================================
    "CAAC": {
        "authority_zh": "中国民用航空局",
        "authority_en": "Civil Aviation Administration of China",
        "country": "中国",
        "standards": {
            "CCAR-25": {
                "id": "CCAR-25",
                "title_zh": "运输类飞机适航标准",
                "title_en": "Airworthiness Standards for Transport Category Aeroplanes",
                "category": "airworthiness_regulation",
                "scope_zh": "中国运输类飞机型号合格审定标准。基本对照FAR 25/CS-25。"
                            "适用于C919、ARJ21、C929等国产民机型号审定。",
                "key_sections": {
                    "CCAR 25.1309": {
                        "title_zh": "设备、系统和安装",
                        "content_zh": "与FAR 25.1309 / CS 25.1309等效。定义失效概率目标和安全性分类。"
                                      "适用于C919等国产大飞机。",
                    },
                    "CCAR 25.1301-25.1337": {
                        "title_zh": "设备通则和具体要求",
                        "content_zh": "各类机载设备的功能和安装要求。",
                    },
                },
                "cross_references": ["14CFR25", "CS-25"],
                "note_zh": "CCAR-25与FAR 25高度一致，但部分条款结合中国运行环境有差异。"
                           "C919型号审定同时满足CCAR-25和FAR 25。",
            },

            "CTSO-C153": {
                "id": "CTSO-C153",
                "title_zh": "中国技术标准规定: 机载软件",
                "title_en": "Chinese Technical Standard Order: Airborne Software",
                "category": "software_certification",
                "scope_zh": "CAAC对DO-178C的认可技术标准。要求国产民机软件按DO-178C标准开发。",
                "cross_references": ["DO-178C", "ED-12C"],
            },

            "AC-25.1309": {
                "id": "AC-25.1309-1A",
                "title_zh": "运输类飞机系统安全评估咨询通告",
                "title_en": "Advisory Circular: System Safety Assessment for Transport Category Airplanes",
                "category": "safety_assessment",
                "scope_zh": "CAAC关于CCAR 25.1309的详细符合性指南。参照FAA AC 25.1309和ARP4761。",
                "cross_references": ["ARP4761", "ARP4754A"],
            },

            "AC-25-19": {
                "id": "AC-25-19",
                "title_zh": "机载电子硬件研制保证指南咨询通告",
                "category": "hardware_certification",
                "scope_zh": "CAAC关于DO-254应用的咨询通告。",
                "cross_references": ["DO-254", "ED-80"],
            },

            "AC-21-AA-2018-58": {
                "id": "AC-21-AA-2018-58",
                "title_zh": "民用飞机和系统研制指南咨询通告",
                "category": "system_development",
                "scope_zh": "CAAC关于ARP4754A应用的指南，适用于国产大飞机系统级研制。",
                "cross_references": ["ARP4754A", "ED-79A"],
            },

            "MH_T_0028": {
                "id": "MH/T 0028",
                "title_zh": "民用航空器机载软件适航审定程序",
                "category": "software_certification",
                "scope_zh": "规定CAAC对机载软件适航审定的程序和要求。"
                            "定义了软件SOI审查(SOI#1~#4)的中国具体实施要求。",
                "cross_references": ["DO-178C"],
            },
        },
    },
}


# ============================================================
#  标准类别中英文标签
# ============================================================
CATEGORY_LABELS = {
    "airworthiness_regulation": ("适航规章", "Airworthiness Regulations"),
    "software_certification": ("软件适航", "Software Certification"),
    "hardware_certification": ("硬件适航", "Hardware Certification"),
    "system_development": ("系统研制", "System Development"),
    "safety_assessment": ("安全评估", "Safety Assessment"),
    "environmental_test": ("环境试验", "Environmental Testing"),
    "avionics_standard": ("航电标准", "Avionics Standards"),
    "cybersecurity": ("信息安全", "Cybersecurity"),
}


class StandardsLibrary:
    """适航标准库引擎"""

    def __init__(self, base_dir: str):
        self.base_dir = Path(base_dir) / "standards"
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.db = STANDARDS_DATABASE
        self._generate_all_files()

    # ----------------------------------------------------------
    #  查询接口
    # ----------------------------------------------------------
    def search(self, keyword: str) -> list[dict]:
        results = []
        kw = keyword.lower()
        for authority, auth_data in self.db.items():
            for std_key, std in auth_data.get("standards", {}).items():
                score = 0
                if kw in std.get("id", "").lower():
                    score += 10
                if kw in std.get("title_zh", "").lower():
                    score += 5
                if kw in std.get("title_en", "").lower():
                    score += 5
                if kw in std.get("scope_zh", "").lower():
                    score += 3
                if kw in std.get("category", "").lower():
                    score += 2
                for sec_key, sec in std.get("key_sections", {}).items():
                    if kw in sec.get("content_zh", "").lower():
                        score += 1
                    if kw in sec.get("title_zh", "").lower():
                        score += 2
                if score > 0:
                    results.append({
                        "authority": authority,
                        "standard_key": std_key,
                        "id": std.get("id", std_key),
                        "title_zh": std.get("title_zh", ""),
                        "title_en": std.get("title_en", ""),
                        "category": std.get("category", ""),
                        "score": score,
                    })
        results.sort(key=lambda x: -x["score"])
        return results

    def get_standard(self, standard_key: str) -> Optional[dict]:
        for authority, auth_data in self.db.items():
            standards = auth_data.get("standards", {})
            if standard_key in standards:
                std = standards[standard_key].copy()
                std["authority"] = authority
                std["authority_zh"] = auth_data["authority_zh"]
                return std
        return None

    def get_cross_references(self, standard_key: str) -> list[dict]:
        std = self.get_standard(standard_key)
        if not std:
            return []
        refs = std.get("cross_references", [])
        results = []
        for ref in refs:
            for authority, auth_data in self.db.items():
                for sk, sv in auth_data.get("standards", {}).items():
                    if sv.get("id", "") == ref or sk == ref:
                        results.append({
                            "authority": authority,
                            "id": sv.get("id", sk),
                            "title_zh": sv.get("title_zh", ""),
                        })
        return results

    def get_standards_by_category(self, category: str) -> list[dict]:
        results = []
        for authority, auth_data in self.db.items():
            for sk, sv in auth_data.get("standards", {}).items():
                if sv.get("category") == category:
                    results.append({
                        "authority": authority,
                        "id": sv.get("id", sk),
                        "title_zh": sv.get("title_zh", ""),
                        "title_en": sv.get("title_en", ""),
                    })
        return results

    def get_context_for_prompt(self, keywords: list[str] = None,
                                max_standards: int = 8) -> str:
        if not keywords:
            return ""
        all_results = []
        seen = set()
        for kw in keywords:
            for r in self.search(kw):
                if r["standard_key"] not in seen:
                    seen.add(r["standard_key"])
                    all_results.append(r)
        all_results.sort(key=lambda x: -x["score"])

        if not all_results:
            return ""

        lines = ["[标准库参考 - 以下为相关适航标准条款]"]
        for r in all_results[:max_standards]:
            std = self.get_standard(r["standard_key"])
            if not std:
                continue
            cat_zh, _ = CATEGORY_LABELS.get(std.get("category", ""), ("", ""))
            lines.append(f"\n### {std.get('id', '')} — {std.get('title_zh', '')}")
            lines.append(f"  当局: {std.get('authority_zh', '')} | 类别: {cat_zh}")
            scope = std.get("scope_zh", "")
            if scope:
                lines.append(f"  范围: {scope[:200]}")
            for sec_key, sec in list(std.get("key_sections", {}).items())[:3]:
                sec_title = sec.get("title_zh", sec_key)
                content = sec.get("content_zh", "")
                if content:
                    lines.append(f"  ■ {sec_title}: {content[:150]}")
            xrefs = std.get("cross_references", [])
            if xrefs:
                lines.append(f"  等效标准: {', '.join(xrefs)}")
        return "\n".join(lines)

    def get_statistics(self) -> dict:
        total = 0
        by_authority = {}
        by_category = {}
        for authority, auth_data in self.db.items():
            stds = auth_data.get("standards", {})
            count = len(stds)
            total += count
            by_authority[authority] = count
            for sv in stds.values():
                cat = sv.get("category", "other")
                by_category[cat] = by_category.get(cat, 0) + 1
        return {
            "total_standards": total,
            "by_authority": by_authority,
            "by_category": by_category,
        }

    # ----------------------------------------------------------
    #  生成标准文件(md + json)
    # ----------------------------------------------------------
    def _generate_all_files(self):
        db_path = self.base_dir / "standards_db.json"
        with open(db_path, "w", encoding="utf-8") as f:
            json.dump(self.db, f, ensure_ascii=False, indent=2)

        for authority, auth_data in self.db.items():
            auth_dir = self.base_dir / authority
            auth_dir.mkdir(parents=True, exist_ok=True)
            for std_key, std in auth_data.get("standards", {}).items():
                self._write_standard_md(auth_dir, std_key, std, authority, auth_data)

        self._write_cross_reference_table()

    def _write_standard_md(self, auth_dir: Path, std_key: str, std: dict,
                            authority: str, auth_data: dict):
        std_id = std.get("id", std_key)
        safe_name = std_id.replace("/", "_").replace(" ", "_").replace(".", "_")
        path = auth_dir / f"{safe_name}.md"

        cat_zh, cat_en = CATEGORY_LABELS.get(std.get("category", ""), ("", ""))
        lines = [
            f"# {std_id}",
            f"",
            f"**{std.get('title_zh', '')}**",
            f"",
        ]
        if std.get("title_en"):
            lines.append(f"*{std['title_en']}*")
            lines.append("")

        lines.extend([
            f"| 属性 | 内容 |",
            f"|------|------|",
            f"| 适航当局 | {auth_data['authority_zh']} ({authority}) |",
            f"| 类别 | {cat_zh} ({cat_en}) |",
        ])
        if std.get("publisher"):
            lines.append(f"| 发布机构 | {std['publisher']} |")
        if std.get("year"):
            lines.append(f"| 发布年份 | {std['year']} |")
        lines.append("")

        if std.get("scope_zh"):
            lines.extend(["## 适用范围", "", std["scope_zh"], ""])
        if std.get("scope_en"):
            lines.extend([f"*{std['scope_en']}*", ""])

        sections = std.get("key_sections", {})
        if sections:
            lines.extend(["## 关键条款", ""])
            for sec_key, sec in sections.items():
                sec_title = sec.get("title_zh", sec_key)
                lines.append(f"### {sec_title}")
                if sec.get("title_en"):
                    lines.append(f"*{sec['title_en']}*")
                lines.append("")
                if sec.get("content_zh"):
                    lines.append(sec["content_zh"])
                    lines.append("")
                if sec.get("dal_relevance"):
                    lines.append(f"**DAL相关性**: {sec['dal_relevance']}")
                    lines.append("")

        xrefs = std.get("cross_references", [])
        if xrefs:
            lines.extend(["## 交叉引用(等效标准)", ""])
            for xr in xrefs:
                lines.append(f"- {xr}")
            lines.append("")

        if std.get("supplements"):
            lines.extend(["## 补充文件", ""])
            for s in std["supplements"]:
                lines.append(f"- {s}")
            lines.append("")

        if std.get("note_zh"):
            lines.extend(["## 备注", "", std["note_zh"], ""])

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

    def _write_cross_reference_table(self):
        path = self.base_dir / "cross_reference.md"
        lines = [
            "# 中美欧适航标准交叉引用表",
            "",
            f"> 自动生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "",
            "## 三方等效标准对照",
            "",
            "| 领域 | FAA (美国) | EASA (欧洲) | CAAC (中国) |",
            "|------|-----------|-------------|-------------|",
            "| 飞机适航 | 14 CFR Part 25 | CS-25 | CCAR-25 |",
            "| 软件适航 | DO-178C | ED-12C | CTSO-C153 / MH/T 0028 |",
            "| 硬件适航 | DO-254 | ED-80 | AC-25-19 |",
            "| 系统研制 | ARP4754A | ED-79A | AC-21-AA-2018-58 |",
            "| 安全评估 | ARP4761 | ED-135 | AC-25.1309-1A |",
            "| 环境试验 | DO-160G | ED-14G | — |",
            "| IMA航电 | DO-297 | ED-124 | — |",
            "| 信息安全 | DO-326A | ED-202A | — |",
            "",
            "## 关键差异说明",
            "",
            "### FAA vs EASA",
            "- EASA标准(ED-xxx)与FAA/RTCA标准(DO-xxx)技术内容基本一致",
            "- EASA通过AMC(Acceptable Means of Compliance)发布详细符合性指南",
            "- 部分EASA特殊条件(Special Conditions)与FAA有差异",
            "",
            "### CAAC特点",
            "- CCAR-25基本等同FAR 25，但部分条款结合中国运行环境有调整",
            "- CAAC通过咨询通告(AC)引用FAA/EASA标准作为可接受的符合性方法",
            "- C919同时满足CCAR-25和FAR 25双重认证要求",
            "- CAAC正在建设自主的适航标准体系，逐步完善本土化标准",
            "",
            "## 按领域分类汇总",
            "",
        ]

        for cat_key, (cat_zh, cat_en) in CATEGORY_LABELS.items():
            lines.append(f"### {cat_zh} ({cat_en})")
            lines.append("")
            for authority in ["FAA", "EASA", "CAAC"]:
                auth_data = self.db.get(authority, {})
                stds = auth_data.get("standards", {})
                auth_zh = auth_data.get("authority_zh", authority)
                matched = [(k, v) for k, v in stds.items() if v.get("category") == cat_key]
                if matched:
                    lines.append(f"**{auth_zh}**:")
                    for sk, sv in matched:
                        lines.append(f"- {sv.get('id', sk)}: {sv.get('title_zh', '')}")
                    lines.append("")

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
