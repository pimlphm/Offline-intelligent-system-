"""
通用Ontology知识图谱引擎
=========================
架构设计融合:
  - Hedi Karray (UTTOP/Toulouse INP) 的 Industrial Ontologies Foundry (IOF) 分层本体
  - IOF/BFO (Basic Formal Ontology) 三层架构: Top → Core → Domain
  - OpenClaw Skills Hub 的通用实体-关系图谱模式
  - 关联强度量化: 赤(1.0)→橙→黄→绿→青→蓝→紫(0.1) 七级色谱

核心特性:
  - 通用化: 任意文档都能自动构建Ontology，不限于需求-设计-代码
  - 分层本体: BFO顶层 → IOF核心层 → 领域层 (航空/军工/通用)
  - 关联强度: 每条边携带0-1的strength值，映射为赤橙黄绿青蓝紫色谱
  - Schema约束: 类型定义、必填属性、关系基数、无环校验
  - 追溯推理: 路径发现、聚类分析、缺失链接推测
"""
import json
import os
import uuid

from datetime import datetime
from typing import Optional
from pathlib import Path
from collections import defaultdict

from rdflib import Graph as RDFGraph, Namespace, URIRef, Literal
from rdflib.namespace import RDF, RDFS, OWL, XSD
import networkx as nx


# ============================================================
#  BFO / IOF 分层命名空间
# ============================================================
BFO = Namespace("http://purl.obolibrary.org/obo/BFO_")
IOF = Namespace("https://spec.industrialontologies.org/ontology/core/Core/")
AERO = Namespace("http://aviation-kb.org/ontology#")
KB = Namespace("http://aviation-kb.org/node#")

# ============================================================
#  关联强度色谱: 赤橙黄绿青蓝紫
# ============================================================
STRENGTH_SPECTRUM = [
    (0.85, "#FF0000", "赤", "极强关联"),
    (0.70, "#FF6600", "橙", "强关联"),
    (0.55, "#FFCC00", "黄", "较强关联"),
    (0.40, "#33CC33", "绿", "中等关联"),
    (0.25, "#00CCCC", "青", "较弱关联"),
    (0.12, "#3366FF", "蓝", "弱关联"),
    (0.00, "#9933FF", "紫", "极弱关联"),
]


def strength_to_color(strength: float) -> tuple:
    """strength (0~1) → (hex_color, 名称, 描述)"""
    s = max(0.0, min(1.0, strength))
    for threshold, color, name, desc in STRENGTH_SPECTRUM:
        if s >= threshold:
            return color, name, desc
    return "#9933FF", "紫", "极弱关联"


def strength_to_width(strength: float) -> float:
    return 1.0 + strength * 5.0


# ============================================================
#  IOF 分层类型体系
# ============================================================

TYPE_HIERARCHY = {
    # --- BFO 顶层 (Top-Level) ---
    "entity": {"layer": "bfo", "parent": None, "label": "实体",
               "icon": "●", "base_color": "#607D8B"},
    "continuant": {"layer": "bfo", "parent": "entity", "label": "持续体",
                   "icon": "■", "base_color": "#78909C"},
    "occurrent": {"layer": "bfo", "parent": "entity", "label": "发生体",
                  "icon": "▲", "base_color": "#90A4AE"},

    # --- IOF 核心层 (Core) ---
    "artifact": {"layer": "iof_core", "parent": "continuant", "label": "人工物",
                 "icon": "◆", "base_color": "#42A5F5"},
    "process": {"layer": "iof_core", "parent": "occurrent", "label": "过程",
                "icon": "▶", "base_color": "#66BB6A"},
    "agent": {"layer": "iof_core", "parent": "continuant", "label": "主体",
              "icon": "◉", "base_color": "#AB47BC"},
    "information": {"layer": "iof_core", "parent": "continuant", "label": "信息实体",
                    "icon": "◇", "base_color": "#FFA726"},
    "capability": {"layer": "iof_core", "parent": "continuant", "label": "能力",
                   "icon": "★", "base_color": "#EC407A"},
    "specification": {"layer": "iof_core", "parent": "information", "label": "规格",
                      "icon": "◈", "base_color": "#26C6DA"},
    "quality": {"layer": "iof_core", "parent": "continuant", "label": "性质",
                "icon": "○", "base_color": "#8D6E63"},

    # --- 领域层: 通用知识工程 ---
    "concept": {"layer": "domain", "parent": "information", "label": "概念",
                "icon": "💡", "base_color": "#FF7043"},
    "document": {"layer": "domain", "parent": "information", "label": "文档",
                 "icon": "📄", "base_color": "#78909C"},
    "standard": {"layer": "domain", "parent": "specification", "label": "标准/规范",
                 "icon": "📋", "base_color": "#5C6BC0"},
    "method": {"layer": "domain", "parent": "process", "label": "方法/算法",
               "icon": "⚙", "base_color": "#26A69A"},
    "technology": {"layer": "domain", "parent": "artifact", "label": "技术",
                   "icon": "🔧", "base_color": "#7E57C2"},
    "person": {"layer": "domain", "parent": "agent", "label": "人员",
               "icon": "👤", "base_color": "#5C6BC0"},
    "organization": {"layer": "domain", "parent": "agent", "label": "组织",
                     "icon": "🏢", "base_color": "#42A5F5"},

    # --- 领域层: 民机适航认证体系 (ARP4754A/DO-178C/ARP4761) ---
    # 需求层次 (DOORS/Polarion中的层级)
    "requirement": {"layer": "domain_aero", "parent": "specification",
                    "label": "需求", "icon": "●", "base_color": "#E53935"},
    "aircraft_req": {"layer": "domain_aero", "parent": "requirement",
                     "label": "飞机级需求", "icon": "●", "base_color": "#B71C1C"},
    "system_req": {"layer": "domain_aero", "parent": "requirement",
                   "label": "系统级需求", "icon": "●", "base_color": "#C62828"},
    "subsystem_req": {"layer": "domain_aero", "parent": "requirement",
                      "label": "子系统需求", "icon": "●", "base_color": "#D32F2F"},
    "hlr": {"layer": "domain_aero", "parent": "requirement",
            "label": "高层需求HLR", "icon": "●", "base_color": "#E53935"},
    "llr": {"layer": "domain_aero", "parent": "requirement",
            "label": "低层需求LLR", "icon": "●", "base_color": "#EF5350"},
    "functional_req": {"layer": "domain_aero", "parent": "requirement",
                       "label": "功能需求", "icon": "●", "base_color": "#E53935"},
    "safety_req": {"layer": "domain_aero", "parent": "requirement",
                   "label": "安全需求", "icon": "●", "base_color": "#FF6D00"},
    "performance_req": {"layer": "domain_aero", "parent": "requirement",
                        "label": "性能需求", "icon": "●", "base_color": "#FFB300"},
    "regulatory_req": {"layer": "domain_aero", "parent": "requirement",
                       "label": "适航条款", "icon": "●", "base_color": "#8E24AA"},
    "derived_req": {"layer": "domain_aero", "parent": "requirement",
                    "label": "派生需求", "icon": "●", "base_color": "#F06292"},
    "interface_req": {"layer": "domain_aero", "parent": "requirement",
                      "label": "接口需求", "icon": "●", "base_color": "#4DB6AC"},

    # 安全评估体系 (ARP4761)
    "hazard": {"layer": "domain_aero", "parent": "quality",
               "label": "危险/失效", "icon": "▲", "base_color": "#FF1744"},
    "failure_condition": {"layer": "domain_aero", "parent": "hazard",
                          "label": "失效状态", "icon": "▲", "base_color": "#D50000"},
    "fha_item": {"layer": "domain_aero", "parent": "hazard",
                 "label": "FHA条目", "icon": "▲", "base_color": "#FF1744"},
    "fmea_item": {"layer": "domain_aero", "parent": "hazard",
                  "label": "FMEA条目", "icon": "▲", "base_color": "#FF5252"},
    "fault_tree": {"layer": "domain_aero", "parent": "hazard",
                   "label": "故障树FTA", "icon": "▲", "base_color": "#FF8A80"},
    "dal_assignment": {"layer": "domain_aero", "parent": "specification",
                       "label": "DAL分配", "icon": "◆", "base_color": "#AA00FF"},
    "cca_item": {"layer": "domain_aero", "parent": "hazard",
                 "label": "共因分析CCA", "icon": "▲", "base_color": "#E040FB"},
    "safety_objective": {"layer": "domain_aero", "parent": "specification",
                         "label": "安全目标", "icon": "◆", "base_color": "#FF6E40"},

    # 设计层次 (Capella/Cameo中的架构)
    "design": {"layer": "domain_aero", "parent": "artifact",
               "label": "设计", "icon": "◆", "base_color": "#1E88E5"},
    "operational_analysis": {"layer": "domain_aero", "parent": "design",
                             "label": "运行分析OA", "icon": "◆", "base_color": "#0D47A1"},
    "system_analysis": {"layer": "domain_aero", "parent": "design",
                        "label": "系统分析SA", "icon": "◆", "base_color": "#1565C0"},
    "logical_architecture": {"layer": "domain_aero", "parent": "design",
                             "label": "逻辑架构LA", "icon": "◆", "base_color": "#1976D2"},
    "physical_architecture": {"layer": "domain_aero", "parent": "design",
                              "label": "物理架构PA", "icon": "◆", "base_color": "#1E88E5"},
    "structural_design": {"layer": "domain_aero", "parent": "design",
                          "label": "结构设计", "icon": "◆", "base_color": "#1565C0"},
    "system_design": {"layer": "domain_aero", "parent": "design",
                      "label": "系统设计", "icon": "◆", "base_color": "#0097A7"},
    "software_design": {"layer": "domain_aero", "parent": "design",
                        "label": "软件设计", "icon": "◆", "base_color": "#1E88E5"},
    "hardware_design": {"layer": "domain_aero", "parent": "design",
                        "label": "硬件设计DO-254", "icon": "◆", "base_color": "#00838F"},

    # 代码/实现层
    "code": {"layer": "domain_aero", "parent": "artifact",
             "label": "代码/实现", "icon": "■", "base_color": "#43A047"},
    "module": {"layer": "domain_aero", "parent": "code",
               "label": "软件模块", "icon": "■", "base_color": "#2E7D32"},
    "function": {"layer": "domain_aero", "parent": "code",
                 "label": "函数/组件", "icon": "■", "base_color": "#43A047"},
    "configuration_item": {"layer": "domain_aero", "parent": "artifact",
                           "label": "构型项CI", "icon": "■", "base_color": "#558B2F"},

    # 验证与确认层 (V模型右半)
    "test_case": {"layer": "domain_aero", "parent": "process",
                  "label": "测试用例", "icon": "▶", "base_color": "#F9A825"},
    "test_procedure": {"layer": "domain_aero", "parent": "process",
                       "label": "测试规程", "icon": "▶", "base_color": "#F57F17"},
    "test_result": {"layer": "domain_aero", "parent": "information",
                    "label": "测试结果", "icon": "▶", "base_color": "#FDD835"},
    "coverage_analysis": {"layer": "domain_aero", "parent": "process",
                          "label": "覆盖率分析", "icon": "▶", "base_color": "#FFD600"},
    "review_record": {"layer": "domain_aero", "parent": "information",
                      "label": "评审记录", "icon": "▶", "base_color": "#FFAB00"},

    # 认证交付物 (SOI阶段文档)
    "psac": {"layer": "domain_aero", "parent": "document",
             "label": "PSAC计划", "icon": "◇", "base_color": "#6D4C41"},
    "sas": {"layer": "domain_aero", "parent": "document",
            "label": "SAS总结", "icon": "◇", "base_color": "#795548"},
    "compliance_matrix": {"layer": "domain_aero", "parent": "document",
                          "label": "符合性矩阵", "icon": "◇", "base_color": "#8D6E63"},
    "soi_review": {"layer": "domain_aero", "parent": "process",
                   "label": "SOI审查", "icon": "▶", "base_color": "#A1887F"},

    # 适航标准/条款
    "airworthiness_reg": {"layer": "domain_aero", "parent": "standard",
                          "label": "适航条例", "icon": "◇", "base_color": "#7B1FA2"},
    "certification_basis": {"layer": "domain_aero", "parent": "standard",
                            "label": "认证基础", "icon": "◇", "base_color": "#6A1B9A"},

    # 飞机系统/部件
    "aircraft_system": {"layer": "domain_aero", "parent": "artifact",
                        "label": "飞机系统ATA", "icon": "◆", "base_color": "#00695C"},
    "lru": {"layer": "domain_aero", "parent": "artifact",
            "label": "线路可更换单元LRU", "icon": "◆", "base_color": "#00796B"},
    "equipment": {"layer": "domain_aero", "parent": "artifact",
                  "label": "机载设备", "icon": "◆", "base_color": "#00897B"},

    # 变更/问题管理
    "change_request": {"layer": "domain_aero", "parent": "information",
                       "label": "变更请求CR", "icon": "◇", "base_color": "#E65100"},
    "problem_report": {"layer": "domain_aero", "parent": "information",
                       "label": "问题报告PR", "icon": "◇", "base_color": "#BF360C"},

    # --- 领域层: 通用(LLM自动推断) ---
    "topic": {"layer": "domain", "parent": "concept",
              "label": "主题", "icon": "📌", "base_color": "#EF5350"},
    "finding": {"layer": "domain", "parent": "information",
                "label": "发现/结论", "icon": "🔍", "base_color": "#AB47BC"},
    "evidence": {"layer": "domain", "parent": "information",
                 "label": "证据/数据", "icon": "📊", "base_color": "#29B6F6"},
    "constraint": {"layer": "domain", "parent": "specification",
                   "label": "约束", "icon": "🔒", "base_color": "#FF7043"},
    "risk": {"layer": "domain", "parent": "quality",
             "label": "风险", "icon": "⚠", "base_color": "#FF1744"},
    "decision": {"layer": "domain", "parent": "information",
                 "label": "决策", "icon": "🎯", "base_color": "#00BFA5"},
    "assumption": {"layer": "domain", "parent": "information",
                   "label": "假设", "icon": "❓", "base_color": "#FFD54F"},
    "interface": {"layer": "domain", "parent": "specification",
                  "label": "接口", "icon": "🔗", "base_color": "#4DB6AC"},
}

RELATION_TYPES = {
    # 追溯关系 (DO-178C/ARP4754A核心)
    "implements": {"label": "实现", "inverse": "implemented_by", "category": "traceability"},
    "traces_to": {"label": "追溯到", "inverse": "traced_from", "category": "traceability"},
    "verifies": {"label": "验证", "inverse": "verified_by", "category": "traceability"},
    "satisfies": {"label": "满足", "inverse": "satisfied_by", "category": "traceability"},
    "allocates_to": {"label": "分配到", "inverse": "allocated_from", "category": "traceability"},
    "decomposes_to": {"label": "分解到", "inverse": "decomposed_from", "category": "traceability"},
    "covers": {"label": "覆盖", "inverse": "covered_by", "category": "traceability"},

    # 层级关系
    "refines": {"label": "细化", "inverse": "refined_by", "category": "hierarchy"},
    "extends": {"label": "扩展", "inverse": "extended_by", "category": "hierarchy"},
    "part_of": {"label": "组成部分", "inverse": "has_part", "category": "composition"},

    # 依赖与约束
    "depends_on": {"label": "依赖", "inverse": "depended_by", "category": "dependency"},
    "constrains": {"label": "约束", "inverse": "constrained_by", "category": "constraint"},
    "conflicts_with": {"label": "冲突", "inverse": "conflicts_with", "category": "conflict"},
    "contradicts": {"label": "矛盾", "inverse": "contradicted_by", "category": "conflict"},

    # 派生与因果
    "derived_from": {"label": "派生自", "inverse": "derives", "category": "derivation"},
    "produces": {"label": "产出", "inverse": "produced_by", "category": "causation"},
    "mitigates": {"label": "缓解/消减", "inverse": "mitigated_by", "category": "safety"},
    "causes": {"label": "导致", "inverse": "caused_by", "category": "safety"},

    # 安全评估 (ARP4761)
    "identified_by": {"label": "识别于", "inverse": "identifies", "category": "safety"},
    "assessed_in": {"label": "评估于", "inverse": "assesses", "category": "safety"},
    "assigns_dal": {"label": "分配DAL", "inverse": "dal_assigned_by", "category": "safety"},
    "failure_leads_to": {"label": "失效导致", "inverse": "caused_by_failure", "category": "safety"},
    "contributes_to": {"label": "贡献于(故障树)", "inverse": "contributed_by", "category": "safety"},

    # V&V关系
    "tested_by": {"label": "测试于", "inverse": "tests", "category": "verification"},
    "reviewed_in": {"label": "评审于", "inverse": "reviews", "category": "verification"},
    "complies_with": {"label": "符合", "inverse": "compliance_for", "category": "certification"},

    # 通用关联
    "documented_in": {"label": "记载于", "inverse": "documents", "category": "reference"},
    "related_to": {"label": "相关", "inverse": "related_to", "category": "association"},
    "uses": {"label": "使用", "inverse": "used_by", "category": "usage"},
    "supports": {"label": "支撑", "inverse": "supported_by", "category": "support"},
    "similar_to": {"label": "相似", "inverse": "similar_to", "category": "similarity"},
    "precedes": {"label": "先于", "inverse": "follows", "category": "temporal"},
    "owned_by": {"label": "属于", "inverse": "owns", "category": "ownership"},
    "references": {"label": "引用", "inverse": "referenced_by", "category": "reference"},
    "supersedes": {"label": "取代", "inverse": "superseded_by", "category": "versioning"},
    "impacts": {"label": "影响", "inverse": "impacted_by", "category": "change_mgmt"},
}


# ============================================================
#  核心引擎
# ============================================================

ATA_STRUCTURE = {
    "21": {"name": "空调", "zone": "前机身/设备舱", "en": "Air Conditioning"},
    "22": {"name": "自动飞行", "zone": "驾驶舱/航电舱", "en": "Auto Flight"},
    "23": {"name": "通信", "zone": "航电舱/天线罩", "en": "Communications"},
    "24": {"name": "电源", "zone": "前机身/设备舱", "en": "Electrical Power"},
    "25": {"name": "设备/装饰", "zone": "客舱", "en": "Equipment/Furnishings"},
    "26": {"name": "防火", "zone": "发动机/APU/货舱", "en": "Fire Protection"},
    "27": {"name": "飞行操纵", "zone": "机翼/尾翼/驾驶舱", "en": "Flight Controls"},
    "28": {"name": "燃油", "zone": "机翼/中央翼盒", "en": "Fuel"},
    "29": {"name": "液压", "zone": "中机身/主起落架舱", "en": "Hydraulic Power"},
    "30": {"name": "防冰排雨", "zone": "机翼前缘/发动机进气道", "en": "Ice and Rain Protection"},
    "31": {"name": "指示记录", "zone": "驾驶舱/航电舱", "en": "Indicating/Recording"},
    "32": {"name": "起落架", "zone": "前起落架舱/主起落架舱", "en": "Landing Gear"},
    "33": {"name": "灯光", "zone": "机翼/机身/尾翼", "en": "Lights"},
    "34": {"name": "导航", "zone": "航电舱/天线罩", "en": "Navigation"},
    "35": {"name": "氧气", "zone": "客舱/驾驶舱顶部", "en": "Oxygen"},
    "36": {"name": "引气", "zone": "发动机/前机身", "en": "Pneumatic"},
    "38": {"name": "水/废水", "zone": "后机身", "en": "Water/Waste"},
    "46": {"name": "信息系统", "zone": "航电舱", "en": "Information Systems"},
    "49": {"name": "机载辅助动力", "zone": "尾锥/后机身", "en": "Airborne APU"},
    "51": {"name": "标准施工", "zone": "全机", "en": "Standard Practices"},
    "52": {"name": "门", "zone": "前/后机身", "en": "Doors"},
    "53": {"name": "机身", "zone": "机身段", "en": "Fuselage"},
    "54": {"name": "短舱/吊架", "zone": "发动机区域", "en": "Nacelles/Pylons"},
    "55": {"name": "安定面", "zone": "尾翼", "en": "Stabilizers"},
    "56": {"name": "窗户", "zone": "驾驶舱/客舱", "en": "Windows"},
    "57": {"name": "机翼", "zone": "机翼", "en": "Wings"},
    "71": {"name": "动力装置", "zone": "发动机", "en": "Power Plant"},
    "72": {"name": "发动机", "zone": "发动机", "en": "Engine"},
    "73": {"name": "发动机燃油和控制", "zone": "发动机", "en": "Engine Fuel and Control"},
    "74": {"name": "点火", "zone": "发动机", "en": "Ignition"},
    "75": {"name": "发动机引气", "zone": "发动机", "en": "Engine Bleed Air"},
    "76": {"name": "发动机控制", "zone": "发动机/航电舱", "en": "Engine Controls"},
    "77": {"name": "发动机指示", "zone": "驾驶舱/发动机", "en": "Engine Indicating"},
    "78": {"name": "排气", "zone": "发动机尾部", "en": "Exhaust"},
    "79": {"name": "滑油", "zone": "发动机", "en": "Oil"},
    "80": {"name": "起动", "zone": "发动机", "en": "Starting"},
}


class OntologyEngine:

    def __init__(self, db_path: str = "ontology/knowledge_graph.json"):
        self.db_path = db_path
        self.rdf = RDFGraph()
        self._bind_namespaces()
        self.nx_graph = nx.DiGraph()
        self.nodes = {}
        self.edges = []
        self.schema = {"types": dict(TYPE_HIERARCHY), "relations": dict(RELATION_TYPES)}
        self._undo_stack = []
        self._redo_stack = []
        self._max_undo = 50
        self._load()

    def _bind_namespaces(self):
        for prefix, ns in [("bfo", BFO), ("iof", IOF), ("aero", AERO),
                           ("kb", KB), ("owl", OWL)]:
            self.rdf.bind(prefix, ns)

    # ---- CRUD ----

    def add_node(self, node_type: str, label: str, properties: dict = None,
                 node_id: str = None, source_doc: str = None) -> str:
        nid = node_id or f"{node_type[:3]}_{uuid.uuid4().hex[:6]}"
        # 标准化类型
        if node_type not in TYPE_HIERARCHY:
            best = self._infer_type(node_type)
            node_type = best
        type_info = TYPE_HIERARCHY.get(node_type, TYPE_HIERARCHY["concept"])
        node = {
            "id": nid, "type": node_type, "label": label,
            "properties": properties or {},
            "source_doc": source_doc or "",
            "layer": type_info["layer"],
            "created": datetime.now().isoformat(),
        }
        self.nodes[nid] = node
        self.nx_graph.add_node(nid, **node)
        subj = URIRef(str(KB) + nid)
        self.rdf.add((subj, RDF.type, AERO[node_type]))
        self.rdf.add((subj, RDFS.label, Literal(label, lang="zh")))
        return nid

    def add_edge(self, source_id: str, target_id: str, relation: str,
                 strength: float = 0.5, properties: dict = None,
                 auto_strength: bool = True) -> dict:
        """添加带关联强度的边"""
        if auto_strength and strength == 0.5:
            strength = self._compute_strength(source_id, target_id, relation)
        strength = max(0.0, min(1.0, strength))
        edge = {
            "source": source_id, "target": target_id,
            "relation": relation, "strength": strength,
            "properties": properties or {},
            "created": datetime.now().isoformat(),
        }
        self.edges.append(edge)
        self.nx_graph.add_edge(source_id, target_id,
                               relation=relation, strength=strength,
                               **(properties or {}))
        return edge

    def _compute_strength(self, src_id: str, tgt_id: str, relation: str) -> float:
        """自动计算关联强度"""
        base = 0.5
        rel_info = RELATION_TYPES.get(relation, {})
        cat = rel_info.get("category", "association")
        cat_boost = {"traceability": 0.2, "composition": 0.2, "causation": 0.15,
                     "dependency": 0.1, "conflict": 0.15, "constraint": 0.1,
                     "hierarchy": 0.05, "reference": -0.1, "similarity": -0.05,
                     "association": 0.0}.get(cat, 0.0)
        base += cat_boost
        src = self.nodes.get(src_id, {})
        tgt = self.nodes.get(tgt_id, {})
        if src.get("source_doc") and src["source_doc"] == tgt.get("source_doc"):
            base += 0.1
        src_type = src.get("type", "")
        tgt_type = tgt.get("type", "")
        if src_type and tgt_type:
            src_layer = TYPE_HIERARCHY.get(src_type, {}).get("layer", "")
            tgt_layer = TYPE_HIERARCHY.get(tgt_type, {}).get("layer", "")
            if src_layer == tgt_layer:
                base += 0.05
        return max(0.05, min(0.99, base))

    def _infer_type(self, raw_type: str) -> str:
        """将LLM输出的非标准类型映射到最近的标准类型"""
        raw = raw_type.lower().replace(" ", "_").replace("-", "_")
        if raw in TYPE_HIERARCHY:
            return raw
        alias_map = {
            "func_req": "functional_req", "safety": "safety_req",
            "perf_req": "performance_req", "reg_req": "regulatory_req",
            "struct_design": "structural_design", "sys_design": "system_design",
            "sw_design": "software_design", "test": "test_case",
            "algorithm": "method", "technique": "technology",
            "paper": "document", "report": "document",
            "company": "organization", "team": "organization",
            "researcher": "person", "author": "person",
            "issue": "risk", "problem": "risk",
            "result": "finding", "conclusion": "finding",
            "data": "evidence", "dataset": "evidence",
            "limit": "constraint", "boundary": "constraint",
            "choice": "decision", "hypothesis": "assumption",
            "api": "interface", "protocol": "interface",
        }
        if raw in alias_map:
            return alias_map[raw]
        for key in TYPE_HIERARCHY:
            if raw in key or key in raw:
                return key
        return "concept"

    def remove_node(self, node_id: str):
        self.nodes.pop(node_id, None)
        if node_id in self.nx_graph:
            self.nx_graph.remove_node(node_id)
        self.edges = [e for e in self.edges
                      if e["source"] != node_id and e["target"] != node_id]

    # ---- Undo / Redo ----

    def snapshot(self, label: str = ""):
        """保存当前状态到undo栈"""
        state = {
            "label": label,
            "nodes": json.loads(json.dumps(self.nodes)),
            "edges": json.loads(json.dumps(self.edges)),
        }
        self._undo_stack.append(state)
        if len(self._undo_stack) > self._max_undo:
            self._undo_stack.pop(0)
        self._redo_stack.clear()

    def undo(self) -> str:
        if not self._undo_stack:
            return ""
        current = {
            "label": "redo_point",
            "nodes": json.loads(json.dumps(self.nodes)),
            "edges": json.loads(json.dumps(self.edges)),
        }
        self._redo_stack.append(current)
        state = self._undo_stack.pop()
        self._restore_state(state)
        return state.get("label", "")

    def redo(self) -> str:
        if not self._redo_stack:
            return ""
        current = {
            "label": "undo_point",
            "nodes": json.loads(json.dumps(self.nodes)),
            "edges": json.loads(json.dumps(self.edges)),
        }
        self._undo_stack.append(current)
        state = self._redo_stack.pop()
        self._restore_state(state)
        return state.get("label", "")

    def _restore_state(self, state: dict):
        self.nodes = state["nodes"]
        self.edges = state["edges"]
        self.nx_graph = nx.DiGraph()
        for nid, node in self.nodes.items():
            self.nx_graph.add_node(nid, **node)
        for edge in self.edges:
            self.nx_graph.add_edge(
                edge["source"], edge["target"],
                relation=edge.get("relation", ""),
                strength=edge.get("strength", 0.5),
            )

    @property
    def can_undo(self):
        return len(self._undo_stack) > 0

    @property
    def can_redo(self):
        return len(self._redo_stack) > 0

    # ---- Source-doc grouping ----

    def get_source_docs(self) -> dict:
        """按来源文档分组节点, 返回 {doc_name: [node_ids]}"""
        groups = defaultdict(list)
        for nid, node in self.nodes.items():
            doc = node.get("source_doc", "") or "未分类"
            groups[doc].append(nid)
        return dict(groups)

    def get_ata_mapping(self) -> dict:
        """根据节点的ata_chapter属性映射到ATA结构位置"""
        mapping = defaultdict(list)
        for nid, node in self.nodes.items():
            ata = node.get("properties", {}).get("ata_chapter", "")
            if ata:
                ata_num = str(ata).split("-")[0].split(".")[0].strip()
                if ata_num in ATA_STRUCTURE:
                    info = ATA_STRUCTURE[ata_num]
                    mapping[ata_num].append({
                        "node_id": nid,
                        "label": node.get("label", ""),
                        "type": node.get("type", ""),
                        "zone": info["zone"],
                        "ata_name": info["name"],
                    })
        return dict(mapping)

    def get_node(self, node_id: str) -> Optional[dict]:
        return self.nodes.get(node_id)

    def get_neighbors(self, node_id: str, min_strength: float = 0.0) -> list:
        if node_id not in self.nx_graph:
            return []
        neighbors = []
        for _, target, data in self.nx_graph.out_edges(node_id, data=True):
            if data.get("strength", 0) >= min_strength:
                neighbors.append({
                    "id": target, "direction": "out",
                    "relation": data.get("relation", ""),
                    "strength": data.get("strength", 0.5),
                    **self.nodes.get(target, {}),
                })
        for source, _, data in self.nx_graph.in_edges(node_id, data=True):
            if data.get("strength", 0) >= min_strength:
                neighbors.append({
                    "id": source, "direction": "in",
                    "relation": data.get("relation", ""),
                    "strength": data.get("strength", 0.5),
                    **self.nodes.get(source, {}),
                })
        return sorted(neighbors, key=lambda x: -x.get("strength", 0))

    def query_by_type(self, node_type: str) -> list:
        results = [n for n in self.nodes.values() if n["type"] == node_type]
        parent_type = node_type
        children = [k for k, v in TYPE_HIERARCHY.items()
                    if v.get("parent") == parent_type]
        for child in children:
            results.extend(n for n in self.nodes.values() if n["type"] == child)
        return results

    def search_nodes(self, keyword: str) -> list:
        kw = keyword.lower()
        results = []
        for n in self.nodes.values():
            score = 0
            if kw in n["label"].lower():
                score = 3
            elif kw in n.get("type", "").lower():
                score = 2
            else:
                for v in n.get("properties", {}).values():
                    if kw in str(v).lower():
                        score = 1
                        break
            if score > 0:
                results.append((score, n))
        return [n for _, n in sorted(results, key=lambda x: -x[0])]

    # ---- Analysis ----

    def get_traceability_matrix(self) -> dict:
        reqs = []
        for t in ["requirement", "functional_req", "safety_req",
                  "performance_req", "regulatory_req"]:
            reqs.extend(self.query_by_type(t))
        seen_ids = set()
        unique_reqs = []
        for r in reqs:
            if r["id"] not in seen_ids:
                seen_ids.add(r["id"])
                unique_reqs.append(r)
        matrix = {}
        for req in unique_reqs:
            rid = req["id"]
            neighbors = self.get_neighbors(rid)
            designs = [n for n in neighbors if "design" in n.get("type", "")]
            codes = [n for n in neighbors
                     if n.get("type") in ("code", "module", "function")]
            tests = [n for n in neighbors if n.get("type") == "test_case"]
            matrix[rid] = {
                "requirement": req, "designs": designs,
                "codes": codes, "tests": tests,
                "coverage": "full" if designs and codes else
                            "partial" if designs or codes else "none",
            }
        return matrix

    def find_clusters(self) -> list:
        """发现知识簇（弱连通分量）"""
        if self.nx_graph.number_of_nodes() == 0:
            return []
        components = list(nx.weakly_connected_components(self.nx_graph))
        clusters = []
        for comp in components:
            nodes_in = [self.nodes[nid] for nid in comp if nid in self.nodes]
            type_counts = defaultdict(int)
            for n in nodes_in:
                type_counts[n["type"]] += 1
            labels = [self.nodes[nid]["label"] for nid in comp if nid in self.nodes]
            clusters.append({
                "size": len(comp),
                "node_ids": list(comp),
                "labels": labels,
                "nodes": labels,
                "type_distribution": dict(type_counts),
                "density": self._subgraph_density(comp),
            })
        return sorted(clusters, key=lambda c: -c["size"])

    def _subgraph_density(self, node_ids) -> float:
        sub = self.nx_graph.subgraph(node_ids)
        n = sub.number_of_nodes()
        if n <= 1:
            return 0.0
        return sub.number_of_edges() / (n * (n - 1))

    def find_bridge_nodes(self) -> list:
        """发现关键桥接节点（去除后增加连通分量数）"""
        if self.nx_graph.number_of_nodes() < 3:
            return []
        undirected = self.nx_graph.to_undirected()
        bridges = []
        try:
            betweenness = nx.betweenness_centrality(undirected)
            for nid, score in sorted(betweenness.items(), key=lambda x: -x[1])[:10]:
                if score > 0.05 and nid in self.nodes:
                    bridges.append({**self.nodes[nid], "centrality": round(score, 4),
                                     "betweenness": round(score, 4)})
        except Exception:
            pass
        return bridges

    def suggest_missing_links(self) -> list:
        """基于图谱拓扑推测缺失的链接"""
        suggestions = []
        # 孤立需求
        for t in ["requirement", "functional_req", "safety_req",
                  "performance_req", "regulatory_req"]:
            for n in self.query_by_type(t):
                if not self.get_neighbors(n["id"]):
                    suggestions.append({
                        "type": "orphan_node", "severity": "high",
                        "message": f"孤立{TYPE_HIERARCHY.get(t,{}).get('label',t)}: "
                                   f"'{n['label']}' 没有任何关联",
                        "node": n,
                    })
        # 没有测试的安全需求
        for n in self.query_by_type("safety_req"):
            neighbors = self.get_neighbors(n["id"])
            if not any(nb.get("type") == "test_case" for nb in neighbors):
                suggestions.append({
                    "type": "safety_gap", "severity": "critical",
                    "message": f"安全需求 '{n['label']}' 缺少测试验证",
                    "node": n,
                })
        # 小孤立簇
        clusters = self.find_clusters()
        for c in clusters:
            if c["size"] <= 2 and len(clusters) > 1:
                labels = [self.nodes[nid]["label"]
                          for nid in c["node_ids"] if nid in self.nodes]
                suggestions.append({
                    "type": "isolated_cluster", "severity": "medium",
                    "message": f"孤立知识簇 ({c['size']}节点): {', '.join(labels[:3])}",
                    "node_ids": c["node_ids"],
                })
        return suggestions

    def suggest_next_gen(self) -> list:
        """推导下一代需求/知识方向"""
        suggestions = []
        all_types = defaultdict(int)
        for n in self.nodes.values():
            all_types[n["type"]] += 1
        total = len(self.nodes)
        if total == 0:
            return suggestions
        type_ratios = {t: c / total for t, c in all_types.items()}
        if type_ratios.get("safety_req", 0) < 0.1 and total > 5:
            suggestions.append({
                "direction": "安全性增强",
                "detail": f"安全需求仅占{type_ratios.get('safety_req',0):.0%}，"
                          "建议增加故障模式、冗余设计等安全需求",
                "priority": "high",
            })
        if not any("test" in t for t in all_types) and total > 5:
            suggestions.append({
                "direction": "验证与测试",
                "detail": "知识图谱中缺少测试用例节点，建议补充测试策略",
                "priority": "high",
            })
        risk_count = all_types.get("risk", 0)
        if risk_count == 0 and total > 8:
            suggestions.append({
                "direction": "风险管理",
                "detail": "未识别任何风险节点，建议系统化风险评估",
                "priority": "medium",
            })
        return suggestions

    # ---- Export ----

    def to_dict(self) -> dict:
        return {
            "nodes": list(self.nodes.values()),
            "edges": self.edges,
            "meta": {
                "node_count": len(self.nodes),
                "edge_count": len(self.edges),
                "type_hierarchy": "IOF/BFO",
                "updated": datetime.now().isoformat(),
            },
        }

    def to_vis_json(self) -> dict:
        vis_nodes = []
        for n in self.nodes.values():
            ntype = n["type"]
            type_info = TYPE_HIERARCHY.get(ntype, TYPE_HIERARCHY.get("concept", {}))
            layer = type_info.get("layer", "domain")
            size = {"bfo": 15, "iof_core": 20, "domain": 25,
                    "domain_aero": 28}.get(layer, 25)
            shape = {"bfo": "triangle", "iof_core": "diamond",
                     "domain": "dot", "domain_aero": "dot"}.get(layer, "dot")
            vis_nodes.append({
                "id": n["id"], "label": n["label"],
                "group": ntype, "color": type_info.get("base_color", "#999"),
                "shape": shape, "size": size,
                "title": (
                    f"<b>{n['label']}</b><br>"
                    f"类型: {type_info.get('label', ntype)}<br>"
                    f"层级: {layer}<br>"
                    + "".join(f"{k}: {v}<br>"
                             for k, v in n.get("properties", {}).items()
                             if v)
                ),
                "font": {"size": 12},
            })
        vis_edges = []
        for e in self.edges:
            s = e.get("strength", 0.5)
            color, color_name, _ = strength_to_color(s)
            rel_info = RELATION_TYPES.get(e["relation"], {})
            vis_edges.append({
                "from": e["source"], "to": e["target"],
                "label": rel_info.get("label", e["relation"]),
                "arrows": "to",
                "color": {"color": color, "opacity": 0.5 + s * 0.5},
                "width": strength_to_width(s),
                "title": f"{rel_info.get('label', e['relation'])} "
                         f"(强度: {s:.2f}, {color_name})",
                "font": {"size": 9, "align": "middle"},
            })
        return {"nodes": vis_nodes, "edges": vis_edges}

    def export_rdf_turtle(self, path: str):
        self.rdf.serialize(destination=path, format="turtle")

    # ---- Persistence ----

    def save(self):
        os.makedirs(os.path.dirname(self.db_path) or ".", exist_ok=True)
        with open(self.db_path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)

    def _load(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for n in data.get("nodes", []):
                    self.nodes[n["id"]] = n
                    self.nx_graph.add_node(n["id"], **n)
                for e in data.get("edges", []):
                    self.edges.append(e)
                    self.nx_graph.add_edge(
                        e["source"], e["target"],
                        relation=e["relation"],
                        strength=e.get("strength", 0.5),
                    )
            except (json.JSONDecodeError, KeyError):
                pass

    def get_statistics(self) -> dict:
        type_counts = defaultdict(int)
        layer_counts = defaultdict(int)
        for n in self.nodes.values():
            type_counts[n["type"]] += 1
            layer_counts[n.get("layer", "unknown")] += 1
        rel_counts = defaultdict(int)
        strengths = []
        for e in self.edges:
            rel_counts[e["relation"]] += 1
            strengths.append(e.get("strength", 0.5))
        avg_strength = sum(strengths) / len(strengths) if strengths else 0
        return {
            "total_nodes": len(self.nodes),
            "total_edges": len(self.edges),
            "node_types": dict(type_counts),
            "layer_distribution": dict(layer_counts),
            "relation_types": dict(rel_counts),
            "avg_strength": round(avg_strength, 3),
            "connected_components": nx.number_weakly_connected_components(self.nx_graph)
            if self.nx_graph.number_of_nodes() > 0 else 0,
        }

    @staticmethod
    def get_type_hierarchy():
        return TYPE_HIERARCHY

    @staticmethod
    def get_relation_types():
        return RELATION_TYPES

    @staticmethod
    def get_strength_spectrum():
        return STRENGTH_SPECTRUM
