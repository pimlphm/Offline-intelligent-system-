@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion
title AeroKB Agent
cd /d "%~dp0"

echo ============================================
echo   AeroKB Agent - Starting...
echo ============================================
echo.

echo [1/4] Checking Ollama...
curl -s http://localhost:11434/api/tags >nul 2>&1
if !errorlevel! neq 0 (
    echo   Ollama not running, starting...
    start "" ollama serve
    timeout /t 3 /nobreak >nul
    curl -s http://localhost:11434/api/tags >nul 2>&1
    if !errorlevel! neq 0 (
        echo   [WARN] Ollama failed to start
    ) else (
        echo   Ollama started OK
    )
) else (
    echo   Ollama ready
)

echo [2/4] Finding Python...
set PY=
if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PY=C:\ProgramData\anaconda3\python.exe"
    echo   Using Anaconda Python
) else (
    where python >nul 2>&1
    if !errorlevel! equ 0 (
        set "PY=python"
        echo   Using system Python
    ) else (
        echo   [ERROR] Python not found
        pause
        exit /b 1
    )
)

echo [3/4] Checking deps...
"!PY!" -c "import PyQt5" >nul 2>&1
if !errorlevel! neq 0 (
    echo   Installing dependencies...
    "!PY!" -m pip install -r requirements.txt -q
)

echo [4/4] Launching app...
echo.
"!PY!" main.py

if !errorlevel! neq 0 (
    echo.
    echo [ERROR] App failed to start
    pause
)
endlocal