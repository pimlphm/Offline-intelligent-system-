# Layered Retrieval Eval Report

## Status

Compiled knowledge scaffolding now exists:

- `compiled_knowledge/`
- `knowledge/graph/schema.yaml`
- `knowledge/graph/graph_builder.py`
- `knowledge/graph/graph.graphml`

## Graph Build Snapshot

- GraphML output built successfully from current chunks
- Node count: `500`
- Edge count: `664`

## Gate Result

`REWAIT`

## Reason

- graph compilation is available, but graph-aware retrieval lift has not yet been benchmarked
- no Recall@10 comparison for multi-hop or temporal questions has been recorded yet
- graph layer remains optional until benchmark evidence justifies rollout

## Next Work

- add graph-aware candidate filtering into retrieval
- benchmark multi-hop and temporal subsets
- only consider enabling `ENABLE_GRAPH_LAYER` after measured lift
