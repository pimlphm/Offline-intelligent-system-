# As-Is System Audit

- Generated: 2026-04-18T09:03:52.889654+00:00
- Workspace: `C:\Users\weiku\Desktop\知识库`

## Summary

The current repository is a desktop-first knowledge assistant built around a PyQt GUI, a local lexical RAG index,
an ontology/graph store, and Ollama or vLLM-Ascend chat backends. It already parses multiple office/document formats
and can build graph structures from LLM analysis, but it is not yet a production-grade, phased RAG platform.

## Current Runtime

- Desktop entrypoint: `main.py`
- Packaging entrypoint: `build_app.py`
- Smoke pipeline: `pipelines/run_current.py`
- Configured backend: `ollama`

## Retrieval Stack

- Chunking is implemented in `core/rag_engine.py::_split_text` with character-oriented paragraph buffering.
- Retrieval is implemented in `core/rag_engine.py::search` using a BM25-style lexical scorer over in-memory chunks.
- The current persisted RAG index is `ontology/rag_index.json`.
- Missing target capabilities: dense retrieval, hybrid fusion, reranker, query rewrite, routing.

## Knowledge And Storage

- Graph storage exists in `ontology/knowledge_graph.json` and is managed by `core/ontology_engine.py`.
- Experience memory exists in `experience/_global/experience_index.json`.
- Standards content exists in `standards/` with `standards/standards_db.json`.
- No compiled wiki layer, entity pages, GraphML export pipeline, or layered retrieval path exists yet.

## UI And Ingestion

- The current interface is a PyQt desktop application in `gui/main_window.py`.
- Drag-and-drop upload is supported for local files.
- Document parsing covers PDF, DOCX, PPTX, XLSX, CSV, JSON, YAML, HTML, TXT, and Markdown through `core/doc_parser.py`.
- Missing target capabilities: browser SPA UI, chunked async upload, OCR extraction, image embeddings, dynamic tree growth in the web client.

## Evaluation And Operations

- Current testing is concentrated in `test_all.py`.
- No benchmark query set, eval suite, or phase-by-phase metric reports exist yet.
- No Docker Compose, monitoring, rollback, or security approval pipeline exists yet.

## Migration Gaps

- Current system is desktop-first, not API-first.
- Current retrieval is lexical only; no dense/hybrid/rerank stack exists.
- No compiled wiki/entity-topic knowledge layer is generated today.
- No phased orchestrator or gate-check existed before this upgrade slice.
- No benchmark/eval suite with gold sources and citation requirements exists yet.
- No Docker, monitoring, rollback, or write-approval security workflow exists yet.

## Immediate Next Step

Phase 0 can be considered bootstrapped once `inventory.json`, `as_is_system_audit.md`, and a successful
`pipelines/run_current` smoke report are all present. The next major work item is Phase 1: publish the target
architecture, migration plan, and compatibility/rollback boundaries.
