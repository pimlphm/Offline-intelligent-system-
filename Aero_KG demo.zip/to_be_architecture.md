# Target Architecture Blueprint

## Goal

Evolve the current desktop-first knowledge assistant into a production-grade RAG platform that is:

- service-oriented, while keeping the current PyQt desktop app usable during migration
- auditable through explicit phase gates and artifact logging
- rollback-safe through versioned models, indexes, and feature flags
- layered across raw retrieval, compiled knowledge, and agentic reasoning

## Design Principles

- Preserve the current `core/` and `gui/` paths until the new service path proves itself on the benchmark.
- Put all new production-facing code under `src/`, `knowledge/`, and `eval/`.
- Keep every experimental capability behind `config.yaml` switches.
- Separate ingestion, retrieval, generation, and orchestration responsibilities.
- Treat citations and audit logs as first-class outputs, not optional metadata.

## Target Layers

### 1. Raw Retrieval Layer

Purpose: ingest raw documents, segment them into structured chunks, and retrieve evidence quickly.

Primary modules:

- `knowledge/ingestion/segmenter.py`
- `knowledge/ingestion/extractor.py`
- `knowledge/ingestion/ingest_pipeline.py`
- `src/retrieval/bm25.py`
- `src/retrieval/dense.py`
- `src/retrieval/hybrid.py`
- `src/retrieval/reranker.py`
- `src/retrieval/routing.py`

Responsibilities:

- parse PDF, DOCX, CSV, XLSX, TXT, and Markdown using the existing parser stack
- segment diagnostic content into typed chunks such as `symptom`, `cause`, `rule`, `action`, and `evidence`
- store chunk payloads in `knowledge/chunks/` and `knowledge/chunks.db`
- expose sparse, dense, and fused retrieval through one service contract

### 2. Compiled Knowledge Layer

Purpose: transform raw chunks into durable, curated knowledge artifacts.

Primary modules:

- `knowledge/wiki/`
- `knowledge/graph/`
- future `wiki_builder.py`
- future `graph_builder.py`

Responsibilities:

- generate entity pages, topic pages, timelines, and FAQ summaries with citations
- publish graph-compatible outputs and graph schema definitions
- expose compiled knowledge as an optional retrieval tier

### 3. Agentic Reasoning Layer

Purpose: apply multi-step retrieval only to complex questions.

Primary modules:

- future `src/agentic/agentic_retrieval.py`
- future `src/agentic/graph.yaml`

Responsibilities:

- classify query complexity
- decide whether to stay in baseline retrieval or enter a retrieval-rewrite-retrieve loop
- self-check evidence completeness and citation coverage before answering

## Service Boundaries

### Program Manager

The Program Manager remains code-light and artifact-heavy:

- render phase packets
- record instructions and results in `orchestrator_log.json`
- gate later phases on deliverable presence and acceptance status

### Backend Service

The backend service becomes the stable API boundary:

- `/health`
- `/ingest`
- `/retrieve`
- `/generate`

Internal boundary:

- `src/backend/app.py` exposes the HTTP interface
- `src/backend/service.py` coordinates ingestion, retrieval, and generation
- `src/backend/providers/ollama.py` owns LLM and embedding calls

### Desktop UI Compatibility

The existing desktop app is preserved during migration:

- current `main.py` and `gui/main_window.py` continue to work
- the GUI may later call the new API instead of directly wiring `core/` objects
- no forced cutover happens before Phase 3 evaluation clears the gate

## Data Flow

1. Document enters via current GUI or future API upload.
2. Parser normalizes file content.
3. Segmenter emits structured chunks plus metadata.
4. Ingestion pipeline writes chunk JSON, SQLite rows, and wiki stubs.
5. Retrieval indexes refresh from chunk storage.
6. Query router selects baseline retrieval or future agentic flow.
7. Generator answers only from retrieved evidence and emits citations.
8. Evaluation harness records retrieval and generation errors separately.

## Compatibility And Rollout Strategy

### Keep

- `core/doc_parser.py` for multi-format extraction
- `core/rag_engine.py` as the current lexical baseline reference
- `core/llm_agent.py` for current desktop behavior during migration
- `ontology/` and `experience/` as legacy knowledge stores

### Add

- `src/` for production service modules
- `knowledge/` for chunk, wiki, and graph assets
- `eval/` and `eval_suite/` for benchmark execution

### Replace Later

- desktop-internal retrieval calls with `src/backend/service.py`
- ad hoc GUI orchestration with explicit API-driven workflows
- monolithic current indexing with a versioned retrieval index directory

## Rollback Points

- Model rollback: `versioning.active_model_version` and `previous_model_version`
- Index rollback: `versioning.active_index_version` and `previous_index_version`
- Feature rollback: all major upgrades guarded by `feature_flags`
- Service rollback: desktop app can keep using the legacy path if the API path fails

## First-Wave Upgrade Scope

The first production upgrade target is explicitly:

- hybrid retrieval
- service boundary
- benchmark-driven evaluation

Graph-first retrieval and agentic retrieval stay optional until benchmark gains justify rollout.

## Acceptance For Phase 1

- Hybrid retrieval is defined as the first-wave retrieval upgrade.
- Compatibility points are documented for GUI, current parser stack, and legacy stores.
- Rollback points exist for model, index, and feature switches.
- Module boundary diagram is published in `module_boundary.svg`.
