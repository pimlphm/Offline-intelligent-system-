from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Literal, Optional


Decision = Literal["PROCEED", "REVERT", "REWAIT"]


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class Assignment:
    role: str
    task: str


@dataclass(frozen=True)
class Deliverable:
    path: str
    format: str


@dataclass(frozen=True)
class PhaseDefinition:
    phase_id: int
    goal: str
    assignments: List[Assignment]
    deliverables: List[Deliverable]
    acceptance_criteria: List[str]
    notes: List[str] = field(default_factory=list)

    @property
    def name(self) -> str:
        return f"Phase {self.phase_id}"

    def render(self, decision: Decision = "REWAIT") -> str:
        lines = [f"<{self.name}>", f"Goal: {self.goal}", "Assignments:"]
        lines.extend(f"  - {item.role}: {item.task}" for item in self.assignments)
        lines.append("Deliverables:")
        lines.extend(
            f"  - {item.path} ({item.path}, {item.format})"
            for item in self.deliverables
        )
        lines.append("AcceptanceCriteria:")
        lines.extend(f"  - {criterion}" for criterion in self.acceptance_criteria)
        lines.append(f"Decision: {decision}")
        return "\n".join(lines)


def build_default_phases() -> Dict[int, PhaseDefinition]:
    return {
        0: PhaseDefinition(
            phase_id=0,
            goal="Generate a complete as-is audit of the current system and verify the current end-to-end request path.",
            assignments=[
                Assignment("Chief Architect", "Document the current module boundaries, runtime path, and upgrade constraints."),
                Assignment("Knowledge Engineer", "Inventory current document ingestion, parsing, chunking, and metadata behavior."),
                Assignment("Retrieval Scientist", "Audit the current retrieval stack, ranking logic, and known gaps."),
                Assignment("Backend Engineer", "Identify current entrypoints and create a reproducible smoke path for the existing system."),
                Assignment("Program Manager (Orchestrator)", "Record the instruction packet and all outputs to orchestrator_log.json."),
            ],
            deliverables=[
                Deliverable("as_is_system_audit.md", "markdown"),
                Deliverable("inventory.json", "json"),
            ],
            acceptance_criteria=[
                "All current modules are described with source-file references.",
                "A runnable current-system smoke command exists at pipelines/run_current.sh or pipelines/run_current.ps1.",
                "The audit explicitly separates current capabilities from migration gaps.",
            ],
        ),
        1: PhaseDefinition(
            phase_id=1,
            goal="Publish the target architecture, migration blueprint, compatibility boundaries, and rollback plan.",
            assignments=[
                Assignment("Chief Architect", "Design the target three-layer RAG architecture and migration sequence."),
                Assignment("Retrieval Scientist", "Define the first hybrid retrieval milestone and the retrieval service contract."),
                Assignment("Reliability Engineer", "Define rollback points for model and index transitions."),
                Assignment("Program Manager (Orchestrator)", "Hold the phase until architecture docs and compatibility points exist."),
            ],
            deliverables=[
                Deliverable("to_be_architecture.md", "markdown"),
                Deliverable("module_boundary.svg", "svg"),
                Deliverable("migration_plan.md", "markdown"),
                Deliverable("risk_matrix.md", "markdown"),
            ],
            acceptance_criteria=[
                "Hybrid Retrieval is explicitly called out as a first-wave upgrade.",
                "Compatibility points and rollback points are listed for each migration step.",
            ],
        ),
        2: PhaseDefinition(
            phase_id=2,
            goal="Create the benchmark set, evaluation specification, and executable offline evaluation suite.",
            assignments=[
                Assignment("Evaluation Lead", "Build 50-200 real queries with gold sources and citation requirements."),
                Assignment("Security / Governance Reviewer", "Add safety and citation compliance checks to the evaluation spec."),
                Assignment("Backend Engineer", "Provide evaluation harness hooks for retrieval and generation logging."),
                Assignment("Program Manager (Orchestrator)", "Block later phases until the benchmark and eval suite exist."),
            ],
            deliverables=[
                Deliverable("eval/benchmark_queries.json", "json"),
                Deliverable("eval/eval_spec.md", "markdown"),
                Deliverable("eval/run_all.py", "python"),
                Deliverable("eval_suite", "directory"),
            ],
            acceptance_criteria=[
                "Each query has a gold source, expected answer type, and citation requirement.",
                "Evaluation distinguishes retrieval errors from generation errors.",
            ],
        ),
        3: PhaseDefinition(
            phase_id=3,
            goal="Implement the baseline production-ready RAG path with ingestion, hybrid retrieval, API endpoints, and operations basics.",
            assignments=[
                Assignment("Knowledge Engineer", "Build raw-to-chunk ingestion with structured metadata and persistent markdown wiki output."),
                Assignment("Retrieval Scientist", "Implement dense + BM25 hybrid retrieval, reranking, and query rewrite."),
                Assignment("Backend Engineer", "Expose /ingest, /retrieve, and /generate via FastAPI with Ollama providers."),
                Assignment("Reliability Engineer", "Add docker-compose, startup scripts, and logging collection."),
            ],
            deliverables=[
                Deliverable("src/backend/app.py", "python"),
                Deliverable("src/retrieval/hybrid.py", "python"),
                Deliverable("knowledge/chunks", "directory"),
                Deliverable("knowledge/wiki", "directory"),
                Deliverable("baseline_eval_report.md", "markdown"),
            ],
            acceptance_criteria=[
                "Recall@10 improves by at least 10 percent over the Phase 2 baseline.",
                "Responses always include evidence citation.",
            ],
        ),
        4: PhaseDefinition(
            phase_id=4,
            goal="Add query routing, multi-step retrieval, and self-check for complex questions only.",
            assignments=[
                Assignment("Retrieval Scientist", "Implement decide-to-retrieve routing and multi-step retrieval."),
                Assignment("Backend Engineer", "Expose the agentic retrieval path behind a config switch."),
                Assignment("Evaluation Lead", "Measure faithfulness and latency impact on the complex-query slice."),
            ],
            deliverables=[
                Deliverable("src/agentic/agentic_retrieval.py", "python"),
                Deliverable("src/agentic/graph.yaml", "yaml"),
                Deliverable("agentic_eval_report.md", "markdown"),
            ],
            acceptance_criteria=[
                "Agentic retrieval is only used for the complex-query subset.",
                "Overall latency growth stays within the agreed threshold.",
            ],
        ),
        5: PhaseDefinition(
            phase_id=5,
            goal="Compile persistent wiki and graph knowledge layers and fuse them with raw retrieval.",
            assignments=[
                Assignment("Knowledge Engineer", "Build persistent wiki/entity/topic pages with citations."),
                Assignment("Graph / Memory Designer", "Build the knowledge graph and the layered retrieval path."),
                Assignment("Retrieval Scientist", "Fuse graph signals with raw retrieval without forcing production rollout."),
            ],
            deliverables=[
                Deliverable("compiled_knowledge", "directory"),
                Deliverable("knowledge/graph/schema.yaml", "yaml"),
                Deliverable("knowledge/graph/graph_builder.py", "python"),
                Deliverable("layered_eval_report.md", "markdown"),
            ],
            acceptance_criteria=[
                "Multi-hop and temporal recall improve over the baseline by the target amount.",
                "Graph layer remains optional until it shows measurable gain.",
            ],
        ),
        6: PhaseDefinition(
            phase_id=6,
            goal="Harden the platform with performance tuning, CI/CD, monitoring, rollback, and security review.",
            assignments=[
                Assignment("Reliability Engineer", "Add versioned rollback, monitoring, and production compose files."),
                Assignment("Security / Governance Reviewer", "Implement write-approval hooks, prompt-injection checks, and audit coverage."),
                Assignment("Backend Engineer", "Integrate CI/CD and production deployment wiring."),
            ],
            deliverables=[
                Deliverable("docker-compose.prod.yml", "yaml"),
                Deliverable("monitoring", "directory"),
                Deliverable("ci", "directory"),
                Deliverable("security_audit_report.md", "markdown"),
            ],
            acceptance_criteria=[
                "Rollback artifacts exist for model and index changes.",
                "Security audit gates protect all knowledge-base write operations.",
            ],
        ),
    }


class ProgramManager:
    def __init__(
        self,
        workspace_root: Path | str,
        log_path: Path | str | None = None,
        phases: Optional[Dict[int, PhaseDefinition]] = None,
    ) -> None:
        self.workspace_root = Path(workspace_root).resolve()
        self.log_path = (
            Path(log_path).resolve()
            if log_path
            else self.workspace_root / "orchestrator_log.json"
        )
        self.phases = phases or build_default_phases()

    def get_phase(self, phase_id: int) -> PhaseDefinition:
        if phase_id not in self.phases:
            raise KeyError(f"Unknown phase: {phase_id}")
        return self.phases[phase_id]

    def render_phase_packet(self, phase_id: int, decision: Decision = "REWAIT") -> str:
        return self.get_phase(phase_id).render(decision=decision)

    def gate_check(self, phase_id: int) -> Dict[str, object]:
        phase = self.get_phase(phase_id)
        deliverables = {}
        for item in phase.deliverables:
            deliverables[item.path] = (self.workspace_root / item.path).exists()
        passed = all(deliverables.values())
        return {
            "phase_id": phase_id,
            "passed": passed,
            "deliverables": deliverables,
            "checked_at": utc_now_iso(),
        }

    def record_instruction(self, phase_id: int, note: str = "") -> Dict[str, object]:
        phase = self.get_phase(phase_id)
        record = {
            "timestamp": utc_now_iso(),
            "record_type": "instruction",
            "phase_id": phase.phase_id,
            "phase_name": phase.name,
            "goal": phase.goal,
            "assignments": [asdict(item) for item in phase.assignments],
            "deliverables": [asdict(item) for item in phase.deliverables],
            "acceptance_criteria": phase.acceptance_criteria,
            "notes": [note] if note else [],
            "decision": "REWAIT",
            "rendered": phase.render(decision="REWAIT"),
        }
        self._append_record(record)
        return record

    def record_result(
        self,
        phase_id: int,
        decision: Decision,
        artifacts: Optional[Iterable[str]] = None,
        notes: Optional[Iterable[str]] = None,
        acceptance_results: Optional[Dict[str, object]] = None,
    ) -> Dict[str, object]:
        phase = self.get_phase(phase_id)
        gate = self.gate_check(phase_id)
        record = {
            "timestamp": utc_now_iso(),
            "record_type": "result",
            "phase_id": phase.phase_id,
            "phase_name": phase.name,
            "goal": phase.goal,
            "artifacts": list(artifacts or []),
            "acceptance_results": acceptance_results or {},
            "gate_check": gate,
            "notes": list(notes or []),
            "decision": decision,
            "rendered": phase.render(decision=decision),
        }
        self._append_record(record)
        return record

    def _append_record(self, record: Dict[str, object]) -> None:
        payload = self._read_log()
        payload["updated_at"] = utc_now_iso()
        payload.setdefault("records", []).append(record)
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _read_log(self) -> Dict[str, object]:
        if not self.log_path.exists():
            return {
                "workspace_root": str(self.workspace_root),
                "created_at": utc_now_iso(),
                "updated_at": utc_now_iso(),
                "records": [],
            }
        try:
            return json.loads(self.log_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {
                "workspace_root": str(self.workspace_root),
                "created_at": utc_now_iso(),
                "updated_at": utc_now_iso(),
                "records": [],
            }


def main() -> int:
    parser = argparse.ArgumentParser(description="Render or log phased Program Manager packets.")
    parser.add_argument("--workspace-root", default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument(
        "--action",
        choices=["show", "log-instruction", "gate-check"],
        default="show",
    )
    args = parser.parse_args()

    manager = ProgramManager(args.workspace_root)
    if args.action == "show":
        print(manager.render_phase_packet(args.phase))
        return 0
    if args.action == "log-instruction":
        print(manager.record_instruction(args.phase)["rendered"])
        return 0

    print(json.dumps(manager.gate_check(args.phase), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
