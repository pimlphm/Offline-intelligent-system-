from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
OUTPUT_PATH = ROOT / "eval" / "benchmark_queries.json"


DOCS = [
    {
        "key": "A320neo_Engine_Control_Software_Spec.md",
        "label": "A320neo engine control software specification",
        "focus": "engine control software behavior",
        "cert": "software certification expectations",
        "theme": "software specification",
    },
    {
        "key": "A320neo_FBW_DO178C_Certification.md",
        "label": "A320neo fly-by-wire DO-178C certification package",
        "focus": "fly-by-wire certification and traceability",
        "cert": "DO-178C evidence and DAL discussion",
        "theme": "certification package",
    },
    {
        "key": "A350_EWIS_Certification_ARP4754A.md",
        "label": "A350 EWIS ARP4754A development package",
        "focus": "EWIS development and certification",
        "cert": "ARP4754A lifecycle evidence",
        "theme": "EWIS system engineering",
    },
    {
        "key": "A350_Flight_Control_System_Design.md",
        "label": "A350 flight control system design document",
        "focus": "flight control system design",
        "cert": "design constraints and control architecture",
        "theme": "system design",
    },
    {
        "key": "A350_MBSE_Knowledge_Engineering.md",
        "label": "A350 MBSE knowledge engineering guide",
        "focus": "MBSE and knowledge engineering",
        "cert": "model-based lifecycle structure",
        "theme": "MBSE guidance",
    },
    {
        "key": "B777X_Composite_Wing_Structure_Analysis.md",
        "label": "B777X composite wing structure analysis",
        "focus": "composite wing structure analysis",
        "cert": "structural analysis evidence",
        "theme": "composite structure",
    },
    {
        "key": "B777X_FCS_MBSE_Capella_Model.md",
        "label": "B777X FCS Capella MBSE model",
        "focus": "Capella-based flight control architecture",
        "cert": "MBSE architecture model",
        "theme": "Capella model",
    },
    {
        "key": "B787_Digital_Thread_Ontology_Framework.md",
        "label": "B787 digital thread ontology framework",
        "focus": "ontology and digital thread structure",
        "cert": "knowledge graph and ontology alignment",
        "theme": "digital thread ontology",
    },
    {
        "key": "B787_ECS_Safety_Assessment_FHA_PSSA.md",
        "label": "B787 ECS FHA/PSSA safety assessment",
        "focus": "safety assessment findings",
        "cert": "FHA and PSSA evidence",
        "theme": "safety assessment",
    },
    {
        "key": "B787_Electrical_Power_System_Requirements.md",
        "label": "B787 electrical power system requirements",
        "focus": "electrical power requirements",
        "cert": "requirements and standards references",
        "theme": "requirements specification",
    },
]


PAIR_QUERIES = [
    (
        "A320neo_FBW_DO178C_Certification.md",
        "A350_Flight_Control_System_Design.md",
        "Which document should be cited for certification traceability versus design architecture in Airbus flight control work?",
    ),
    (
        "A350_MBSE_Knowledge_Engineering.md",
        "B777X_FCS_MBSE_Capella_Model.md",
        "Which file covers MBSE knowledge engineering guidance and which one covers a concrete Capella flight-control model?",
    ),
    (
        "B787_Electrical_Power_System_Requirements.md",
        "B787_ECS_Safety_Assessment_FHA_PSSA.md",
        "Which B787 file should answer a power-system requirements question and which one should answer an ECS safety-assessment question?",
    ),
    (
        "B787_Digital_Thread_Ontology_Framework.md",
        "A350_MBSE_Knowledge_Engineering.md",
        "Which source should be cited for digital-thread ontology structure and which for Airbus MBSE knowledge engineering practice?",
    ),
    (
        "B777X_Composite_Wing_Structure_Analysis.md",
        "A350_EWIS_Certification_ARP4754A.md",
        "Which document is structural-analysis evidence and which one is EWIS lifecycle certification evidence?",
    ),
    (
        "A320neo_Engine_Control_Software_Spec.md",
        "A320neo_FBW_DO178C_Certification.md",
        "Which A320neo file is software-behavior focused and which one is certification-package focused?",
    ),
    (
        "B777X_FCS_MBSE_Capella_Model.md",
        "B787_Digital_Thread_Ontology_Framework.md",
        "Compare the scope of the B777X Capella model document with the B787 ontology framework document.",
    ),
    (
        "A350_Flight_Control_System_Design.md",
        "B777X_Composite_Wing_Structure_Analysis.md",
        "Which source should be used for flight-control design details and which for composite wing analysis?",
    ),
    (
        "A350_EWIS_Certification_ARP4754A.md",
        "B787_Electrical_Power_System_Requirements.md",
        "Which file is the better citation for EWIS lifecycle evidence and which for electrical power requirements?",
    ),
    (
        "B787_ECS_Safety_Assessment_FHA_PSSA.md",
        "A320neo_FBW_DO178C_Certification.md",
        "Which file is safety-assessment oriented and which one is software-certification oriented?",
    ),
]


MULTIHOP_QUERIES = [
    (
        ["A350_MBSE_Knowledge_Engineering.md", "A350_Flight_Control_System_Design.md"],
        "Identify the document that explains Airbus MBSE practice and the document that explains Airbus flight-control design implementation.",
    ),
    (
        ["B787_Digital_Thread_Ontology_Framework.md", "B787_Electrical_Power_System_Requirements.md"],
        "Which B787 document describes ontology/digital-thread structure, and which one gives concrete electrical power requirements?",
    ),
    (
        ["B777X_FCS_MBSE_Capella_Model.md", "A350_MBSE_Knowledge_Engineering.md"],
        "If a user asks for both an MBSE method guide and a concrete MBSE model example, which two files should be retrieved?",
    ),
    (
        ["B787_ECS_Safety_Assessment_FHA_PSSA.md", "A320neo_FBW_DO178C_Certification.md"],
        "Which sources should be paired to contrast safety-assessment evidence with DO-178C traceability evidence?",
    ),
    (
        ["B777X_Composite_Wing_Structure_Analysis.md", "B787_Electrical_Power_System_Requirements.md"],
        "Which files together cover structural-analysis content and electrical-requirements content for Boeing programs?",
    ),
    (
        ["A350_EWIS_Certification_ARP4754A.md", "B787_Digital_Thread_Ontology_Framework.md"],
        "Which files would you cite for lifecycle certification structure plus ontology alignment?",
    ),
    (
        ["A320neo_Engine_Control_Software_Spec.md", "A320neo_FBW_DO178C_Certification.md"],
        "Retrieve the two A320neo files needed to answer one software-spec question and one certification-traceability question.",
    ),
    (
        ["A350_Flight_Control_System_Design.md", "B777X_FCS_MBSE_Capella_Model.md"],
        "Which files together cover flight-control design and MBSE architecture modeling across Airbus and Boeing examples?",
    ),
    (
        ["B787_ECS_Safety_Assessment_FHA_PSSA.md", "A350_EWIS_Certification_ARP4754A.md"],
        "Which files should be cited together for safety/lifecycle evidence across ECS and EWIS domains?",
    ),
    (
        ["A350_MBSE_Knowledge_Engineering.md", "B787_Digital_Thread_Ontology_Framework.md"],
        "Which files together provide a knowledge-engineering view and an ontology-framework view of aviation knowledge systems?",
    ),
]


def build_benchmark() -> list[dict]:
    entries: list[dict] = []
    next_id = 1

    for doc in DOCS:
        entries.append(
            {
                "id": f"BQ-{next_id:03d}",
                "query": f"Summarize the main scope of the {doc['label']}.",
                "gold_sources": [doc["key"]],
                "expected_answer_type": "summary",
                "citation_requirement": "Must cite the exact source filename.",
                "complexity": "simple",
                "query_family": "single_doc_summary",
            }
        )
        next_id += 1
        entries.append(
            {
                "id": f"BQ-{next_id:03d}",
                "query": f"What certification or standards angle is emphasized in the {doc['label']}?",
                "gold_sources": [doc["key"]],
                "expected_answer_type": "standards_or_certification_focus",
                "citation_requirement": "Must cite the exact source filename.",
                "complexity": "simple",
                "query_family": "single_doc_certification",
            }
        )
        next_id += 1
        entries.append(
            {
                "id": f"BQ-{next_id:03d}",
                "query": f"Which source should answer a question about {doc['focus']}?",
                "gold_sources": [doc["key"]],
                "expected_answer_type": "source_selection",
                "citation_requirement": "Must cite the exact source filename.",
                "complexity": "medium",
                "query_family": "source_selection",
            }
        )
        next_id += 1

    for left, right, query in PAIR_QUERIES:
        entries.append(
            {
                "id": f"BQ-{next_id:03d}",
                "query": query,
                "gold_sources": [left, right],
                "expected_answer_type": "comparison",
                "citation_requirement": "Must cite both filenames.",
                "complexity": "complex",
                "query_family": "paired_comparison",
            }
        )
        next_id += 1

    for gold_sources, query in MULTIHOP_QUERIES:
        entries.append(
            {
                "id": f"BQ-{next_id:03d}",
                "query": query,
                "gold_sources": gold_sources,
                "expected_answer_type": "multi_source_selection",
                "citation_requirement": "Must cite every supporting filename.",
                "complexity": "complex",
                "query_family": "multi_hop_source_selection",
            }
        )
        next_id += 1

    return entries


def main() -> int:
    benchmark = build_benchmark()
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(json.dumps(benchmark, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Wrote {len(benchmark)} benchmark queries to {OUTPUT_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
