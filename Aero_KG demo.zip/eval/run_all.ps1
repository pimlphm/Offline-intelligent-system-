param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ArgsList
)

$RootDir = Split-Path -Parent $PSScriptRoot
Set-Location $RootDir

$Candidates = @()
if ($env:KNOWLEDGE_RAG_PYTHON) {
    $Candidates += $env:KNOWLEDGE_RAG_PYTHON
}

$Candidates += @(
    "$env:USERPROFILE\.conda\envs\PHMagent\python.exe",
    "$env:USERPROFILE\.conda\envs\copaw\python.exe",
    "$env:USERPROFILE\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
)

foreach ($Candidate in $Candidates) {
    if ($Candidate -and (Test-Path $Candidate)) {
        & $Candidate eval/run_all.py @ArgsList
        exit $LASTEXITCODE
    }
}

throw "No usable Python interpreter found. Set KNOWLEDGE_RAG_PYTHON to a real python.exe path."
