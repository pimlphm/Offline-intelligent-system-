#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

PYTHON_BIN="${KNOWLEDGE_RAG_PYTHON:-}"

if [[ -z "$PYTHON_BIN" ]]; then
  if command -v python3 >/dev/null 2>&1; then
    PYTHON_BIN="python3"
  elif command -v python >/dev/null 2>&1; then
    PYTHON_BIN="python"
  else
    echo "No usable Python interpreter found. Set KNOWLEDGE_RAG_PYTHON first." >&2
    exit 1
  fi
fi

"$PYTHON_BIN" eval/run_all.py "$@"
