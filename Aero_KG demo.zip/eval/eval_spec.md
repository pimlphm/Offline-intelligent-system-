# Evaluation Specification

## Benchmark Schema

Each benchmark entry in `benchmark_queries.json` must contain:

- `id`
- `query`
- `gold_sources`
- `expected_answer_type`
- `citation_requirement`
- `complexity`
- `query_family`

## Required Metrics

### Retrieval

- Recall@10
- MRR
- hit count by complexity
- retrieval error count

Retrieval error definition:

- none of the `gold_sources` appear in the retrieved document list

### Generation

- citation precision proxy
- generation error count

Generation error definition:

- retrieval hit exists, but the final answer does not cite any required gold source

### System

- total benchmark size
- mean latency
- p90 latency
- mode used: `current` or `service`

## Execution Modes

### current

Runs the benchmark against the current smoke pipeline in `pipelines/run_current.py`.

### service

Runs the benchmark against the new service layer in `src/backend/service.py`.

## Reporting

`eval/run_all.py` writes:

- JSON summary under `output/reports/eval/`
- Markdown summary under `output/reports/eval/`

## Acceptance Intent

- Phase 2 is complete once the benchmark, schema tests, and runnable benchmark harness all exist.
- Later phases must use this benchmark before feature rollouts are accepted.
