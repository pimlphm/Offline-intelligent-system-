from __future__ import annotations

import argparse
import copy
import json
import statistics
import sys
import time
from pathlib import Path
from typing import Callable, Dict, Iterable, List

import yaml


ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pipelines.run_current import run_current_pipeline


def load_config() -> dict:
    return yaml.safe_load((ROOT / "config.yaml").read_text(encoding="utf-8"))


def load_benchmark(path: Path) -> list[dict]:
    return json.loads(path.read_text(encoding="utf-8"))


def reciprocal_rank(retrieved_docs: Iterable[str], gold_sources: Iterable[str]) -> float:
    gold = set(gold_sources)
    for idx, name in enumerate(retrieved_docs, start=1):
        if name in gold:
            return 1.0 / idx
    return 0.0


def citation_precision(answer: str, gold_sources: list[str]) -> float:
    if not gold_sources:
        return 1.0
    hits = sum(1 for item in gold_sources if item in answer)
    return hits / len(gold_sources)


def current_executor(query: str) -> dict:
    return run_current_pipeline(query=query, use_llm=False)


def service_executor_factory() -> Callable[[str], dict]:
    from src.backend.service import KnowledgeBaseService

    service = KnowledgeBaseService(load_config())
    if not service.has_chunks():
        docs = [str(path) for path in sorted((ROOT / "docs").glob("demo_*/*.md"))]
        service.ingest_paths(docs)

    def execute(query: str) -> dict:
        return service.generate(query, use_llm=False)

    return execute


def agentic_executor_factory() -> Callable[[str], dict]:
    from src.backend.service import KnowledgeBaseService

    config = copy.deepcopy(load_config())
    config.setdefault("feature_flags", {})["ENABLE_AGENTIC"] = True
    config.setdefault("agentic", {})["max_steps"] = 3
    service = KnowledgeBaseService(config)
    if not service.has_chunks():
        docs = [str(path) for path in sorted((ROOT / "docs").glob("demo_*/*.md"))]
        service.ingest_paths(docs)

    def execute(query: str) -> dict:
        return service.generate(query, use_llm=False)

    return execute


def evaluate(mode: str, benchmark: list[dict]) -> dict:
    if mode == "current":
        executor = current_executor
    elif mode == "agentic":
        executor = agentic_executor_factory()
    else:
        executor = service_executor_factory()
    rows = []
    latencies = []

    for item in benchmark:
        started = time.perf_counter()
        result = executor(item["query"])
        elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
        latencies.append(elapsed_ms)

        retrieval_results = result.get("retrieval_results", [])
        retrieved_docs = [entry.get("doc_name", "") for entry in retrieval_results]
        hit = any(source in retrieved_docs for source in item["gold_sources"])
        mrr = reciprocal_rank(retrieved_docs, item["gold_sources"])
        answer_text = result.get("answer", "")
        citation_score = citation_precision(answer_text, item["gold_sources"])
        self_check = result.get("self_check", {})

        rows.append(
            {
                "id": item["id"],
                "query": item["query"],
                "complexity": item["complexity"],
                "gold_sources": item["gold_sources"],
                "retrieved_docs": retrieved_docs,
                "retrieval_hit": hit,
                "mrr": mrr,
                "citation_precision": citation_score,
                "retrieval_error": not hit,
                "generation_error": hit and citation_score == 0.0,
                "latency_ms": elapsed_ms,
                "agentic_used": bool(result.get("agentic_used", False)),
                "self_check_score": self_check.get("score"),
            }
        )

    recall = sum(1 for row in rows if row["retrieval_hit"]) / len(rows) if rows else 0.0
    mean_latency = statistics.mean(latencies) if latencies else 0.0
    p90_latency = statistics.quantiles(latencies, n=10)[-1] if len(latencies) >= 10 else max(latencies or [0.0])
    self_check_scores = [row["self_check_score"] for row in rows if row["self_check_score"] is not None]

    return {
        "mode": mode,
        "benchmark_size": len(rows),
        "metrics": {
            "recall_at_10": round(recall, 4),
            "mrr": round(sum(row["mrr"] for row in rows) / len(rows), 4) if rows else 0.0,
            "citation_precision": round(
                sum(row["citation_precision"] for row in rows) / len(rows), 4
            )
            if rows
            else 0.0,
            "retrieval_errors": sum(1 for row in rows if row["retrieval_error"]),
            "generation_errors": sum(1 for row in rows if row["generation_error"]),
            "latency_mean_ms": round(mean_latency, 2),
            "latency_p90_ms": round(p90_latency, 2),
            "agentic_requests": sum(1 for row in rows if row["agentic_used"]),
            "agentic_usage_rate": round(sum(1 for row in rows if row["agentic_used"]) / len(rows), 4)
            if rows
            else 0.0,
            "self_check_mean": round(statistics.mean(self_check_scores), 4) if self_check_scores else 0.0,
        },
        "results": rows,
    }


def write_report(report: dict, output_dir: Path, phase_label: str) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / f"eval_report_{phase_label}.json"
    md_path = output_dir / f"eval_report_{phase_label}.md"

    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    metrics = report["metrics"]
    md_lines = [
        f"# Evaluation Report ({phase_label})",
        "",
        f"- Mode: `{report['mode']}`",
        f"- Benchmark size: `{report['benchmark_size']}`",
        f"- Recall@10: `{metrics['recall_at_10']}`",
        f"- MRR: `{metrics['mrr']}`",
        f"- Citation precision: `{metrics['citation_precision']}`",
        f"- Retrieval errors: `{metrics['retrieval_errors']}`",
        f"- Generation errors: `{metrics['generation_errors']}`",
        f"- Mean latency (ms): `{metrics['latency_mean_ms']}`",
        f"- P90 latency (ms): `{metrics['latency_p90_ms']}`",
        f"- Agentic requests: `{metrics.get('agentic_requests', 0)}`",
        f"- Agentic usage rate: `{metrics.get('agentic_usage_rate', 0.0)}`",
        f"- Self-check mean: `{metrics.get('self_check_mean', 0.0)}`",
        "",
    ]
    md_path.write_text("\n".join(md_lines), encoding="utf-8")
    return json_path, md_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the benchmark suite against the current or service pipeline.")
    parser.add_argument("--mode", choices=["current", "service", "agentic"], default="current")
    parser.add_argument("--phase-label", default="phase2_baseline")
    parser.add_argument("--complexity", choices=["all", "simple", "medium", "complex"], default="all")
    args = parser.parse_args()

    config = load_config()
    benchmark_path = ROOT / config["evaluation"]["benchmark_path"]
    benchmark = load_benchmark(benchmark_path)
    if args.complexity != "all":
        benchmark = [item for item in benchmark if item.get("complexity") == args.complexity]
    report = evaluate(args.mode, benchmark)
    output_dir = ROOT / config["evaluation"]["output_report_dir"]
    json_path, md_path = write_report(report, output_dir, args.phase_label)
    print(json.dumps({"json": str(json_path), "markdown": str(md_path), "metrics": report["metrics"]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
