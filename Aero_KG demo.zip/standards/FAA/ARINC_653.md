# ARINC 653

**航电应用标准软件接口(APEX)**

*Avionics Application Standard Software Interface*

| 属性 | 内容 |
|------|------|
| 适航当局 | 美国联邦航空管理局 (FAA) |
| 类别 | 航电标准 (Avionics Standards) |
| 发布机构 | AEEC / SAE ITC |

## 适用范围

IMA(综合模块化航电)的分区操作系统标准。定义时间和空间分区，保证不同DAL等级的软件在同一硬件上运行的安全隔离。

## 交叉引用(等效标准)

- DO-297
