# 14 CFR Part 25

**运输类飞机适航标准**

*Airworthiness Standards: Transport Category Airplanes*

| 属性 | 内容 |
|------|------|
| 适航当局 | 美国联邦航空管理局 (FAA) |
| 类别 | 适航规章 (Airworthiness Regulations) |

## 适用范围

运输类飞机型号合格审定的最低安全标准

*Minimum safety standards for type certification of transport category airplanes*

## 关键条款

### 设备、系统和安装
*Equipment, Systems, and Installations*

要求系统设计使得单一失效不会导致灾难性后果。灾难性失效概率<1×10⁻⁹/飞行小时。建立失效严重性分类: 灾难/危险/重大/轻微/无影响。

**DAL相关性**: 定义了DAL分配的基础框架

### 飞行控制系统通则
*General (Flight Controls)*

飞行控制系统应确保在正常和故障条件下安全飞行和着陆。

### 通风
*Ventilation*

座舱新鲜空气流量不低于4.7升/秒/人。CO₂浓度限制。

### 增压座舱
*Pressurized Cabins*

正常运行时座舱高度不超过8000英尺(2438米)。

### 燃油箱点火防护
*Fuel Tank Ignition Prevention*

燃油箱区域不得存在电弧、热源等点火源。

### 电气设备和安装
*Electrical Equipment and Installations*

电气系统设计、安装和维护应防止危险。

### 电气线路互联系统(EWIS)
*Electrical Wiring Interconnection System*

EWIS作为型号设计的一部分，需满足防火、分离、标识等要求。

## 交叉引用(等效标准)

- CS-25
- CCAR-25
