# CTSO-C153

**中国技术标准规定: 机载软件**

*Chinese Technical Standard Order: Airborne Software*

| 属性 | 内容 |
|------|------|
| 适航当局 | 中国民用航空局 (CAAC) |
| 类别 | 软件适航 (Software Certification) |

## 适用范围

CAAC对DO-178C的认可技术标准。要求国产民机软件按DO-178C标准开发。

## 交叉引用(等效标准)

- DO-178C
- ED-12C
