# ED-12C

**机载系统和设备中的软件考虑**

*Software Considerations in Airborne Systems and Equipment Certification*

| 属性 | 内容 |
|------|------|
| 适航当局 | 欧洲航空安全局 (EASA) |
| 类别 | 软件适航 (Software Certification) |
| 发布机构 | EUROCAE |

## 适用范围

DO-178C的欧洲等效文件。EASA认可的软件适航标准。内容与DO-178C完全一致。

## 交叉引用(等效标准)

- DO-178C

## 备注

ED-12C与DO-178C技术内容完全相同，是中欧联合制定的双标准号文件。
