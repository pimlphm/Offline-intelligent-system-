# ED-79A

**民用飞机和系统研制指南**

*Guidelines for Development of Civil Aircraft and Systems*

| 属性 | 内容 |
|------|------|
| 适航当局 | 欧洲航空安全局 (EASA) |
| 类别 | 系统研制 (System Development) |
| 发布机构 | EUROCAE |

## 适用范围

ARP4754A的EASA认可等效文件。

## 交叉引用(等效标准)

- ARP4754A
