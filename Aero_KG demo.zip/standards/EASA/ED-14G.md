# ED-14G

**机载设备环境条件和试验程序**

*Environmental Conditions and Test Procedures for Airborne Equipment*

| 属性 | 内容 |
|------|------|
| 适航当局 | 欧洲航空安全局 (EASA) |
| 类别 | 环境试验 (Environmental Testing) |
| 发布机构 | EUROCAE |

## 适用范围

DO-160G的欧洲等效文件。

## 交叉引用(等效标准)

- DO-160G
