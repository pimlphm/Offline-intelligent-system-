@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion
title AeroKB Agent - Install Deps
cd /d "%~dp0"

echo ============================================
echo   AeroKB Agent - Install Dependencies
echo ============================================
echo.

echo Finding Python...
set PY=
if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PY=C:\ProgramData\anaconda3\python.exe"
    echo   Using Anaconda Python
) else (
    where python >nul 2>&1
    if !errorlevel! equ 0 (
        set "PY=python"
        echo   Using system Python
    ) else (
        echo   [ERROR] Python not found
        echo   Please install Python 3.10+ or Anaconda
        pause
        exit /b 1
    )
)

echo.
echo Installing dependencies...
"!PY!" -m pip install -r requirements.txt

echo.
if !errorlevel! equ 0 (
    echo ============================================
    echo   Install complete!
    echo   Run the start script to launch
    echo ============================================
) else (
    echo [WARN] Some dependencies failed
    echo Check network and retry
)

echo.
pause
endlocal