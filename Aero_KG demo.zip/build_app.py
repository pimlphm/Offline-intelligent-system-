"""
航空知识库Agent - 一键打包脚本
========================================
使用PyInstaller打包为独立可执行文件，
然后用Inno Setup生成Windows安装程序。

用法:
  python build_app.py           # 仅PyInstaller打包
  python build_app.py --inno    # 打包 + 生成安装程序(需安装Inno Setup)
"""
import subprocess
import sys
import os
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DIST = ROOT / "dist"
BUILD = ROOT / "build"
APP_NAME = "航空知识库Agent"
VERSION = "1.0.0"
ICON_PATH = ROOT / "app_icon.ico"
EXE_NAME = "AeroKnowledgeAgent"


def ensure_pyinstaller():
    try:
        import PyInstaller
    except ImportError:
        print("[INFO] 正在安装 PyInstaller ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])


def create_icon_if_missing():
    if ICON_PATH.exists():
        return
    try:
        from PIL import Image, ImageDraw, ImageFont
        size = 256
        img = Image.new("RGBA", (size, size), (13, 17, 23, 255))
        draw = ImageDraw.Draw(img)
        draw.rounded_rectangle([20, 20, 236, 236], radius=40,
                               fill=(22, 27, 34, 255), outline=(88, 166, 255, 255),
                               width=4)
        try:
            font = ImageFont.truetype("msyh.ttc", 64)
        except Exception:
            font = ImageFont.load_default()
        draw.text((size // 2, size // 2 - 10), "KB",
                  fill=(88, 166, 255, 255), font=font, anchor="mm")
        draw.text((size // 2, size // 2 + 50), "Agent",
                  fill=(201, 209, 217, 200), font=ImageFont.load_default(),
                  anchor="mm")
        img.save(str(ICON_PATH), format="ICO")
        print(f"[OK] 生成图标: {ICON_PATH}")
    except ImportError:
        print("[WARN] 未安装Pillow, 使用无图标模式")


def run_pyinstaller():
    print("=" * 60)
    print(f"  {APP_NAME} v{VERSION} - PyInstaller 打包")
    print("=" * 60)

    if DIST.exists():
        shutil.rmtree(DIST)
    if BUILD.exists():
        shutil.rmtree(BUILD)

    data_dirs = [
        ("docs", "docs"),
        ("lib", "lib"),
        ("standards", "standards"),
        ("config.yaml", "."),
    ]

    add_data_args = []
    for src, dst in data_dirs:
        src_path = ROOT / src
        if src_path.exists():
            add_data_args.extend(["--add-data", f"{src_path}{os.pathsep}{dst}"])

    hidden_imports = [
        "PyQt5", "PyQt5.QtWidgets", "PyQt5.QtCore", "PyQt5.QtGui",
        "PyQt5.QtWebEngineWidgets", "PyQt5.QtWebEngine",
        "PyQt5.sip",
        "networkx", "rdflib", "pyvis", "yaml", "requests",
        "docx", "openpyxl", "pptx", "PyPDF2", "pdfplumber",
        "markdown", "bs4", "lxml", "watchdog", "jinja2", "chardet",
        "json", "csv", "xml", "html",
    ]

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--windowed",
        "--name", EXE_NAME,
        "--collect-all", "PyQt5",
        "--collect-data", "pyvis",
        "--collect-data", "rdflib",
    ]

    if ICON_PATH.exists():
        cmd.extend(["--icon", str(ICON_PATH)])

    for hi in hidden_imports:
        cmd.extend(["--hidden-import", hi])

    cmd.extend(add_data_args)
    cmd.append(str(ROOT / "main.py"))

    print("\n[RUN]", " ".join(cmd[:6]), "...")
    result = subprocess.run(cmd, cwd=str(ROOT))

    if result.returncode != 0:
        print("[FAIL] PyInstaller 打包失败!")
        sys.exit(1)

    app_dist = DIST / EXE_NAME
    if not app_dist.exists():
        print(f"[FAIL] 输出目录不存在: {app_dist}")
        sys.exit(1)

    for folder_name in ["ontology", "output", "output/graphs", "output/reports"]:
        (app_dist / folder_name).mkdir(parents=True, exist_ok=True)

    for extra in ["core", "gui"]:
        src_dir = ROOT / extra
        dst_dir = app_dist / extra
        if src_dir.exists() and not dst_dir.exists():
            shutil.copytree(src_dir, dst_dir,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    for bat in ["启动.bat", "install.bat"]:
        src_bat = ROOT / bat
        if src_bat.exists():
            shutil.copy2(src_bat, app_dist / bat)

    if (ROOT / "知识产权").exists():
        shutil.copytree(ROOT / "知识产权", app_dist / "知识产权",
                        ignore=shutil.ignore_patterns("__pycache__"))

    print(f"\n[OK] 打包完成!")
    print(f"     输出: {app_dist}")
    print(f"     启动: {app_dist / (EXE_NAME + '.exe')}")
    return app_dist


def generate_inno_script(app_dist: Path):
    iss_path = ROOT / "setup_script.iss"
    iss_content = f"""; Inno Setup Script - {APP_NAME}
; 自动生成, 请勿手动编辑

#define MyAppName "{APP_NAME}"
#define MyAppNameEn "AeroKnowledgeAgent"
#define MyAppVersion "{VERSION}"
#define MyAppPublisher "航空知识库研发团队"
#define MyAppExeName "{EXE_NAME}.exe"

[Setup]
AppId={{{{8F3C1A5E-2B7D-4E9F-A1C3-5D8E2F6A7B9C}}}}
AppName={{#MyAppName}}
AppVersion={{#MyAppVersion}}
AppPublisher={{#MyAppPublisher}}
DefaultDirName={{autopf}}\\{{#MyAppNameEn}}
DefaultGroupName={{#MyAppName}}
OutputDir={str(ROOT / "installer_output")}
OutputBaseFilename={EXE_NAME}_Setup_v{VERSION}
SetupIconFile={str(ICON_PATH) if ICON_PATH.exists() else ""}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
DisableProgramGroupPage=yes
LicenseFile=
UninstallDisplayIcon={{app}}\\{{#MyAppExeName}}
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "chinesesimplified"; MessagesFile: "compiler:Languages\\ChineseSimplified.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式"; GroupDescription: "附加选项:"; Flags: checked
Name: "quicklaunchicon"; Description: "创建快速启动栏图标"; GroupDescription: "附加选项:"; Flags: unchecked

[Files]
Source: "{app_dist}\\*"; DestDir: "{{app}}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{{group}}\\{{#MyAppName}}"; Filename: "{{app}}\\{{#MyAppExeName}}"
Name: "{{group}}\\卸载 {{#MyAppName}}"; Filename: "{{uninstallexe}}"
Name: "{{autodesktop}}\\{{#MyAppName}}"; Filename: "{{app}}\\{{#MyAppExeName}}"; Tasks: desktopicon

[Run]
Filename: "{{app}}\\{{#MyAppExeName}}"; Description: "立即启动 {{#MyAppName}}"; Flags: nowait postinstall skipifsilent

[Code]
function InitializeSetup(): Boolean;
begin
  Result := True;
end;
"""

    if not ICON_PATH.exists():
        iss_content = iss_content.replace(
            f"SetupIconFile={str(ICON_PATH)}", "")

    iss_path.write_text(iss_content, encoding="utf-8")
    print(f"\n[OK] Inno Setup 脚本: {iss_path}")
    return iss_path


def run_inno_setup(iss_path: Path):
    inno_paths = [
        r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe",
        r"C:\Program Files\Inno Setup 6\ISCC.exe",
    ]
    iscc = None
    for p in inno_paths:
        if os.path.exists(p):
            iscc = p
            break

    if not iscc:
        iscc = shutil.which("ISCC")

    if not iscc:
        print("\n[WARN] 未找到 Inno Setup 6, 跳过安装程序生成")
        print("       请安装 Inno Setup 6: https://jrsoftware.org/isdl.php")
        print(f"       手动编译: ISCC.exe \"{iss_path}\"")
        return

    (ROOT / "installer_output").mkdir(exist_ok=True)

    print("\n[RUN] 生成安装程序 ...")
    result = subprocess.run([iscc, str(iss_path)], cwd=str(ROOT))

    if result.returncode == 0:
        print(f"\n[OK] 安装程序已生成!")
        print(f"     位置: {ROOT / 'installer_output'}")
    else:
        print("[FAIL] Inno Setup 编译失败")


def create_portable_bat(app_dist: Path):
    bat = app_dist / f"启动{APP_NAME}.bat"
    bat.write_text(f"""@echo off
chcp 65001 >nul 2>&1
title {APP_NAME}
cd /d "%~dp0"
start "" "{EXE_NAME}.exe"
""", encoding="utf-8")
    print(f"[OK] 便携启动脚本: {bat}")


if __name__ == "__main__":
    ensure_pyinstaller()
    create_icon_if_missing()
    app_dist = run_pyinstaller()
    create_portable_bat(app_dist)

    if "--inno" in sys.argv:
        iss = generate_inno_script(app_dist)
        run_inno_setup(iss)
    else:
        iss = generate_inno_script(app_dist)
        print("\n" + "=" * 60)
        print("  打包选项:")
        print(f"  1. 便携版 (已就绪): {app_dist}")
        print(f"  2. 安装程序: 安装 Inno Setup 6 后运行:")
        print(f"     python build_app.py --inno")
        print("=" * 60)
