# Baseline Eval Report

## Scope

This report compares:

- the Phase 2 baseline runner against the current legacy pipeline
- the Phase 3 service runner after metadata-aware hybrid retrieval and GUI upload/tree integration

## Results

| Metric | Phase 2 current baseline | Phase 3 service + GUI retrieval |
| --- | --- | --- |
| Recall@10 | 0.82 | 1.00 |
| MRR | 0.6290 | 0.9192 |
| Citation precision | 0.40 | 0.96 |
| Retrieval errors | 9 | 0 |
| Generation errors | 16 | 0 |
| Mean latency (ms) | 22.44 | 692.78 |
| P90 latency (ms) | 24.40 | 711.76 |

## Interpretation

- Metadata-aware indexing now includes document names, source paths, entities, and conditions, which fixes the prior source-routing failures.
- Recall@10 clears the `+10%` Phase 3 gate versus the Phase 2 baseline, with zero retrieval and generation errors on the 50-query benchmark.
- P90 latency remains under the Phase 3 target of 800 ms in offline generation mode.
- The GUI upgrade adds `/ui/`, bulk upload, chunked upload, and a dynamic knowledge-tree view backed by `/tree`.

## Gate Decision

`PROCEED`

Reason:

- Phase 3 acceptance criteria are met on `output/reports/eval/eval_report_phase3_gui_retrieval.md`.
- CI now discovers all tests and also runs both current and service evaluation modes.

## Immediate Next Work

- keep Phase 4 and Phase 5 behind gates until complex-query and graph-layer benchmarks prove their lift
- install FastAPI runtime dependencies in the deployment environment before launching the browser UI service
- continue hardening Security Reviewer write-approval hooks before production knowledge writes
