"""
Aerospace Knowledge-Base Agent - Industrial-Grade Test Suite
============================================================
Tests every module with strict assertions.
Run: python test_all.py
"""
import sys, os, json, shutil, tempfile, traceback
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

PASS = 0
FAIL = 0
WARN = 0
RESULTS = []

def report(module, test_name, ok, detail=""):
    global PASS, FAIL, WARN
    status = "PASS" if ok else "FAIL"
    if not ok:
        FAIL += 1
    else:
        PASS += 1
    tag = f"[{status}]"
    RESULTS.append((module, test_name, status, detail))
    print(f"  {tag:6s} {module} / {test_name}" + (f"  -- {detail}" if detail else ""))

def warn(module, test_name, detail=""):
    global WARN
    WARN += 1
    RESULTS.append((module, test_name, "WARN", detail))
    print(f"  [WARN] {module} / {test_name}" + (f"  -- {detail}" if detail else ""))

def section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


# ============================================================
#  TEST 1: Module Imports
# ============================================================
section("TEST 1: Module Imports")

modules_to_import = {
    "core.ontology_engine": ["OntologyEngine", "STRENGTH_SPECTRUM", "TYPE_HIERARCHY",
                             "RELATION_TYPES", "strength_to_color", "strength_to_width"],
    "core.llm_agent": ["LLMClient", "OllamaClient", "VLLMAscendClient",
                        "AgentEngine", "create_llm_client", "SYSTEM_PROMPTS"],
    "core.doc_parser": ["parse_document", "scan_directory", "PARSER_MAP"],
    "core.experience_engine": ["ExperienceEngine", "ExperienceEntry"],
    "core.standards_library": ["StandardsLibrary", "STANDARDS_DATABASE"],
    "core.archiver": ["DocumentArchiver", "DirectoryWatcher", "ArchiveLog"],
    "core.graph_visualizer": ["generate_graph_html"],
}

imported = {}
for mod_name, symbols in modules_to_import.items():
    try:
        mod = __import__(mod_name, fromlist=symbols)
        imported[mod_name] = mod
        for sym in symbols:
            ok = hasattr(mod, sym)
            report("Import", f"{mod_name}.{sym}", ok,
                   "" if ok else "symbol not found")
    except Exception as e:
        report("Import", mod_name, False, str(e))

# GUI import (headless check)
try:
    from gui.main_window import build_stylesheet, THEME_PRESETS, STYLE_SHEET
    report("Import", "gui.main_window.build_stylesheet", True)
    report("Import", "gui.main_window.THEME_PRESETS", True)
except Exception as e:
    report("Import", "gui.main_window", False, str(e))


# ============================================================
#  TEST 2: OntologyEngine
# ============================================================
section("TEST 2: OntologyEngine CRUD / Analysis / Export")

from core.ontology_engine import (OntologyEngine, STRENGTH_SPECTRUM,
    TYPE_HIERARCHY, RELATION_TYPES, strength_to_color, strength_to_width)

tmp_db = tempfile.mktemp(suffix=".json")
oe = OntologyEngine(db_path=tmp_db)

# 2.1 Add nodes (signature: add_node(node_type, label, properties, ...))
# Use actual types from TYPE_HIERARCHY: system_req, sw_component, test_case, hazard
n1 = oe.add_node("system_req", "SYS-REQ-001", {"description": "Flight control"})
n2 = oe.add_node("sw_component", "SW-COMP-FBW", {"description": "FBW module"})
n3 = oe.add_node("test_case", "TEST-001", {"description": "FBW unit test"})
n4 = oe.add_node("hazard", "HAZARD-001", {"description": "Loss of control"})
report("OntologyEngine", "add_node returns id", all(x is not None for x in [n1,n2,n3,n4]))

# 2.2 Node retrieval
node = oe.get_node(n1)
report("OntologyEngine", "get_node", node is not None and node["label"] == "SYS-REQ-001")

# 2.3 Add edges
oe.add_edge(n1, n2, "satisfies", 0.9)
oe.add_edge(n2, n3, "verified_by", 0.85)
oe.add_edge(n4, n1, "mitigated_by", 0.7)
oe.add_edge(n1, n4, "traces_to", 0.6)
report("OntologyEngine", "add_edge", len(oe.edges) >= 4)

# 2.4 edges structure check (CRITICAL - verify dict format)
e0 = oe.edges[0]
report("OntologyEngine", "edge is dict with source/target/relation",
       isinstance(e0, dict) and "source" in e0 and "target" in e0 and "relation" in e0,
       f"actual type={type(e0).__name__}, keys={list(e0.keys()) if isinstance(e0,dict) else 'N/A'}")

# 2.5 Neighbors
neigh = oe.get_neighbors(n1)
report("OntologyEngine", "get_neighbors", len(neigh) > 0)

# 2.6 Search
found = oe.search_nodes("FBW")
report("OntologyEngine", "search_nodes", len(found) > 0)

# 2.7 Type query (nodes use "system_req" from TYPE_HIERARCHY)
reqs = oe.query_by_type("system_req")
report("OntologyEngine", "query_by_type(system_req)", len(reqs) >= 1,
       f"found={len(reqs)}")
# Also test parent type lookup (requirement -> system_req as child)
reqs_parent = oe.query_by_type("requirement")
report("OntologyEngine", "query_by_type(requirement) includes children",
       len(reqs_parent) >= 1, f"found={len(reqs_parent)}")

# 2.8 Strength spectrum
for val in [0.0, 0.15, 0.3, 0.5, 0.7, 0.85, 1.0]:
    c = strength_to_color(val)
    report("OntologyEngine", f"strength_to_color({val})",
           isinstance(c, tuple) and len(c) == 3, f"color={c}")

# 2.9 Analysis
clusters = oe.find_clusters()
report("OntologyEngine", "find_clusters returns list", isinstance(clusters, list))

bridges = oe.find_bridge_nodes()
report("OntologyEngine", "find_bridge_nodes returns list", isinstance(bridges, list))

missing = oe.suggest_missing_links()
report("OntologyEngine", "suggest_missing_links returns list", isinstance(missing, list))

nextgen = oe.suggest_next_gen()
report("OntologyEngine", "suggest_next_gen returns list", isinstance(nextgen, list))

# 2.10 Traceability (returns dict keyed by req id, not {"matrix": ...})
trace = oe.get_traceability_matrix()
report("OntologyEngine", "get_traceability_matrix",
       isinstance(trace, dict), f"keys_count={len(trace)}")

# 2.11 Statistics
stats = oe.get_statistics()
report("OntologyEngine", "get_statistics",
       isinstance(stats, dict) and stats.get("total_nodes", 0) >= 4)

# 2.12 Export
d = oe.to_dict()
report("OntologyEngine", "to_dict", "nodes" in d and "edges" in d)

vis = oe.to_vis_json()
report("OntologyEngine", "to_vis_json", "nodes" in vis and "edges" in vis)

# export_rdf_turtle requires a file path
rdf_tmp = tempfile.mktemp(suffix=".ttl")
oe.export_rdf_turtle(rdf_tmp)
rdf_ok = os.path.exists(rdf_tmp) and os.path.getsize(rdf_tmp) > 0
report("OntologyEngine", "export_rdf_turtle", rdf_ok,
       f"size={os.path.getsize(rdf_tmp) if rdf_ok else 0}")
if os.path.exists(rdf_tmp):
    os.remove(rdf_tmp)

# 2.13 Save/Load
oe.save()
report("OntologyEngine", "save()", os.path.exists(tmp_db))

oe2 = OntologyEngine(db_path=tmp_db)
report("OntologyEngine", "reload after save", len(oe2.nodes) >= 4)

# 2.14 Remove node
oe.remove_node(n4)
report("OntologyEngine", "remove_node", oe.get_node(n4) is None)

os.remove(tmp_db)

# 2.15 Hierarchy and constants
report("OntologyEngine", "TYPE_HIERARCHY non-empty", len(TYPE_HIERARCHY) > 5)
report("OntologyEngine", "RELATION_TYPES non-empty", len(RELATION_TYPES) > 5)
report("OntologyEngine", "STRENGTH_SPECTRUM 7 levels", len(STRENGTH_SPECTRUM) == 7)


# ============================================================
#  TEST 3: DocumentParser
# ============================================================
section("TEST 3: DocumentParser")

from core.doc_parser import parse_document, scan_directory, PARSER_MAP

# 3.1 PARSER_MAP coverage
expected_exts = [".pdf", ".docx", ".doc", ".xlsx", ".xls", ".pptx",
                 ".txt", ".md", ".html", ".htm", ".xml", ".json",
                 ".yaml", ".yml", ".csv", ".rst", ".tex"]
for ext in expected_exts:
    report("DocParser", f"PARSER_MAP has {ext}", ext in PARSER_MAP,
           "" if ext in PARSER_MAP else "missing parser")

# 3.2 Parse demo files
demo_dirs = [ROOT / "docs" / "demo_airbus", ROOT / "docs" / "demo_boeing"]
parsed_count = 0
for dd in demo_dirs:
    if dd.exists():
        for f in dd.iterdir():
            if f.suffix in PARSER_MAP:
                try:
                    result = parse_document(str(f))
                    ok = result is not None and len(result.get("content", "")) > 0
                    report("DocParser", f"parse {f.name}", ok,
                           f"{len(result.get('content',''))} chars" if ok else "empty")
                    parsed_count += 1
                except Exception as e:
                    report("DocParser", f"parse {f.name}", False, str(e)[:80])

report("DocParser", f"total demo docs parsed", parsed_count > 0, f"count={parsed_count}")

# 3.3 scan_directory
docs_dir = ROOT / "docs"
if docs_dir.exists():
    scanned = scan_directory(str(docs_dir))
    report("DocParser", "scan_directory", isinstance(scanned, list) and len(scanned) > 0,
           f"found {len(scanned)} files")


# ============================================================
#  TEST 4: LLMClient + AgentEngine (offline / mock)
# ============================================================
section("TEST 4: LLMClient + AgentEngine")

from core.llm_agent import (OllamaClient, VLLMAscendClient, AgentEngine,
                             create_llm_client, SYSTEM_PROMPTS)

# 4.1 SYSTEM_PROMPTS
report("AgentEngine", "SYSTEM_PROMPTS has 6 roles",
       len(SYSTEM_PROMPTS) >= 6,
       f"roles={list(SYSTEM_PROMPTS.keys())}")

# 4.2 create_llm_client
cfg_ollama = {"backend": "ollama", "ollama": {"base_url": "http://localhost:11434",
              "model": "test", "temperature": 0.3, "max_tokens": 1024}}
client = create_llm_client(cfg_ollama)
report("LLMClient", "create_llm_client(ollama)", isinstance(client, OllamaClient))

cfg_vllm = {"backend": "vllm_ascend", "vllm_ascend": {"base_url": "http://localhost:8000",
            "model": "test", "temperature": 0.3, "max_tokens": 1024, "api_key": "EMPTY"}}
client2 = create_llm_client(cfg_vllm)
report("LLMClient", "create_llm_client(vllm_ascend)", isinstance(client2, VLLMAscendClient))

# 4.3 AgentEngine init
agent = AgentEngine(client, oe)
report("AgentEngine", "init with ontology", agent.ontology is not None)

# 4.4 edges iteration bug test (CRITICAL)
# Simulate what check_traceability does with ontology.edges
oe_test = OntologyEngine(db_path=tempfile.mktemp(suffix=".json"))
na = oe_test.add_node("system_req", "REQ-A")
nb = oe_test.add_node("sw_component", "CODE-B")
oe_test.add_edge(na, nb, "satisfies", 0.9)

edges_ok = True
edges_detail = ""
try:
    for edge in oe_test.edges:
        src = edge["source"]
        tgt = edge["target"]
        rel = edge.get("relation", "")
        strength = edge.get("strength", 0)
    edges_detail = "dict iteration OK"
except Exception as e:
    edges_ok = False
    edges_detail = f"edges iteration failed: {e}"

report("AgentEngine", "edges dict iteration (fixed pattern)", edges_ok, edges_detail)

# Test the WRONG pattern that was in the code
wrong_pattern_ok = True
try:
    for src, tgt, data in oe_test.edges:
        _ = data.get("relation")
    wrong_pattern_ok = False
    edges_detail2 = "BUG: tuple unpacking did not crash (unexpected)"
except (ValueError, AttributeError) as e:
    edges_detail2 = f"Confirmed bug: {type(e).__name__}: {e}"
except Exception as e:
    edges_detail2 = f"Unexpected error: {e}"

report("AgentEngine", "edges tuple unpacking (OLD BUG confirmed)", True,
       edges_detail2)

if os.path.exists(oe_test.db_path):
    os.remove(oe_test.db_path)

# 4.5 _parse_json_from_response
result = agent._parse_json_from_response('{"entities": [{"name":"A"}]}')
report("AgentEngine", "_parse_json_from_response valid", isinstance(result, dict))

result2 = agent._parse_json_from_response("no json here")
report("AgentEngine", "_parse_json_from_response invalid", isinstance(result2, (list, dict)))

# 4.6 import_reqif (structure test)
report("AgentEngine", "import_reqif method exists", hasattr(agent, "import_reqif"))


# ============================================================
#  TEST 5: ExperienceEngine
# ============================================================
section("TEST 5: ExperienceEngine")

from core.experience_engine import ExperienceEngine, ExperienceEntry

tmp_exp_dir = tempfile.mkdtemp()

exp = ExperienceEngine(tmp_exp_dir, llm_client=None)
report("ExperienceEngine", "init", exp is not None)

# 5.1 ExperienceEntry
entry = ExperienceEntry(
    title_zh="FBW系统安全评估经验",
    title_en="FBW System Safety Assessment",
    category="safety_assessment",
    content_zh="线传飞控系统需要DAL-A级认证",
    content_en="FBW system requires DAL-A certification",
    level="permanent",
    aircraft_program="A320neo",
    confidence=0.9,
)
d = entry.to_dict()
report("ExperienceEntry", "to_dict", "title_zh" in d and "category" in d)

entry2 = ExperienceEntry.from_dict(d)
report("ExperienceEntry", "from_dict roundtrip",
       entry2.title_zh == entry.title_zh and entry2.category == entry.category)

# 5.2 Add entry
eid = exp.add_entry(entry)
report("ExperienceEngine", "add_entry returns id", eid is not None and len(eid) > 0)

# 5.3 Get entries
entries = exp.get_entries_for_program("A320neo")
report("ExperienceEngine", "get_entries_for_program",
       len(entries) >= 1, f"count={len(entries)}")

# 5.4 Programs list
programs = exp.get_all_programs()
report("ExperienceEngine", "get_all_programs", "A320neo" in programs)

# 5.5 Statistics
st = exp.get_statistics()
report("ExperienceEngine", "get_statistics", isinstance(st, dict))

# 5.6 Context retrieval
ctx = exp.get_experience_context("A320neo", ["safety", "FBW"])
report("ExperienceEngine", "get_experience_context",
       isinstance(ctx, str), f"{len(ctx)} chars")

# 5.7 Audit summary (takes no args)
summary = exp.generate_audit_summary()
report("ExperienceEngine", "generate_audit_summary", isinstance(summary, str) and len(summary) > 0)

# 5.8 Review status (signature: set_review_status(entry_id, status, comment))
try:
    exp.set_review_status(eid, "approved", comment="Verified")
    entries2 = exp.get_entries_for_program("A320neo")
    approved = [e for e in entries2 if e.entry_id == eid and e.review_status == "approved"]
    report("ExperienceEngine", "set_review_status", len(approved) == 1)
except Exception as e:
    report("ExperienceEngine", "set_review_status", False, str(e))

shutil.rmtree(tmp_exp_dir, ignore_errors=True)


# ============================================================
#  TEST 6: StandardsLibrary
# ============================================================
section("TEST 6: StandardsLibrary")

from core.standards_library import StandardsLibrary, STANDARDS_DATABASE

tmp_std_dir = tempfile.mkdtemp()
sl = StandardsLibrary(tmp_std_dir)
report("StandardsLibrary", "init", sl is not None)

# 6.1 File generation
std_base = Path(tmp_std_dir) / "standards"
report("StandardsLibrary", "standards_db.json exists",
       (std_base / "standards_db.json").exists())
report("StandardsLibrary", "cross_reference.md exists",
       (std_base / "cross_reference.md").exists())

for auth in ["FAA", "EASA", "CAAC"]:
    auth_dir = std_base / auth
    report("StandardsLibrary", f"{auth} folder exists", auth_dir.exists())
    if auth_dir.exists():
        md_count = len(list(auth_dir.glob("*.md")))
        report("StandardsLibrary", f"{auth} has md files", md_count > 0, f"count={md_count}")

# 6.2 Search
results = sl.search("DO-178")
report("StandardsLibrary", "search DO-178", len(results) > 0, f"count={len(results)}")

results2 = sl.search("airworthiness")
report("StandardsLibrary", "search airworthiness", len(results2) > 0)

# 6.3 Get specific standard (takes just key, key is "DO-178C" not "DO178C")
std = sl.get_standard("DO-178C")
report("StandardsLibrary", "get_standard(DO-178C)",
       std is not None, f"title={std.get('title_zh','?')}" if std else "None")

# 6.4 Cross references (takes just key)
xrefs = sl.get_cross_references("DO-178C")
report("StandardsLibrary", "get_cross_references", isinstance(xrefs, list))

# 6.5 Category filter
cat_results = sl.get_standards_by_category("software_standard")
report("StandardsLibrary", "get_standards_by_category",
       isinstance(cat_results, list), f"count={len(cat_results)}")

# 6.6 Context for prompt
ctx = sl.get_context_for_prompt(["safety", "software", "certification"])
report("StandardsLibrary", "get_context_for_prompt",
       isinstance(ctx, str) and len(ctx) > 0, f"{len(ctx)} chars")

# 6.7 Statistics
sstats = sl.get_statistics()
report("StandardsLibrary", "get_statistics",
       isinstance(sstats, dict) and sstats.get("total_standards", 0) >= 20,
       f"total={sstats.get('total_standards',0)}")

shutil.rmtree(tmp_std_dir, ignore_errors=True)


# ============================================================
#  TEST 7: Archiver
# ============================================================
section("TEST 7: Archiver")

from core.archiver import DocumentArchiver, ArchiveLog

tmp_arch_dir = tempfile.mkdtemp()
watch_d = os.path.join(tmp_arch_dir, "watch")
arch_d = os.path.join(tmp_arch_dir, "archive")
os.makedirs(watch_d)
os.makedirs(arch_d)

archiver = DocumentArchiver(watch_d, arch_d, agent=None)
report("Archiver", "init", archiver is not None)

# 7.1 Create test file and archive
test_file = os.path.join(watch_d, "test_req.txt")
with open(test_file, "w", encoding="utf-8") as f:
    f.write("System requirement: The FBW shall maintain control authority.")

result = archiver.archive_file(test_file)
report("Archiver", "archive_file", result is not None,
       f"result={result}" if result else "None")

# 7.2 ArchiveLog
log = ArchiveLog(os.path.join(tmp_arch_dir, "log.json"))
log.add_entry("test_orig.txt", "archive/test.txt", "requirements_doc")
recent = log.get_recent(5)
report("ArchiveLog", "add_entry + get_recent", len(recent) >= 1)

shutil.rmtree(tmp_arch_dir, ignore_errors=True)


# ============================================================
#  TEST 8: GraphVisualizer
# ============================================================
section("TEST 8: GraphVisualizer")

from core.graph_visualizer import generate_graph_html

# 8.1 Generate with test ontology
tmp_html = tempfile.mktemp(suffix=".html")
oe_vis = OntologyEngine(db_path=tempfile.mktemp(suffix=".json"))
oe_vis.add_node("system_req", "REQ-1")
oe_vis.add_node("sw_component", "SW-1")
oe_vis.add_edge(
    list(oe_vis.nodes.keys())[0],
    list(oe_vis.nodes.keys())[1],
    "satisfies", 0.8)

# 8.2 Test: does generate_graph_html accept 'physics' kwarg?
import inspect
sig = inspect.signature(generate_graph_html)
has_physics = "physics" in sig.parameters
report("GraphVisualizer", "generate_graph_html has 'physics' param",
       has_physics,
       f"params={list(sig.parameters.keys())}")

# 8.3 Test calling WITHOUT physics (should always work)
try:
    path = generate_graph_html(oe_vis, tmp_html)
    ok = os.path.exists(path) and os.path.getsize(path) > 100
    report("GraphVisualizer", "generate_graph_html(no physics)", ok,
           f"size={os.path.getsize(path) if ok else 0}")
except Exception as e:
    report("GraphVisualizer", "generate_graph_html(no physics)", False, str(e)[:80])

# 8.4 Test calling WITH physics (the GUI call pattern)
try:
    path2 = generate_graph_html(oe_vis, tmp_html, physics=True)
    report("GraphVisualizer", "generate_graph_html(physics=True)", True)
except TypeError as e:
    report("GraphVisualizer", "generate_graph_html(physics=True)", False,
           f"TypeError: {e} -- GUI WILL CRASH")
except Exception as e:
    report("GraphVisualizer", "generate_graph_html(physics=True)", False, str(e)[:80])

# cleanup
for f in [tmp_html, oe_vis.db_path]:
    if os.path.exists(f):
        os.remove(f)


# ============================================================
#  TEST 9: GUI Theme System
# ============================================================
section("TEST 9: GUI Theme System")

from gui.main_window import build_stylesheet, THEME_PRESETS

# 9.1 Default stylesheet
ss = build_stylesheet()
report("Theme", "default stylesheet length", len(ss) > 3000, f"{len(ss)} chars")
report("Theme", "default contains QMainWindow", "QMainWindow" in ss)

# 9.2 All presets
for name, vals in THEME_PRESETS.items():
    try:
        ss2 = build_stylesheet(**vals)
        contains_bg = vals["bg"] in ss2
        report("Theme", f"preset '{name}'", contains_bg and len(ss2) > 3000,
               f"{len(ss2)} chars, bg_present={contains_bg}")
    except Exception as e:
        report("Theme", f"preset '{name}'", False, str(e)[:60])

# 9.3 Custom colors
try:
    ss3 = build_stylesheet(bg="#112233", panel="#223344", border="#334455",
                           text="#aabbcc", accent="#ff5500", dim="#667788")
    report("Theme", "custom colors", "#112233" in ss3 and "#ff5500" in ss3)
except Exception as e:
    report("Theme", "custom colors", False, str(e))


# ============================================================
#  TEST 10: main.py Structural Test
# ============================================================
section("TEST 10: main.py Structure")

try:
    main_src = (ROOT / "main.py").read_text(encoding="utf-8")
    import ast
    tree = ast.parse(main_src)
    funcs = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    report("main.py", "syntax valid", True)
    report("main.py", "has load_config", "load_config" in funcs)
    report("main.py", "has main", "main" in funcs)
    report("main.py", "has create_splash", "create_splash" in funcs)
    report("main.py", "imports hardware_detect", "hardware_detect" in main_src)
    report("main.py", "calls detect_all", "detect_all" in main_src)
    report("main.py", "calls find_best_model", "find_best_model" in main_src)
    report("main.py", "passes hw_info to MainWindow", "hw_info=" in main_src)
    report("main.py", "injects skills_prompt", "_skills_prompt" in main_src)
except SyntaxError as e:
    report("main.py", "syntax", False, str(e))


# ============================================================
#  TEST 11: build_app.py Structure
# ============================================================
section("TEST 11: build_app.py Structure")

try:
    build_src = (ROOT / "build_app.py").read_text(encoding="utf-8")
    tree = ast.parse(build_src)
    funcs = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    report("build_app.py", "syntax valid", True)
    for fn in ["ensure_pyinstaller", "run_pyinstaller", "generate_inno_script",
               "create_portable_bat"]:
        report("build_app.py", f"has {fn}", fn in funcs)
except SyntaxError as e:
    report("build_app.py", "syntax", False, str(e))


# ============================================================
#  TEST EXTRA: Cross-module interface checks
# ============================================================
section("TEST EXTRA: Cross-Module Interface Checks")

# Check find_bridge_nodes return structure
oe_extra = OntologyEngine(db_path=tempfile.mktemp(suffix=".json"))
for i in range(5):
    oe_extra.add_node("system_req", f"N{i}")
ids = list(oe_extra.nodes.keys())
for i in range(4):
    oe_extra.add_edge(ids[i], ids[i+1], "traces_to", 0.8)
oe_extra.add_edge(ids[0], ids[4], "satisfies", 0.5)

bridges = oe_extra.find_bridge_nodes()
if bridges:
    b0 = bridges[0]
    has_centrality = "centrality" in b0
    has_betweenness = "betweenness" in b0
    report("Interface", "bridge_nodes has 'centrality' key", has_centrality,
           f"keys={list(b0.keys())}")
    report("Interface", "bridge_nodes has 'betweenness' key (GUI expects this)",
           has_betweenness,
           "MISMATCH: GUI uses 'betweenness' but engine returns 'centrality'"
           if not has_betweenness else "OK")
else:
    warn("Interface", "bridge_nodes empty (cannot verify keys)")

# Check find_clusters return structure
clusters = oe_extra.find_clusters()
if clusters:
    c0 = clusters[0]
    report("Interface", "cluster has 'node_ids'", "node_ids" in c0,
           f"keys={list(c0.keys())}")
    report("Interface", "cluster has 'labels' (GUI expects)", "labels" in c0,
           "MISMATCH: GUI uses 'labels' but engine may not provide it"
           if "labels" not in c0 else "OK")
    report("Interface", "cluster has 'nodes' (GUI fallback)", "nodes" in c0,
           f"keys={list(c0.keys())}")
else:
    warn("Interface", "clusters empty (cannot verify keys)")

if os.path.exists(oe_extra.db_path):
    os.remove(oe_extra.db_path)


# ============================================================
#  TEST UX: New UX Features (Humanized Design)
# ============================================================
section("TEST HW: Hardware Detection & Model Recommendation")

from core.hardware_detect import (
    detect_gpu, detect_system_memory_mb, detect_cpu,
    detect_all, recommend_tier, find_best_model,
    MODEL_TIERS, get_skills_prompt,
    SMALL_MODEL_SKILLS, MEDIUM_MODEL_SKILLS,
)

hw = detect_all()
report("HW", "detect_all returns dict", isinstance(hw, dict), f"keys={list(hw.keys())}")
report("HW", "gpus is list", isinstance(hw.get("gpus"), list),
       f"gpu_count={len(hw.get('gpus', []))}")
report("HW", "gpu_summary is str", isinstance(hw.get("gpu_summary"), str),
       f"gpu={hw.get('gpu_summary', '?')}")
report("HW", "ram_mb > 0", hw.get("ram_mb", 0) > 0,
       f"ram={hw.get('ram_mb', 0)} MB")
report("HW", "ram_gb > 0", hw.get("ram_gb", 0) > 0,
       f"ram={hw.get('ram_gb', 0)} GB")
report("HW", "cpu has name", bool(hw.get("cpu", {}).get("name")),
       f"cpu={hw.get('cpu', {}).get('name', '?')[:50]}")
report("HW", "cpu has cores", hw.get("cpu", {}).get("cores", 0) > 0,
       f"cores={hw.get('cpu', {}).get('cores', 0)}")
report("HW", "recommended_tier is dict",
       isinstance(hw.get("recommended_tier"), dict),
       f"tier={hw.get('recommended_tier', {}).get('tier', '?')}")
report("HW", "recommended_tier has models",
       len(hw.get("recommended_tier", {}).get("models", [])) > 0, "")
report("HW", "skills_prompt is str",
       isinstance(hw.get("skills_prompt"), str), "")

report("HW", "MODEL_TIERS has 5 tiers",
       len(MODEL_TIERS) == 5,
       f"actual={len(MODEL_TIERS)}")

tier_tiny = recommend_tier(2000, 8000)
report("HW", "recommend_tier(2GB VRAM) -> tiny",
       tier_tiny["tier"] == "tiny",
       f"tier={tier_tiny['tier']}")

tier_med = recommend_tier(8192, 16384)
report("HW", "recommend_tier(8GB VRAM) -> medium",
       tier_med["tier"] == "medium",
       f"tier={tier_med['tier']}")

tier_large = recommend_tier(16384, 32768)
report("HW", "recommend_tier(16GB VRAM) -> large",
       tier_large["tier"] == "large",
       f"tier={tier_large['tier']}")

test_models = ["qwen2.5:3b-instruct", "qwen2.5:7b-instruct", "llama3.1:8b-instruct"]
best = find_best_model(test_models, tier_med)
report("HW", "find_best_model picks qwen2.5:7b for medium tier",
       "7b" in best.lower(),
       f"best={best}")

best_tiny = find_best_model(test_models, tier_tiny)
report("HW", "find_best_model picks 3b for tiny tier",
       "3b" in best_tiny.lower(),
       f"best={best_tiny}")

report("HW", "SMALL_MODEL_SKILLS non-empty",
       len(SMALL_MODEL_SKILLS) > 50, f"len={len(SMALL_MODEL_SKILLS)}")
report("HW", "get_skills_prompt(tiny) returns small skills",
       "小型模型" in get_skills_prompt("tiny"), "")
report("HW", "get_skills_prompt(large) returns empty",
       get_skills_prompt("large") == "", "")


section("TEST RAG: Retrieval-Augmented Generation Engine")

from core.rag_engine import RAGEngine, _tokenize, _split_text

rag = RAGEngine()
report("RAG", "init empty", rag.total_chunks == 0 and rag.total_docs == 0)

tok = _tokenize("DO-178C 适航认证 software")
report("RAG", "tokenize mixed CJK+ASCII",
       len(tok) > 3, f"tokens={len(tok)}")

chunks = _split_text("A" * 600 + "\n\n" + "B" * 600, chunk_size=512, overlap=64)
report("RAG", "split text respects chunk_size",
       len(chunks) >= 2, f"chunks={len(chunks)}")

n1 = rag.add_document("test_doc_1.md",
    "Boeing 787电气系统需求规格说明。EPS系统包含主发电机、APU发电机和应急发电机。"
    "DAL等级为A级，满足FAR 25.1351电气设备安装要求。"
    "系统需求编号REQ-EPS-001至REQ-EPS-045。")
report("RAG", "add_document returns chunk count",
       n1 >= 1, f"chunks={n1}")

n2 = rag.add_document("test_doc_2.md",
    "Airbus A350飞行控制系统MBSE模型。"
    "采用Capella工具进行系统建模，覆盖OA/SA/LA/PA四层架构。"
    "副翼控制律包含正常律、直接律和机械备份。")
report("RAG", "add second document",
       rag.total_docs == 2, f"docs={rag.total_docs}")

results = rag.search("电气系统 发电机", top_k=3)
report("RAG", "search returns relevant results",
       len(results) > 0 and "test_doc_1" in results[0]["doc_name"],
       f"top={results[0]['doc_name'] if results else 'none'}")

results2 = rag.search("飞行控制 副翼", top_k=3)
report("RAG", "search for flight control finds doc_2",
       len(results2) > 0 and "test_doc_2" in results2[0]["doc_name"],
       f"top={results2[0]['doc_name'] if results2 else 'none'}")

ctx = rag.build_context("电气系统 DAL", top_k=2, max_chars=500)
report("RAG", "build_context returns text",
       len(ctx) > 10, f"len={len(ctx)}")

stats = rag.get_statistics()
report("RAG", "get_statistics",
       stats["total_docs"] == 2 and stats["total_chunks"] >= 2,
       f"docs={stats['total_docs']}, chunks={stats['total_chunks']}")

rag_dup = rag.add_document("test_doc_1.md", "duplicate content")
report("RAG", "duplicate doc is skipped",
       rag_dup == 0 and rag.total_docs == 2, "")

rag_persist = RAGEngine(persist_path=str(ROOT / "ontology" / "_test_rag.json"))
rag_persist.add_document("persist_test.md", "测试持久化内容")
rag_persist2 = RAGEngine(persist_path=str(ROOT / "ontology" / "_test_rag.json"))
report("RAG", "persistence save/load",
       rag_persist2.total_docs == 1,
       f"loaded_docs={rag_persist2.total_docs}")
try:
    os.remove(str(ROOT / "ontology" / "_test_rag.json"))
except Exception:
    pass


section("TEST UNDO: Ontology Undo/Redo")

from core.ontology_engine import OntologyEngine, ATA_STRUCTURE

onto_undo = OntologyEngine.__new__(OntologyEngine)
onto_undo.db_path = ""
from rdflib import Graph as RDFGraph2
onto_undo.rdf = RDFGraph2()
onto_undo._bind_namespaces()
import networkx as nx2
onto_undo.nx_graph = nx2.DiGraph()
onto_undo.nodes = {}
onto_undo.edges = []
onto_undo.schema = {}
onto_undo._undo_stack = []
onto_undo._redo_stack = []
onto_undo._max_undo = 50

onto_undo.add_node("concept", "TestA")
onto_undo.snapshot("step1")
onto_undo.add_node("concept", "TestB")
report("UNDO", "snapshot saved state",
       len(onto_undo._undo_stack) == 1, "")
report("UNDO", "has 2 nodes before undo",
       len(onto_undo.nodes) == 2, f"nodes={len(onto_undo.nodes)}")

onto_undo.undo()
report("UNDO", "undo restores to 1 node",
       len(onto_undo.nodes) == 1, f"nodes={len(onto_undo.nodes)}")
report("UNDO", "can_redo is True after undo",
       onto_undo.can_redo, "")

onto_undo.redo()
report("UNDO", "redo restores to 2 nodes",
       len(onto_undo.nodes) == 2, f"nodes={len(onto_undo.nodes)}")

report("UNDO", "ATA_STRUCTURE has entries",
       len(ATA_STRUCTURE) > 20, f"ata_count={len(ATA_STRUCTURE)}")
report("UNDO", "ATA-27 is Flight Controls",
       ATA_STRUCTURE.get("27", {}).get("name") == "飞行操纵", "")
report("UNDO", "ATA-24 zone is correct",
       "设备舱" in ATA_STRUCTURE.get("24", {}).get("zone", ""), "")

onto_undo2 = OntologyEngine.__new__(OntologyEngine)
onto_undo2.db_path = ""
onto_undo2.rdf = RDFGraph2()
onto_undo2._bind_namespaces()
onto_undo2.nx_graph = nx2.DiGraph()
onto_undo2.nodes = {}
onto_undo2.edges = []
onto_undo2.schema = {}
onto_undo2._undo_stack = []
onto_undo2._redo_stack = []
onto_undo2._max_undo = 50

onto_undo2.add_node("system_req", "EPS需求", properties={"ata_chapter": "24"}, source_doc="doc1.md")
onto_undo2.add_node("concept", "无ATA", source_doc="doc2.md")
docs = onto_undo2.get_source_docs()
report("UNDO", "get_source_docs groups by doc",
       "doc1.md" in docs and "doc2.md" in docs,
       f"docs={list(docs.keys())}")

ata = onto_undo2.get_ata_mapping()
report("UNDO", "get_ata_mapping finds ATA-24",
       "24" in ata and len(ata["24"]) == 1,
       f"ata_keys={list(ata.keys())}")


section("TEST GUI: New Features (Multi-tree, Undo, RAG)")

mw_src_new = (ROOT / "gui" / "main_window.py").read_text(encoding="utf-8")
report("GUI-NEW", "tree_view_combo exists",
       "tree_view_combo" in mw_src_new, "")
report("GUI-NEW", "build_tree_by_doc method",
       "_build_tree_by_doc" in mw_src_new, "")
report("GUI-NEW", "build_tree_by_ata method",
       "_build_tree_by_ata" in mw_src_new, "")
report("GUI-NEW", "build_tree_flat method",
       "_build_tree_flat" in mw_src_new, "")
report("GUI-NEW", "undo_btn exists",
       "undo_btn" in mw_src_new, "")
report("GUI-NEW", "redo_btn exists",
       "redo_btn" in mw_src_new, "")
report("GUI-NEW", "_undo_graph method",
       "def _undo_graph" in mw_src_new, "")
report("GUI-NEW", "_redo_graph method",
       "def _redo_graph" in mw_src_new, "")
report("GUI-NEW", "Ctrl+Z shortcut",
       'Ctrl+Z' in mw_src_new, "")
report("GUI-NEW", "Ctrl+Y shortcut",
       'Ctrl+Y' in mw_src_new, "")
report("GUI-NEW", "RAG engine imported",
       "RAGEngine" in mw_src_new, "")
report("GUI-NEW", "rag.build_context in send_message",
       "rag.build_context" in mw_src_new, "")
report("GUI-NEW", "/rag_status command",
       "/rag_status" in mw_src_new, "")
report("GUI-NEW", "/rag_search command",
       "/rag_search" in mw_src_new, "")
report("GUI-NEW", "/undo command",
       '"/undo"' in mw_src_new, "")
report("GUI-NEW", "/redo command",
       '"/redo"' in mw_src_new, "")
report("GUI-NEW", "snapshot before clear_graph",
       'snapshot("清空图谱")' in mw_src_new, "")
report("GUI-NEW", "snapshot before analyze_demo",
       'snapshot("分析演示文档")' in mw_src_new, "")
report("GUI-NEW", "snapshot before import files",
       'snapshot(f"导入' in mw_src_new, "")
report("GUI-NEW", "auto-refresh graph on tab visible",
       "self.tabs.currentIndex() == 1" in mw_src_new, "")
report("GUI-NEW", "rag.add_document in analyze_demo",
       "self.rag.add_document" in mw_src_new, "")

agent_src = (ROOT / "core" / "llm_agent.py").read_text(encoding="utf-8")
report("GUI-NEW", "analyze_document has fast_mode",
       "fast_mode" in agent_src, "")
report("GUI-NEW", "analyze_document splits large docs",
       "_split_for_analysis" in agent_src, "")
report("GUI-NEW", "tier-based prompt adjustment",
       "tier in (\"tiny\", \"small\")" in agent_src
       or 'tier in ("tiny", "small")' in agent_src, "")


section("TEST UX: Humanized UX Features")

from gui.main_window import MainWindow, build_stylesheet, THEME_PRESETS
import inspect

mw_src = inspect.getsource(MainWindow)

report("UX", "stop button (stopBtnAnimated) defined",
       "stopBtnAnimated" in mw_src, "")
report("UX", "stop button text '停止生成'",
       "停止生成" in mw_src, "")
report("UX", "drag-and-drop (dragEnterEvent)",
       "dragEnterEvent" in mw_src, "")
report("UX", "drag-and-drop (dropEvent)",
       "dropEvent" in mw_src, "")
report("UX", "clear chat history with confirmation",
       "_clear_chat_history" in mw_src and "QMessageBox.question" in mw_src, "")
report("UX", "empty state for graph tab",
       "_show_graph_empty_state" in mw_src, "")
report("UX", "empty state for trace tab",
       "_show_trace_empty_state" in mw_src, "")
report("UX", "safety empty state HTML",
       "_safety_empty_state_html" in mw_src, "")
report("UX", "tooltips on buttons (setToolTip)",
       mw_src.count("setToolTip") >= 15,
       f"tooltip count: {mw_src.count('setToolTip')}")
report("UX", "pointing hand cursor (setCursor)",
       mw_src.count("PointingHandCursor") >= 10,
       f"cursor count: {mw_src.count('PointingHandCursor')}")
report("UX", "open graph in browser feature",
       "_open_graph_in_browser" in mw_src, "")
report("UX", "busy state updates placeholder text",
       "AI正在思考中" in mw_src, "")
report("UX", "smart error messages (Connection refused)",
       "Connection refused" in mw_src, "")
report("UX", "three-step quick start in welcome",
       "三步快速上手" in mw_src, "")
report("UX", "/help command available",
       '"/help"' in mw_src, "")
report("UX", "/clear command available",
       '"/clear"' in mw_src, "")
report("UX", "file import via drag-drop (_import_dropped_files)",
       "_import_dropped_files" in mw_src, "")
report("UX", "tip label for drag-drop hint",
       "tipLabel" in mw_src, "")
report("UX", "search node clear shows all results",
       "clearButtonEnabled" in mw_src or "_refresh_graph_tree" in mw_src, "")
report("UX", "stop button state management (正在停止)",
       "正在停止..." in mw_src, "")

ss_default = build_stylesheet()
report("UX", "stylesheet has stopBtnAnimated style",
       "stopBtnAnimated" in ss_default, "")
report("UX", "stylesheet has emptyStateTitle style",
       "emptyStateTitle" in ss_default, "")
report("UX", "stylesheet has emptyStateBtn style",
       "emptyStateBtn" in ss_default, "")
report("UX", "stylesheet has tipLabel style",
       "tipLabel" in ss_default, "")


# ============================================================
#  SUMMARY
# ============================================================
print("\n" + "=" * 60)
print(f"  TEST SUMMARY")
print(f"  PASS: {PASS}  |  FAIL: {FAIL}  |  WARN: {WARN}")
print(f"  Total: {PASS + FAIL + WARN}")
print("=" * 60)

if FAIL > 0:
    print("\n  FAILURES:")
    for mod, test, status, detail in RESULTS:
        if status == "FAIL":
            print(f"    [FAIL] {mod} / {test}: {detail}")

if WARN > 0:
    print("\n  WARNINGS:")
    for mod, test, status, detail in RESULTS:
        if status == "WARN":
            print(f"    [WARN] {mod} / {test}: {detail}")

print()
sys.exit(1 if FAIL > 0 else 0)
