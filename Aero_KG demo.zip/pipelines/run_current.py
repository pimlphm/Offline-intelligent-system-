from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Iterable, List, Optional

import yaml

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.doc_parser import parse_document
from core.llm_agent import create_llm_client
from core.rag_engine import RAGEngine


DEFAULT_QUERY = "What does the Boeing B787 Electrical Power System document describe?"


def discover_demo_documents(root: Path) -> List[Path]:
    candidates = []
    for pattern in (
        "docs/demo_airbus/*.md",
        "docs/demo_boeing/*.md",
        "docs/demo_airbus/*.txt",
        "docs/demo_boeing/*.txt",
    ):
        candidates.extend(sorted(root.glob(pattern)))
    return candidates


def summarize_retrieval(results: List[dict], max_items: int = 3) -> str:
    lines = []
    for item in results[:max_items]:
        text = " ".join(item["text"].split())
        snippet = text[:220] + ("..." if len(text) > 220 else "")
        lines.append(
            f"- {item['doc_name']}#{item['chunk_id']} (score={item['score']}): {snippet}"
        )
    return "\n".join(lines) if lines else "- No retrieval hits."


def build_fallback_answer(query: str, results: List[dict]) -> str:
    if not results:
        return (
            "No relevant passages were retrieved from the current corpus, "
            "so the current pipeline cannot answer this request yet."
        )
    top = results[0]
    return (
        f"Offline fallback answer for query: {query}\n"
        f"Best current evidence: {top['doc_name']}#{top['chunk_id']}\n"
        f"{top['text'][:600]}"
    )


def run_current_pipeline(
    query: str = DEFAULT_QUERY,
    document_paths: Optional[Iterable[Path | str]] = None,
    output_path: Optional[Path | str] = None,
    use_llm: bool = True,
    config_path: Optional[Path | str] = None,
) -> dict:
    config_file = Path(config_path) if config_path else ROOT / "config.yaml"
    config = yaml.safe_load(config_file.read_text(encoding="utf-8"))

    source_paths = [Path(item) for item in (document_paths or discover_demo_documents(ROOT))]
    docs = []
    rag = RAGEngine()

    started = time.perf_counter()
    for path in source_paths:
        parsed = parse_document(str(path))
        if not parsed or not parsed.get("content", "").strip():
            continue
        docs.append(parsed["name"])
        rag.add_document(parsed["name"], parsed["content"])

    retrieval_results = rag.search(query, top_k=5)
    context = rag.build_context(query, top_k=3, max_chars=2500)

    llm_used = False
    model_name = None
    answer = build_fallback_answer(query, retrieval_results)
    error = None

    if use_llm:
        llm = create_llm_client(config)
        if llm.check_connection():
            llm_used = True
            model_name = llm.get_current_model()
            prompt = (
                "Answer using only the supplied context. "
                "If the evidence is incomplete, say so. "
                "Cite filenames inline."
            )
            user_message = (
                f"Question: {query}\n\n"
                f"Context:\n{context or 'No context retrieved.'}"
            )
            try:
                answer = llm.chat([{"role": "user", "content": user_message}], system=prompt)
            except Exception as exc:  # pragma: no cover - defensive network path
                error = str(exc)

    elapsed_ms = round((time.perf_counter() - started) * 1000, 2)
    report = {
        "status": "ok" if docs else "empty",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "query": query,
        "indexed_documents": docs,
        "indexed_doc_count": len(docs),
        "indexed_chunk_count": rag.total_chunks,
        "retrieval_results": retrieval_results,
        "retrieval_summary": summarize_retrieval(retrieval_results),
        "llm_used": llm_used,
        "model_name": model_name,
        "answer": answer,
        "latency_ms": elapsed_ms,
        "error": error,
    }

    report_path = Path(output_path) if output_path else ROOT / "output" / "reports" / "run_current_report.json"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a smoke test for the current retrieval/generation path.")
    parser.add_argument("--query", default=DEFAULT_QUERY)
    parser.add_argument("--output", default=str(ROOT / "output" / "reports" / "run_current_report.json"))
    parser.add_argument("--no-llm", action="store_true")
    parser.add_argument("--docs", nargs="*", default=None)
    args = parser.parse_args()

    result = run_current_pipeline(
        query=args.query,
        document_paths=args.docs,
        output_path=args.output,
        use_llm=not args.no_llm,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
