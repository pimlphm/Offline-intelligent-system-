"""
民机适航知识库Agent - GUI主界面
================================================
面向空客/波音民机设计团队的工作流集成工具
- 暗色军工/航空主题 (#0d1117)
- 适航认证工作流 (ARP4754A/DO-178C/ARP4761)
- 安全评估/追溯分析/变更影响分析
- Ollama模型运行时切换
- 赤橙黄绿青蓝紫 关联强度色谱
"""
import sys
import os
import json
import threading
from pathlib import Path
from datetime import datetime

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QSplitter, QTextEdit, QLineEdit, QPushButton, QLabel,
    QTabWidget, QTreeWidget, QTreeWidgetItem, QFileDialog,
    QProgressBar, QStatusBar, QMenu, QMessageBox,
    QComboBox, QGroupBox, QListWidget,
    QFrame, QTextBrowser, QAction, QToolBar, QSizePolicy,
    QColorDialog, QGridLayout, QDialog, QDialogButtonBox,
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QUrl, QTimer, QSize
from PyQt5.QtGui import QFont, QColor, QIcon, QTextCursor, QPalette, QPainter, QKeySequence
from PyQt5.QtWidgets import QShortcut

try:
    from PyQt5.QtWebEngineWidgets import QWebEngineView
    HAS_WEBENGINE = True
except ImportError:
    HAS_WEBENGINE = False


BASE_DIR = Path(__file__).resolve().parent.parent

from core.ontology_engine import STRENGTH_SPECTRUM, TYPE_HIERARCHY

# ============================================================
#  暗色军工/航空主题样式
# ============================================================

THEME_PRESETS = {
    "深空黑 (默认)": {"bg": "#0d1117", "panel": "#161b22", "border": "#30363d",
                     "text": "#c9d1d9", "accent": "#58a6ff", "dim": "#8b949e"},
    "午夜蓝":       {"bg": "#0a1929", "panel": "#0d2137", "border": "#1a3a5c",
                     "text": "#b2d4f5", "accent": "#5ea8f5", "dim": "#6b8ab0"},
    "军绿色":       {"bg": "#0e1510", "panel": "#141f17", "border": "#243b2a",
                     "text": "#b8d4bd", "accent": "#4caf50", "dim": "#6d8f6f"},
    "暗红色":       {"bg": "#150a0a", "panel": "#1f1010", "border": "#3d1e1e",
                     "text": "#d4b8b8", "accent": "#ef5350", "dim": "#8f6d6d"},
    "深灰色":       {"bg": "#1a1a1a", "panel": "#242424", "border": "#3a3a3a",
                     "text": "#d0d0d0", "accent": "#78a9f0", "dim": "#888888"},
    "纯黑色":       {"bg": "#000000", "panel": "#0a0a0a", "border": "#222222",
                     "text": "#e0e0e0", "accent": "#4fc3f7", "dim": "#666666"},
    "深紫色":       {"bg": "#0d0a17", "panel": "#15102a", "border": "#2a1f4a",
                     "text": "#ccc0e0", "accent": "#b388ff", "dim": "#7a6a9a"},
}


def build_stylesheet(bg="#0d1117", panel="#161b22", border="#30363d",
                     text="#c9d1d9", accent="#58a6ff", dim="#8b949e"):
    sel_bg = accent
    hover = panel
    return f"""
QMainWindow {{
    background-color: {bg};
    color: {text};
}}
QWidget {{
    background-color: {bg};
    color: {text};
    font-family: "Microsoft YaHei", "Segoe UI", sans-serif;
}}
QMenuBar {{
    background-color: {panel};
    color: {text};
    border-bottom: 1px solid {border};
    padding: 2px;
    font-size: 13px;
}}
QMenuBar::item {{
    background: transparent;
    padding: 6px 14px;
    border-radius: 4px;
}}
QMenuBar::item:selected {{
    background-color: {border};
    color: {accent};
}}
QMenu {{
    background-color: {panel};
    border: 1px solid {border};
    border-radius: 6px;
    padding: 4px;
    color: {text};
}}
QMenu::item {{
    padding: 6px 28px 6px 14px;
    border-radius: 4px;
}}
QMenu::item:selected {{
    background-color: {sel_bg};
    color: #ffffff;
}}
QMenu::separator {{
    height: 1px;
    background: {border};
    margin: 4px 8px;
}}
QToolBar {{
    background-color: {panel};
    border-bottom: 1px solid {border};
    padding: 4px 8px;
    spacing: 6px;
}}
QToolBar QLabel {{
    color: {dim};
    font-size: 12px;
    padding: 0 4px;
    background: transparent;
}}
QToolBar QLabel#backendLabel {{
    color: #3fb950;
    font-weight: bold;
    font-size: 13px;
    padding: 4px 10px;
    background-color: {bg};
    border: 1px solid #238636;
    border-radius: 10px;
}}
QTabWidget::pane {{
    border: 1px solid {border};
    background: {bg};
    border-radius: 6px;
    top: -1px;
}}
QTabBar::tab {{
    background: {panel};
    color: {dim};
    padding: 8px 22px;
    margin-right: 2px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    border: 1px solid {border};
    border-bottom: none;
    font-size: 13px;
    font-weight: bold;
}}
QTabBar::tab:selected {{
    background: {bg};
    color: {accent};
    border-bottom: 2px solid {accent};
}}
QTabBar::tab:hover:!selected {{
    background: {border};
    color: {text};
}}
QPushButton {{
    background-color: {border};
    color: {text};
    border: 1px solid {border};
    padding: 7px 16px;
    border-radius: 6px;
    font-size: 13px;
    font-weight: bold;
}}
QPushButton:hover {{
    background-color: {panel};
    border-color: {accent};
    color: {accent};
}}
QPushButton:pressed {{
    background-color: {bg};
}}
QPushButton:disabled {{
    background-color: {panel};
    color: {dim};
    border-color: {border};
}}
QPushButton#primaryBtn {{
    background-color: {sel_bg};
    border-color: {sel_bg};
    color: #ffffff;
}}
QPushButton#primaryBtn:hover {{
    background-color: {accent};
}}
QPushButton#dangerBtn {{
    background-color: #da3633;
    border-color: #da3633;
    color: #ffffff;
}}
QPushButton#dangerBtn:hover {{
    background-color: #f85149;
}}
QPushButton#successBtn {{
    background-color: #238636;
    border-color: #238636;
    color: #ffffff;
}}
QPushButton#successBtn:hover {{
    background-color: #2ea043;
}}
QPushButton#quickBtn {{
    background-color: {bg};
    border: 1px solid {border};
    color: {dim};
    font-weight: normal;
    font-size: 12px;
    padding: 4px 12px;
}}
QPushButton#quickBtn:hover {{
    color: {accent};
    border-color: {accent};
    background-color: {panel};
}}
QLineEdit, QTextEdit {{
    background-color: {bg};
    border: 1px solid {border};
    border-radius: 6px;
    padding: 8px;
    font-size: 13px;
    color: {text};
    selection-background-color: {sel_bg};
}}
QLineEdit:focus, QTextEdit:focus {{
    border: 1px solid {accent};
}}
QTextBrowser {{
    background-color: {bg};
    border: 1px solid {border};
    border-radius: 8px;
    padding: 8px;
    color: {text};
    font-size: 14px;
}}
QTreeWidget {{
    background-color: {bg};
    border: 1px solid {border};
    border-radius: 6px;
    color: {text};
    font-size: 13px;
    alternate-background-color: {panel};
}}
QTreeWidget::item {{
    padding: 4px 2px;
    border-bottom: 1px solid {border};
}}
QTreeWidget::item:hover {{
    background: {panel};
}}
QTreeWidget::item:selected {{
    background: {sel_bg};
    color: #ffffff;
}}
QTreeWidget QHeaderView::section {{
    background-color: {panel};
    color: {dim};
    border: none;
    border-bottom: 1px solid {border};
    padding: 6px;
    font-weight: bold;
    font-size: 12px;
}}
QGroupBox {{
    font-weight: bold;
    border: 1px solid {border};
    border-radius: 8px;
    margin-top: 14px;
    padding-top: 18px;
    background: {panel};
    color: {text};
}}
QGroupBox::title {{
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 6px;
    color: {accent};
}}
QProgressBar {{
    border: none;
    border-radius: 4px;
    background: {border};
    height: 6px;
    text-align: center;
}}
QProgressBar::chunk {{
    background: {accent};
    border-radius: 4px;
}}
QStatusBar {{
    background: {bg};
    color: {dim};
    border-top: 1px solid {border};
    font-size: 12px;
    padding: 2px 8px;
}}
QStatusBar QLabel {{
    color: {dim};
    background: transparent;
    padding: 0 6px;
}}
QListWidget {{
    background-color: {bg};
    border: 1px solid {border};
    border-radius: 6px;
    color: {text};
    font-size: 13px;
}}
QListWidget::item {{
    padding: 4px 8px;
    border-bottom: 1px solid {border};
}}
QListWidget::item:hover {{
    background: {panel};
}}
QListWidget::item:selected {{
    background: {sel_bg};
    color: #ffffff;
}}
QComboBox {{
    background-color: {bg};
    border: 1px solid {border};
    border-radius: 6px;
    padding: 5px 28px 5px 8px;
    color: {text};
    font-size: 13px;
    min-width: 180px;
}}
QComboBox:hover {{
    border-color: {accent};
}}
QComboBox::drop-down {{
    border: none;
    width: 24px;
}}
QComboBox::down-arrow {{
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid {dim};
}}
QComboBox QAbstractItemView {{
    background-color: {panel};
    border: 1px solid {border};
    color: {text};
    selection-background-color: {sel_bg};
    outline: none;
}}
QSplitter::handle {{
    background-color: {border};
    width: 2px;
}}
QSplitter::handle:hover {{
    background-color: {accent};
}}
QScrollBar:vertical {{
    background: {bg};
    width: 10px;
    border-radius: 5px;
}}
QScrollBar::handle:vertical {{
    background: {border};
    border-radius: 5px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: {dim};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QScrollBar:horizontal {{
    background: {bg};
    height: 10px;
    border-radius: 5px;
}}
QScrollBar::handle:horizontal {{
    background: {border};
    border-radius: 5px;
    min-width: 30px;
}}
QScrollBar::handle:horizontal:hover {{
    background: {dim};
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0;
}}
QFrame#separator {{
    background-color: {border};
    max-height: 1px;
}}
QLabel#sectionHeader {{
    color: {accent};
    font-size: 15px;
    font-weight: bold;
    padding: 8px 4px;
    background: transparent;
}}
QLabel#spectrumLabel {{
    font-size: 11px;
    padding: 2px 4px;
    background: transparent;
}}
QPushButton#stopBtnAnimated {{
    background-color: #da3633;
    border: 2px solid #f85149;
    color: #ffffff;
    font-weight: bold;
    font-size: 14px;
    padding: 7px 20px;
    border-radius: 6px;
}}
QPushButton#stopBtnAnimated:hover {{
    background-color: #f85149;
    border-color: #ff7b72;
}}
QLabel#emptyStateTitle {{
    color: {accent};
    font-size: 18px;
    font-weight: bold;
    padding: 0;
    background: transparent;
}}
QLabel#emptyStateDesc {{
    color: {dim};
    font-size: 13px;
    padding: 0;
    background: transparent;
}}
QLabel#emptyStateIcon {{
    color: {border};
    font-size: 48px;
    padding: 0;
    background: transparent;
}}
QPushButton#emptyStateBtn {{
    background-color: {accent};
    color: #ffffff;
    border: none;
    padding: 10px 28px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: bold;
}}
QPushButton#emptyStateBtn:hover {{
    background-color: {text};
    color: {bg};
}}
QLabel#tipLabel {{
    color: {dim};
    font-size: 11px;
    padding: 2px 6px;
    background: transparent;
    font-style: italic;
}}
"""


STYLE_SHEET = build_stylesheet()


# ============================================================
#  后台工作线程
# ============================================================

class LLMWorker(QThread):
    """LLM流式/非流式调用线程 (可中断)"""
    chunk_received = pyqtSignal(str)
    finished_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)
    aborted_signal = pyqtSignal()

    def __init__(self, agent, message, mode="chat"):
        super().__init__()
        self.agent = agent
        self.message = message
        self.mode = mode
        self._abort = False

    def abort(self):
        self._abort = True

    def run(self):
        try:
            if self.mode == "chat":
                gen = self.agent.chat_with_context(self.message, stream=True)
                full = ""
                for chunk in gen:
                    if self._abort:
                        self.aborted_signal.emit()
                        if full:
                            self.agent.conversation_history.append(
                                {"role": "assistant", "content": full + "\n[已停止]"}
                            )
                        return
                    full += chunk
                    self.chunk_received.emit(chunk)
                self.agent.conversation_history.append(
                    {"role": "assistant", "content": full}
                )
                self.finished_signal.emit(full)
            elif self.mode == "reason":
                result = self.agent.reason_on_graph()
                if self._abort:
                    self.aborted_signal.emit()
                    return
                self.finished_signal.emit(result)
        except Exception as e:
            if not self._abort:
                self.error_signal.emit(str(e))


class DocAnalyzeWorker(QThread):
    """文档分析线程 (可中断)"""
    progress = pyqtSignal(str)
    finished_signal = pyqtSignal(dict)
    error_signal = pyqtSignal(str)
    aborted_signal = pyqtSignal()

    def __init__(self, agent, doc_info):
        super().__init__()
        self.agent = agent
        self.doc_info = doc_info
        self._abort = False

    def abort(self):
        self._abort = True

    def run(self):
        try:
            name = self.doc_info["name"]
            self.progress.emit(f"正在分析文档 Analyzing: {name} ...")
            analysis = self.agent.analyze_document(
                self.doc_info["content"], name
            )
            if self._abort:
                self.aborted_signal.emit()
                return
            self.progress.emit("正在构建知识图谱 Building ontology ...")
            self.agent.build_graph_from_analysis(analysis, source_doc=name)
            if self._abort:
                self.aborted_signal.emit()
                return
            self.progress.emit("分析完成 Analysis complete!")
            self.finished_signal.emit(analysis)
        except Exception as e:
            if not self._abort:
                self.error_signal.emit(str(e))


# ============================================================
#  主窗口
# ============================================================

class MainWindow(QMainWindow):

    def __init__(self, agent, ontology, config, experience=None,
                 standards=None, hw_info=None):
        super().__init__()
        self.agent = agent
        self.ontology = ontology
        self.config = config
        self.experience = experience
        self.standards = standards
        self.hw_info = hw_info or {}
        self.current_worker = None
        self._workers = []
        self._physics_on = True

        from core.rag_engine import RAGEngine
        rag_path = str(BASE_DIR / "ontology" / "rag_index.json")
        self.rag = RAGEngine(persist_path=rag_path)

        self._theme_file = BASE_DIR / "theme_config.json"
        self._current_theme = self._load_theme()
        self._abort_flag = False

        self._init_ui()
        self._connect_signals()
        self._refresh_graph_tree()
        self._refresh_model_list()
        self.setAcceptDrops(True)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
            self.statusBar().showMessage(
                "释放文件以导入分析... (支持PDF/Word/Excel/PPT/Markdown/XML等)", 0)

    def dragLeaveEvent(self, event):
        self.statusBar().showMessage("就绪", 2000)

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if not urls:
            return
        files = [u.toLocalFile() for u in urls if u.isLocalFile()]
        if not files:
            return

        supported = {'.pdf', '.docx', '.doc', '.xlsx', '.xls', '.pptx',
                     '.txt', '.md', '.html', '.htm', '.xml', '.json',
                     '.yaml', '.yml', '.csv', '.rst', '.tex', '.reqif'}
        valid = [f for f in files if Path(f).suffix.lower() in supported]

        if not valid:
            self.statusBar().showMessage("不支持的文件格式", 3000)
            return

        self.tabs.setCurrentIndex(0)
        names = [Path(f).name for f in valid]
        reply = QMessageBox.question(
            self, "导入文档确认",
            f"即将导入并分析以下 {len(valid)} 个文档:\n\n"
            + "\n".join(f"  ·  {n}" for n in names[:10])
            + ("\n  ..." if len(names) > 10 else "")
            + "\n\n确定开始分析？",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
        )
        if reply != QMessageBox.Yes:
            return

        self._import_dropped_files(valid)

    def _import_dropped_files(self, file_paths):
        from core.doc_parser import parse_document
        self._append_chat("system",
                          f"正在导入 {len(file_paths)} 个文档...")
        self._set_busy(True)
        self.ontology.snapshot(f"导入{len(file_paths)}个文档")
        self._abort_flag = False

        def do_import():
            for i, fpath in enumerate(file_paths):
                if self._abort_flag:
                    self._safe_append("system", f"[已停止] 在第 {i}/{len(file_paths)} 个文件处停止")
                    self._safe_set_busy(False)
                    return
                name = Path(fpath).name
                self._safe_append("system", f"[{i+1}/{len(file_paths)}] 解析: {name}")
                try:
                    doc = parse_document(fpath)
                    if not doc or len(doc.get("content", "").strip()) < 20:
                        self._safe_append("system", f"  跳过 (内容过少)")
                        continue
                    content = doc["content"]
                    self.rag.add_document(name, content)
                    analysis = self.agent.analyze_document(content, name)
                    if self._abort_flag:
                        self._safe_set_busy(False)
                        return
                    self.agent.build_graph_from_analysis(analysis, source_doc=name)
                    ent = len(analysis.get("entities", []))
                    rel = len(analysis.get("relations", []))
                    self._safe_append("system", f"  ✓ 提取 {ent} 实体, {rel} 关系")
                    self._safe_refresh()
                except Exception as e:
                    self._safe_append("system", f"  ✗ 分析失败: {e}")

            rag_stats = self.rag.get_statistics()
            self._safe_append("system",
                f"\n全部文档导入完成!\n"
                f"RAG索引: {rag_stats['total_docs']}文档, {rag_stats['total_chunks']}段落\n"
                f"可直接用自然语言提问，或切换「知识图谱」查看结果。\n"
                f"如果结果不满意，可点击「撤销」回退。")
            self._safe_refresh()

        threading.Thread(target=do_import, daemon=True).start()

    def _load_theme(self) -> dict:
        if self._theme_file.exists():
            try:
                with open(self._theme_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return dict(THEME_PRESETS["深空黑 (默认)"])

    def _save_theme(self, theme: dict):
        self._current_theme = theme
        with open(self._theme_file, "w", encoding="utf-8") as f:
            json.dump(theme, f, ensure_ascii=False, indent=2)

    def _apply_theme(self, theme: dict):
        self._save_theme(theme)
        ss = build_stylesheet(**theme)
        self.setStyleSheet(ss)

    # ================================================================
    #  UI 构建
    # ================================================================

    def _init_ui(self):
        self.setWindowTitle(
            "民机适航知识库Agent — ARP4754A/DO-178C/ARP4761 适航认证工作流"
        )
        self.setMinimumSize(1440, 880)
        self.setStyleSheet(build_stylesheet(**self._current_theme))

        self._create_menu()
        self._create_toolbar()

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(6, 6, 6, 6)
        main_layout.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)
        main_layout.addWidget(splitter)

        splitter.addWidget(self._create_left_panel())
        splitter.addWidget(self._create_right_panel())
        splitter.setSizes([380, 1060])

        self._create_status_bar()

    # ---- Menu ----

    def _create_menu(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu("文件(&F)")
        self._add_action(file_menu, "导入文档(&O)...", self._import_document)
        self._add_action(file_menu, "批量导入目录(&D)...", self._import_directory)
        self._add_action(file_menu, "导入ReqIF (DOORS导出)(&R)...", self._import_reqif)
        file_menu.addSeparator()
        self._add_action(file_menu, "导出知识图谱JSON(&E)...", self._export_graph)
        self._add_action(file_menu, "导出RDF/OWL(&W)...", self._export_rdf)
        file_menu.addSeparator()
        self._add_action(file_menu, "退出(&Q)", self.close)

        cert_menu = menubar.addMenu("适航认证(&C)")
        self._add_action(cert_menu, "安全评估 FHA/DAL分配(&S)",
                         self._run_safety_assessment)
        self._add_action(cert_menu, "DO-178C追溯完整性检查(&T)",
                         self._check_do178c_traceability)
        self._add_action(cert_menu, "变更影响分析(&I)",
                         self._run_impact_analysis)
        cert_menu.addSeparator()
        self._add_action(cert_menu, "生成追溯矩阵报告(&M)",
                         self._show_traceability)

        analysis_menu = menubar.addMenu("知识分析(&A)")
        self._add_action(analysis_menu, "发现缺失链接(&M)",
                         self._find_missing_links)
        self._add_action(analysis_menu, "推导知识演进(&N)",
                         self._suggest_next_gen)
        analysis_menu.addSeparator()
        self._add_action(analysis_menu, "聚类分析(&C)",
                         self._show_clusters)
        self._add_action(analysis_menu, "桥接节点分析(&B)",
                         self._show_bridge_nodes)

        exp_menu = menubar.addMenu("经验管理(&E)")
        self._add_action(exp_menu, "设置当前型号(&P)", self._set_current_program)
        self._add_action(exp_menu, "生成审计汇总报告(&R)", self._generate_audit_report)
        exp_menu.addSeparator()
        self._add_action(exp_menu, "打开经验文件夹(&O)", self._open_experience_folder)

        std_menu = menubar.addMenu("标准库(&S)")
        self._add_action(std_menu, "搜索标准(&F)", self._search_standards)
        self._add_action(std_menu, "三方交叉引用表(&X)", self._show_cross_reference)
        std_menu.addSeparator()
        self._add_action(std_menu, "打开标准文件夹(&O)", self._open_standards_folder)

        archive_menu = menubar.addMenu("归档管理(&R)")
        self._add_action(archive_menu, "自动归档整理(&A)", self._auto_archive)

        theme_menu = menubar.addMenu("主题(&T)")
        for name in THEME_PRESETS:
            action = QAction(name, self)
            action.triggered.connect(lambda checked, n=name: self._apply_theme(
                dict(THEME_PRESETS[n])))
            theme_menu.addAction(action)
        theme_menu.addSeparator()
        self._add_action(theme_menu, "自定义颜色(&C)...", self._open_theme_editor)
        self._add_action(theme_menu, "恢复默认(&D)", lambda: self._apply_theme(
            dict(THEME_PRESETS["深空黑 (默认)"])))

        help_menu = menubar.addMenu("帮助(&H)")
        self._add_action(help_menu, "关于(&A)", self._show_about)

    def _add_action(self, menu, text, slot):
        action = QAction(text, self)
        action.triggered.connect(slot)
        menu.addAction(action)

    # ---- Toolbar with model selector ----

    def _create_toolbar(self):
        toolbar = QToolBar("模型控制")
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(18, 18))
        self.addToolBar(toolbar)

        self.backend_label = QLabel()
        self.backend_label.setObjectName("backendLabel")
        self._update_backend_label()
        toolbar.addWidget(self.backend_label)

        toolbar.addSeparator()

        lbl = QLabel("推理模型:")
        toolbar.addWidget(lbl)

        self.model_combo = QComboBox()
        self.model_combo.setMinimumWidth(220)
        self.model_combo.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.model_combo.setToolTip("选择本地Ollama或vLLM-Ascend推理模型")
        self.model_combo.currentTextChanged.connect(self._on_model_changed)
        toolbar.addWidget(self.model_combo)

        refresh_btn = QPushButton("刷新模型")
        refresh_btn.setMaximumHeight(28)
        refresh_btn.setToolTip("重新获取可用的本地模型列表")
        refresh_btn.setCursor(Qt.PointingHandCursor)
        refresh_btn.clicked.connect(self._refresh_model_list)
        toolbar.addWidget(refresh_btn)

        toolbar.addSeparator()

        if self.hw_info:
            toolbar.addSeparator()
            gpu_str = self.hw_info.get("gpu_summary", "")
            tier = self.hw_info.get("recommended_tier", {})
            hw_lbl = QLabel(
                f"GPU: {gpu_str} | {tier.get('label', '')}"
                if gpu_str else "CPU模式"
            )
            hw_lbl.setStyleSheet(
                "color:#d29922; font-size:11px; font-weight:bold; "
                "padding:2px 8px; background:transparent;"
            )
            hw_lbl.setToolTip(
                f"CPU: {self.hw_info.get('cpu', {}).get('name', '?')}\n"
                f"内存: {self.hw_info.get('ram_gb', '?')} GB\n"
                f"GPU: {gpu_str}\n"
                f"显存: {self.hw_info.get('vram_mb', 0)} MB\n"
                f"推荐层级: {tier.get('label', '?')}\n"
                f"推荐模型: {', '.join(tier.get('models', [])[:2])}"
            )
            toolbar.addWidget(hw_lbl)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        toolbar.addWidget(spacer)

        toolbar.addWidget(self._create_spectrum_legend())

    def _create_spectrum_legend(self):
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(4, 2, 4, 2)
        layout.setSpacing(2)

        title_lbl = QLabel("关联强度:")
        title_lbl.setObjectName("spectrumLabel")
        title_lbl.setStyleSheet(
            "color:#8b949e; font-size:11px; font-weight:bold; background:transparent;"
        )
        layout.addWidget(title_lbl)

        for threshold, color, cn_name, desc in STRENGTH_SPECTRUM:
            lbl = QLabel(f" {cn_name} ")
            lbl.setObjectName("spectrumLabel")
            lbl.setStyleSheet(
                f"background-color:{color}; color:#ffffff; font-size:11px; "
                f"font-weight:bold; border-radius:3px; padding:1px 5px;"
            )
            lbl.setToolTip(f"{cn_name} {desc} (≥{threshold:.2f})")
            layout.addWidget(lbl)

        return container

    def _update_backend_label(self):
        backend_name = self.agent.llm.backend_name
        self.backend_label.setText(f"  {backend_name}  ")
        self._update_status_backend()

    def _refresh_model_list(self):
        self.model_combo.blockSignals(True)
        self.model_combo.clear()
        models = self.agent.llm.list_models()
        current = self.agent.llm.get_current_model()
        if models:
            self.model_combo.addItems(models)
            idx = self.model_combo.findText(current)
            if idx >= 0:
                self.model_combo.setCurrentIndex(idx)
            else:
                self.model_combo.setCurrentIndex(0)
        else:
            self.model_combo.addItem(current or "N/A")
        self.model_combo.blockSignals(False)
        self._update_backend_label()
        self.statusBar().showMessage(
            f"模型列表已刷新: {len(models)} 个可用 | "
            f"当前: {current}", 3000
        )

    def _on_model_changed(self, model_name):
        if not model_name or model_name == "N/A":
            return
        self.agent.llm.set_model(model_name)
        self._update_backend_label()
        self.statusBar().showMessage(f"已切换模型 → {model_name}", 3000)

    # ---- Status Bar ----

    def _create_status_bar(self):
        sb = self.statusBar()
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximumWidth(200)
        self.progress_bar.setVisible(False)
        sb.addPermanentWidget(self.progress_bar)

        self.status_backend = QLabel()
        self._update_status_backend()
        sb.addPermanentWidget(self.status_backend)

        sb.showMessage("就绪")

    def _update_status_backend(self):
        if not hasattr(self, "status_backend"):
            return
        model = self.agent.llm.get_current_model()
        hw = self.hw_info
        gpu_str = hw.get("gpu_summary", "") if hw else ""
        tier_label = hw.get("recommended_tier", {}).get("label", "") if hw else ""
        parts = [f"模型: {model}"]
        if gpu_str:
            parts.append(f"GPU: {gpu_str}")
        if tier_label:
            parts.append(f"推荐: {tier_label}")
        self.status_backend.setText(" | ".join(parts))

    # ---- Left Panel ----

    def _create_left_panel(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        header = QLabel("知识图谱浏览器")
        header.setObjectName("sectionHeader")
        layout.addWidget(header)

        self.tree_view_combo = QComboBox()
        self.tree_view_combo.addItems(["按类型分组", "按文档分组", "按ATA结构", "全部节点"])
        self.tree_view_combo.setToolTip("切换左侧树的组织方式")
        self.tree_view_combo.currentIndexChanged.connect(self._refresh_graph_tree)
        layout.addWidget(self.tree_view_combo)

        self.graph_tree = QTreeWidget()
        self.graph_tree.setHeaderLabels(["名称", "类型", "ID"])
        self.graph_tree.setColumnWidth(0, 180)
        self.graph_tree.setColumnWidth(1, 80)
        self.graph_tree.setAlternatingRowColors(True)
        self.graph_tree.setToolTip("点击节点在右侧查看详情")
        layout.addWidget(self.graph_tree, stretch=1)

        search_box = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜索实体 (如: 增压系统, ELAC, AOA...)")
        self.search_input.setClearButtonEnabled(True)
        search_btn = QPushButton("搜索")
        search_btn.setMaximumWidth(60)
        search_btn.setCursor(Qt.PointingHandCursor)
        search_btn.clicked.connect(self._search_nodes)
        self.search_input.returnPressed.connect(self._search_nodes)
        search_box.addWidget(self.search_input)
        search_box.addWidget(search_btn)
        layout.addLayout(search_box)

        stats_group = QGroupBox("图谱统计")
        stats_layout = QVBoxLayout(stats_group)
        self.stats_label = QLabel("节点: 0 | 边: 0")
        self.stats_label.setStyleSheet(
            "font-size:12px; color:#8b949e; padding:4px; background:transparent;"
        )
        self.stats_label.setWordWrap(True)
        stats_layout.addWidget(self.stats_label)
        layout.addWidget(stats_group)

        btn_layout = QHBoxLayout()
        refresh_btn = QPushButton("刷新")
        refresh_btn.setMaximumWidth(70)
        refresh_btn.setToolTip("刷新知识图谱浏览器中的节点列表")
        refresh_btn.setCursor(Qt.PointingHandCursor)
        refresh_btn.clicked.connect(self._refresh_graph_tree)
        btn_layout.addWidget(refresh_btn)

        self.undo_btn = QPushButton("撤销")
        self.undo_btn.setMaximumWidth(60)
        self.undo_btn.setToolTip("撤销上一步图谱操作 (Ctrl+Z)")
        self.undo_btn.setCursor(Qt.PointingHandCursor)
        self.undo_btn.clicked.connect(self._undo_graph)
        btn_layout.addWidget(self.undo_btn)

        self.redo_btn = QPushButton("重做")
        self.redo_btn.setMaximumWidth(60)
        self.redo_btn.setToolTip("重做已撤销的操作 (Ctrl+Y)")
        self.redo_btn.setCursor(Qt.PointingHandCursor)
        self.redo_btn.clicked.connect(self._redo_graph)
        btn_layout.addWidget(self.redo_btn)

        clear_btn = QPushButton("清空")
        clear_btn.setObjectName("dangerBtn")
        clear_btn.setMaximumWidth(60)
        clear_btn.setToolTip("清空全部知识图谱数据")
        clear_btn.setCursor(Qt.PointingHandCursor)
        clear_btn.clicked.connect(self._clear_graph)
        btn_layout.addWidget(clear_btn)
        layout.addLayout(btn_layout)

        return panel

    # ---- Right Panel (Tabs) ----

    def _create_right_panel(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(4, 4, 4, 4)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.tabs.addTab(self._create_chat_tab(), "对话交互")
        self.tabs.addTab(self._create_graph_tab(), "知识图谱")
        self.tabs.addTab(self._create_trace_tab(), "追溯矩阵")
        self.tabs.addTab(self._create_safety_tab(), "安全评估")
        self.tabs.addTab(self._create_experience_tab(), "经验管理")
        self.tabs.addTab(self._create_standards_tab(), "标准库")
        self.tabs.addTab(self._create_docs_tab(), "文档管理")

        return panel

    def _create_chat_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(6)

        self.chat_display = QTextBrowser()
        self.chat_display.setOpenExternalLinks(True)
        self.chat_display.setAcceptDrops(True)
        self.chat_display.setHtml(self._welcome_html())
        layout.addWidget(self.chat_display, stretch=1)

        quick_row_1 = QHBoxLayout()
        quick_row_1.setSpacing(4)
        primary_commands = [
            ("1. 分析演示文档",   "/analyze_demo",    "successBtn",
             "一键分析内置波音/空客民机文档，构建知识图谱"),
            ("2. 安全评估",       "/safety_assess",   "dangerBtn",
             "执行ARP4761 FHA功能危险评估和DAL等级分配"),
            ("3. 追溯检查",       "/trace_check",     "primaryBtn",
             "检查DO-178C追溯完整性 (需求→设计→代码→测试)"),
        ]
        for text, cmd, obj_name, tip in primary_commands:
            btn = QPushButton(text)
            btn.setObjectName(obj_name)
            btn.setMinimumHeight(34)
            btn.setToolTip(tip)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda checked, c=cmd: self._handle_quick_cmd(c))
            quick_row_1.addWidget(btn)
        layout.addLayout(quick_row_1)

        quick_row_2 = QHBoxLayout()
        quick_row_2.setSpacing(4)
        secondary_commands = [
            ("变更影响",   "/impact_analysis",  "输入节点名称，分析上下游影响范围"),
            ("缺失链接",   "/find_missing",     "发现知识图谱中被忽视的潜在关联"),
            ("自动归档",   "/auto_archive",     "自动整理归档文档到分类文件夹"),
            ("清空对话",   "_clear_chat",       "清空当前对话记录"),
        ]
        for text, cmd, tip in secondary_commands:
            btn = QPushButton(text)
            btn.setObjectName("quickBtn")
            btn.setMaximumHeight(28)
            btn.setToolTip(tip)
            btn.setCursor(Qt.PointingHandCursor)
            if cmd == "_clear_chat":
                btn.clicked.connect(self._clear_chat_history)
            else:
                btn.clicked.connect(lambda checked, c=cmd: self._handle_quick_cmd(c))
            quick_row_2.addWidget(btn)
        layout.addLayout(quick_row_2)

        input_layout = QHBoxLayout()
        input_layout.setSpacing(6)
        self.chat_input = QLineEdit()
        self.chat_input.setPlaceholderText(
            "请输入问题，或拖拽文档到此窗口分析... (Enter 发送, Esc 停止)"
        )
        self.chat_input.setMinimumHeight(42)
        input_layout.addWidget(self.chat_input)

        self.send_btn = QPushButton("发送")
        self.send_btn.setObjectName("primaryBtn")
        self.send_btn.setMinimumHeight(42)
        self.send_btn.setMinimumWidth(90)
        self.send_btn.setToolTip("发送消息 (Enter)")
        self.send_btn.setCursor(Qt.PointingHandCursor)
        input_layout.addWidget(self.send_btn)

        self.stop_btn = QPushButton("■ 停止生成")
        self.stop_btn.setObjectName("stopBtnAnimated")
        self.stop_btn.setMinimumHeight(42)
        self.stop_btn.setMinimumWidth(110)
        self.stop_btn.setVisible(False)
        self.stop_btn.setToolTip("停止当前LLM输出 (Esc)")
        self.stop_btn.setCursor(Qt.PointingHandCursor)
        input_layout.addWidget(self.stop_btn)

        layout.addLayout(input_layout)

        tip_label = QLabel("提示: 可直接拖拽PDF/Word/Excel等文件到窗口进行分析 | "
                           "输入 / 查看所有快捷命令")
        tip_label.setObjectName("tipLabel")
        layout.addWidget(tip_label)

        return tab

    def _clear_chat_history(self):
        reply = QMessageBox.question(
            self, "清空对话",
            "确定要清空当前对话记录吗？\n\n"
            "知识图谱和经验数据不受影响。",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self.agent.conversation_history.clear()
            self.chat_display.setHtml(self._welcome_html())
            self.statusBar().showMessage("对话记录已清空", 3000)

    def _create_graph_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        toolbar = QHBoxLayout()
        gen_btn = QPushButton("生成知识图谱")
        gen_btn.setObjectName("successBtn")
        gen_btn.setToolTip("根据当前知识库数据生成可视化知识图谱")
        gen_btn.setCursor(Qt.PointingHandCursor)
        gen_btn.clicked.connect(self._generate_graph_view)
        toolbar.addWidget(gen_btn)

        self.physics_toggle = QPushButton("物理引擎: 开")
        self.physics_toggle.setToolTip("开启/关闭图谱节点物理弹簧力学动画")
        self.physics_toggle.setCursor(Qt.PointingHandCursor)
        self.physics_toggle.clicked.connect(self._toggle_physics)
        toolbar.addWidget(self.physics_toggle)

        open_browser_btn = QPushButton("在浏览器中打开")
        open_browser_btn.setToolTip("在系统浏览器中查看完整图谱 (支持更大屏幕)")
        open_browser_btn.setCursor(Qt.PointingHandCursor)
        open_browser_btn.clicked.connect(self._open_graph_in_browser)
        toolbar.addWidget(open_browser_btn)

        toolbar.addStretch()
        layout.addLayout(toolbar)

        if HAS_WEBENGINE:
            self.graph_view = QWebEngineView()
            self.graph_view.setMinimumHeight(500)
            layout.addWidget(self.graph_view, stretch=1)
        else:
            self.graph_view = QTextBrowser()
            layout.addWidget(self.graph_view, stretch=1)

        self._show_graph_empty_state()
        return tab

    def _show_graph_empty_state(self):
        empty_html = """
        <div style="padding:60px 40px; text-align:center; color:#c9d1d9;
                    font-family:'Microsoft YaHei',sans-serif;">
            <div style="font-size:64px; color:#30363d; margin-bottom:16px;">◎</div>
            <h2 style="color:#58a6ff; margin-bottom:8px;">知识图谱尚未生成</h2>
            <p style="color:#8b949e; font-size:14px; max-width:500px; margin:0 auto 24px;">
                请先分析文档构建知识库，然后点击上方「生成知识图谱」按钮。<br>
                图谱将以交互式网络图展示实体间的关联关系。
            </p>
            <div style="background:#161b22; border:1px solid #30363d; border-radius:12px;
                        padding:20px; max-width:420px; margin:0 auto; text-align:left;">
                <p style="color:#58a6ff; font-weight:bold; margin:0 0 8px;">快速开始 →</p>
                <p style="color:#c9d1d9; margin:4px 0;">1. 回到「对话交互」→ 点击「分析演示文档」</p>
                <p style="color:#c9d1d9; margin:4px 0;">2. 等待分析完成后回到此页面</p>
                <p style="color:#c9d1d9; margin:4px 0;">3. 点击「生成知识图谱」查看可视化结果</p>
            </div>
        </div>
        """
        if isinstance(self.graph_view, QTextBrowser):
            self.graph_view.setHtml(empty_html)
        elif HAS_WEBENGINE:
            self.graph_view.setHtml(empty_html)

    def _open_graph_in_browser(self):
        graph_html = BASE_DIR / "ontology" / "knowledge_graph.html"
        if graph_html.exists():
            import webbrowser
            webbrowser.open(str(graph_html))
        else:
            self.statusBar().showMessage("请先生成知识图谱", 3000)

    def _create_trace_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        toolbar = QHBoxLayout()
        gen_btn = QPushButton("生成追溯矩阵报告")
        gen_btn.setObjectName("successBtn")
        gen_btn.setToolTip("生成DO-178C需求→设计→代码→测试追溯矩阵")
        gen_btn.setCursor(Qt.PointingHandCursor)
        gen_btn.clicked.connect(self._show_traceability)
        toolbar.addWidget(gen_btn)

        trace_check_btn = QPushButton("DO-178C追溯完整性检查")
        trace_check_btn.setToolTip("检查追溯链路完整性，发现孤儿需求和断裂链路")
        trace_check_btn.setCursor(Qt.PointingHandCursor)
        trace_check_btn.clicked.connect(self._check_do178c_traceability)
        toolbar.addWidget(trace_check_btn)

        toolbar.addStretch()
        layout.addLayout(toolbar)

        if HAS_WEBENGINE:
            self.trace_view = QWebEngineView()
            layout.addWidget(self.trace_view, stretch=1)
        else:
            self.trace_view = QTextBrowser()
            layout.addWidget(self.trace_view, stretch=1)

        self._show_trace_empty_state()
        return tab

    def _show_trace_empty_state(self):
        html = """
        <div style="padding:60px 40px; text-align:center; color:#c9d1d9;
                    font-family:'Microsoft YaHei',sans-serif;">
            <div style="font-size:64px; color:#30363d; margin-bottom:16px;">⟷</div>
            <h2 style="color:#3fb950; margin-bottom:8px;">追溯矩阵</h2>
            <p style="color:#8b949e; font-size:14px; max-width:520px; margin:0 auto 24px;">
                DO-178C要求建立从飞机级需求到源代码再到测试用例的完整追溯链路。<br>
                此模块帮助您检查追溯完整性，发现断裂链路和孤儿节点。
            </p>
            <div style="background:#161b22; border:1px solid #30363d; border-radius:12px;
                        padding:20px; max-width:460px; margin:0 auto; text-align:left;">
                <p style="color:#3fb950; font-weight:bold; margin:0 0 12px;">追溯层级</p>
                <p style="color:#58a6ff; margin:4px 0;">
                    飞机需求 → 系统需求 → 高层需求(HLR) → 低层需求(LLR) → 源代码 → 测试用例
                </p>
                <hr style="border:1px solid #30363d; margin:12px 0;">
                <p style="color:#8b949e; margin:0;">请先分析文档，然后点击上方按钮生成追溯报告。</p>
            </div>
        </div>
        """
        if isinstance(self.trace_view, QTextBrowser):
            self.trace_view.setHtml(html)
        elif HAS_WEBENGINE:
            self.trace_view.setHtml(html)

    def _create_safety_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        toolbar = QHBoxLayout()
        fha_btn = QPushButton("执行安全评估 (FHA/DAL)")
        fha_btn.setObjectName("dangerBtn")
        fha_btn.setToolTip("基于ARP4761执行功能危险评估，分配DAL等级")
        fha_btn.setCursor(Qt.PointingHandCursor)
        fha_btn.clicked.connect(self._run_safety_assessment)
        toolbar.addWidget(fha_btn)

        impact_btn = QPushButton("变更影响分析")
        impact_btn.setToolTip("分析某个需求/设计变更对上下游的影响范围")
        impact_btn.setCursor(Qt.PointingHandCursor)
        impact_btn.clicked.connect(self._run_impact_analysis)
        toolbar.addWidget(impact_btn)

        toolbar.addStretch()
        layout.addLayout(toolbar)

        self.safety_display = QTextBrowser()
        self.safety_display.setHtml(self._safety_empty_state_html())
        layout.addWidget(self.safety_display, stretch=1)

        return tab

    def _safety_empty_state_html(self):
        return (
            '<div style="padding:40px; color:#c9d1d9; font-family:Microsoft YaHei,sans-serif;">'
            '<div style="text-align:center; margin-bottom:24px;">'
            '<div style="font-size:64px; color:#30363d;">⚠</div>'
            '<h2 style="color:#f85149; margin:8px 0;">安全评估工作台</h2>'
            '<p style="color:#8b949e; font-size:14px;">基于ARP4761标准的完整安全评估流程</p>'
            '</div>'
            '<div style="display:flex; gap:12px; flex-wrap:wrap; justify-content:center; max-width:700px; margin:0 auto;">'
            '<div style="background:#1c0a0a; border:1px solid #3d1e1e; border-radius:10px; '
            'padding:16px; flex:1; min-width:200px;">'
            '<p style="color:#f85149; font-weight:bold; margin:0 0 6px;">功能危险评估 (FHA)</p>'
            '<p style="color:#8b949e; font-size:12px; margin:0;">识别系统失效状态<br>分类严重程度等级</p></div>'
            '<div style="background:#0d1a0d; border:1px solid #1a3d1a; border-radius:10px; '
            'padding:16px; flex:1; min-width:200px;">'
            '<p style="color:#3fb950; font-weight:bold; margin:0 0 6px;">DAL等级分配</p>'
            '<p style="color:#8b949e; font-size:12px; margin:0;">A(灾难) B(危险) C(重大)<br>D(轻微) E(无影响)</p></div>'
            '<div style="background:#161022; border:1px solid #2a1f4a; border-radius:10px; '
            'padding:16px; flex:1; min-width:200px;">'
            '<p style="color:#d2a8ff; font-weight:bold; margin:0 0 6px;">变更影响分析</p>'
            '<p style="color:#8b949e; font-size:12px; margin:0;">追溯上下游影响范围<br>安全性与认证合规影响</p></div>'
            '</div>'
            '<div style="text-align:center; margin-top:32px; padding:16px; '
            'background:#161b22; border:1px solid #30363d; border-radius:10px; max-width:500px; margin:32px auto 0;">'
            '<p style="color:#d29922; margin:0;">请先在「对话交互」中分析文档构建知识图谱，然后执行安全评估。</p>'
            '</div></div>'
        )

    def _create_experience_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        toolbar = QHBoxLayout()

        self.exp_program_combo = QComboBox()
        self.exp_program_combo.setMinimumWidth(150)
        self.exp_program_combo.addItem("全部型号")
        if self.experience:
            for prog in self.experience.get_all_programs():
                self.exp_program_combo.addItem(prog)
        self.exp_program_combo.currentTextChanged.connect(self._refresh_experience_list)
        toolbar.addWidget(QLabel("型号筛选:"))
        toolbar.addWidget(self.exp_program_combo)

        toolbar.addSeparator() if hasattr(toolbar, 'addSeparator') else None

        set_prog_btn = QPushButton("设置当前型号")
        set_prog_btn.setToolTip("设置当前工作的机型 (如B787, A320neo, C919)")
        set_prog_btn.setCursor(Qt.PointingHandCursor)
        set_prog_btn.clicked.connect(self._set_current_program)
        toolbar.addWidget(set_prog_btn)

        promote_btn = QPushButton("提升为永久经验")
        promote_btn.setObjectName("successBtn")
        promote_btn.setToolTip("将选中的临时经验提升为永久经验 (多型号验证的最佳实践)")
        promote_btn.setCursor(Qt.PointingHandCursor)
        promote_btn.clicked.connect(self._promote_experience)
        toolbar.addWidget(promote_btn)

        approve_btn = QPushButton("审核通过")
        approve_btn.setToolTip("标记选中的经验为审核通过状态")
        approve_btn.setCursor(Qt.PointingHandCursor)
        approve_btn.clicked.connect(lambda: self._review_experience("approved"))
        toolbar.addWidget(approve_btn)

        reject_btn = QPushButton("驳回")
        reject_btn.setObjectName("dangerBtn")
        reject_btn.setToolTip("驳回选中的经验并填写驳回原因")
        reject_btn.setCursor(Qt.PointingHandCursor)
        reject_btn.clicked.connect(lambda: self._review_experience("rejected"))
        toolbar.addWidget(reject_btn)

        report_btn = QPushButton("生成审计报告")
        report_btn.setToolTip("生成经验积累的完整审计汇总报告 (中英文)")
        report_btn.setCursor(Qt.PointingHandCursor)
        report_btn.clicked.connect(self._generate_audit_report)
        toolbar.addWidget(report_btn)

        toolbar.addStretch()
        layout.addLayout(toolbar)

        splitter = QSplitter(Qt.Vertical)

        self.exp_tree = QTreeWidget()
        self.exp_tree.setHeaderLabels(["标题", "类型", "级别", "置信度", "审核", "使用次数", "ID"])
        self.exp_tree.setColumnWidth(0, 300)
        self.exp_tree.setColumnWidth(1, 80)
        self.exp_tree.setColumnWidth(2, 60)
        self.exp_tree.setColumnWidth(3, 60)
        self.exp_tree.setColumnWidth(4, 60)
        self.exp_tree.setColumnWidth(5, 60)
        self.exp_tree.setAlternatingRowColors(True)
        self.exp_tree.itemClicked.connect(self._on_experience_selected)
        splitter.addWidget(self.exp_tree)

        self.exp_detail = QTextBrowser()
        self.exp_detail.setMaximumHeight(280)
        self.exp_detail.setHtml(
            '<div style="padding:16px; color:#c9d1d9; background:#0d1117;">'
            '<h3 style="color:#58a6ff;">经验积累与审计系统</h3>'
            '<p style="color:#8b949e;">每次文档分析和安全评估后，Agent自动提炼经验教训：</p>'
            '<ul style="color:#c9d1d9;">'
            '<li><b style="color:#3fb950;">永久经验</b>: 基于适航标准的通用规律，多型号验证的最佳实践</li>'
            '<li><b style="color:#d29922;">临时经验</b>: 单次分析的观察，待更多数据验证的假设</li>'
            '</ul>'
            '<p style="color:#8b949e;">经验按机型分文件夹存储为.md文件(中英文双版)，'
            '供人审核后标记状态。Agent下次分析时自动加载历史经验。</p>'
            '</div>'
        )
        splitter.addWidget(self.exp_detail)
        splitter.setSizes([400, 200])

        layout.addWidget(splitter)

        exp_stats = QHBoxLayout()
        self.exp_stats_label = QLabel("经验: 0 条 | 永久: 0 | 临时: 0 | 已审核: 0")
        self.exp_stats_label.setStyleSheet("color:#8b949e; font-size:12px; padding:4px;")
        exp_stats.addWidget(self.exp_stats_label)
        exp_stats.addStretch()

        self.exp_program_label = QLabel("当前型号: _global")
        self.exp_program_label.setStyleSheet(
            "color:#3fb950; font-weight:bold; font-size:12px; padding:4px;"
        )
        exp_stats.addWidget(self.exp_program_label)
        layout.addLayout(exp_stats)

        self._refresh_experience_list()
        return tab

    def _refresh_experience_list(self, filter_program: str = None):
        if not self.experience:
            return
        self.exp_tree.clear()

        program_filter = filter_program or self.exp_program_combo.currentText()
        if program_filter == "全部型号":
            entries = list(self.experience.entries.values())
        else:
            entries = self.experience.get_entries_for_program(program_filter)

        perm_parent = QTreeWidgetItem(["永久经验", "", "", "", "", "", ""])
        perm_parent.setForeground(0, QColor("#3fb950"))
        temp_parent = QTreeWidgetItem(["临时经验", "", "", "", "", "", ""])
        temp_parent.setForeground(0, QColor("#d29922"))

        from core.experience_engine import CATEGORY_LABELS
        for e in sorted(entries, key=lambda x: (x.category, -x.confidence)):
            cat_zh, _ = CATEGORY_LABELS.get(e.category, (e.category, e.category))
            status_map = {"approved": "已通过", "rejected": "已驳回", "pending": "待审核"}
            item = QTreeWidgetItem([
                e.title_zh, cat_zh,
                "永久" if e.level == "permanent" else "临时",
                f"{e.confidence:.0%}",
                status_map.get(e.review_status, e.review_status),
                str(e.usage_count),
                e.entry_id,
            ])
            if e.review_status == "approved":
                item.setForeground(4, QColor("#3fb950"))
            elif e.review_status == "rejected":
                item.setForeground(4, QColor("#f85149"))
            else:
                item.setForeground(4, QColor("#d29922"))

            if e.level == "permanent":
                perm_parent.addChild(item)
            else:
                temp_parent.addChild(item)

        perm_parent.setText(0, f"永久经验 ({perm_parent.childCount()})")
        temp_parent.setText(0, f"临时经验 ({temp_parent.childCount()})")

        self.exp_tree.addTopLevelItem(perm_parent)
        self.exp_tree.addTopLevelItem(temp_parent)
        perm_parent.setExpanded(True)
        temp_parent.setExpanded(True)

        stats = self.experience.get_statistics()
        self.exp_stats_label.setText(
            f"经验: {stats['total_entries']} 条 | "
            f"永久: {stats['permanent']} | 临时: {stats['temporary']} | "
            f"已审核: {stats['approved']} | 型号: {stats['program_count']}"
        )
        self.exp_program_label.setText(
            f"当前型号: {self.agent._current_program}"
        )

        progs_in_combo = set()
        for i in range(self.exp_program_combo.count()):
            progs_in_combo.add(self.exp_program_combo.itemText(i))
        for prog in self.experience.get_all_programs():
            if prog not in progs_in_combo:
                self.exp_program_combo.addItem(prog)

    def _on_experience_selected(self, item, column):
        eid = item.text(6)
        if not eid or not self.experience:
            return
        entry = self.experience.entries.get(eid)
        if not entry:
            return

        status_map = {"approved": "已审核通过", "rejected": "已驳回", "pending": "待审核"}
        html = (
            f'<div style="padding:12px; color:#c9d1d9; background:#0d1117;">'
            f'<h3 style="color:#58a6ff;">{entry.title_zh}</h3>'
            f'<p style="color:#8b949e;">{entry.title_en}</p>'
            f'<table style="color:#c9d1d9; font-size:13px;">'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">ID</td><td><code>{entry.entry_id}</code></td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">级别</td><td>{"永久" if entry.level == "permanent" else "临时"}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">审核</td><td>{status_map.get(entry.review_status, entry.review_status)}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">置信度</td><td>{entry.confidence:.0%}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">适用标准</td><td>{", ".join(entry.applicable_standards) or "通用"}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">适用系统</td><td>{", ".join(entry.applicable_systems) or "通用"}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">型号</td><td>{entry.aircraft_program}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">来源</td><td>{entry.source_doc}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">使用次数</td><td>{entry.usage_count}</td></tr>'
            f'<tr><td style="color:#8b949e; padding:2px 8px;">创建</td><td>{entry.created}</td></tr>'
            f'</table>'
            f'<hr style="border:1px solid #30363d;">'
            f'<h4 style="color:#3fb950;">内容 (中文)</h4>'
            f'<p>{entry.content_zh}</p>'
            f'<h4 style="color:#58a6ff;">Content (English)</h4>'
            f'<p style="color:#8b949e;">{entry.content_en or "—"}</p>'
        )
        if entry.review_comment:
            html += f'<p style="color:#d29922;">审核意见: {entry.review_comment}</p>'
        html += '</div>'
        self.exp_detail.setHtml(html)

    def _set_current_program(self):
        from PyQt5.QtWidgets import QInputDialog
        text, ok = QInputDialog.getText(
            self, "设置当前型号",
            "请输入当前工作的机型名称\n(例如: B787, A320neo, A350, C919, _global):"
        )
        if ok and text.strip():
            self.agent.set_aircraft_program(text.strip())
            self.exp_program_label.setText(f"当前型号: {text.strip()}")
            self._append_chat("system", f"已设置当前型号: {text.strip()}")

    def _promote_experience(self):
        item = self.exp_tree.currentItem()
        if not item or not self.experience:
            return
        eid = item.text(6)
        if not eid:
            return
        self.experience.promote_to_permanent(eid)
        self._refresh_experience_list()
        self._append_chat("system", f"经验 {eid} 已提升为永久经验")

    def _review_experience(self, status: str):
        item = self.exp_tree.currentItem()
        if not item or not self.experience:
            return
        eid = item.text(6)
        if not eid:
            return
        comment = ""
        if status == "rejected":
            from PyQt5.QtWidgets import QInputDialog
            comment, ok = QInputDialog.getText(self, "驳回原因", "请输入驳回原因:")
            if not ok:
                return
        self.experience.set_review_status(eid, status, comment)
        self._refresh_experience_list()
        status_zh = "通过" if status == "approved" else "驳回"
        self._append_chat("system", f"经验 {eid} 审核{status_zh}")

    def _generate_audit_report(self):
        if not self.experience:
            return
        path = self.experience.generate_audit_summary()
        self._append_chat("system",
                          f"审计汇总报告已生成:\n"
                          f"  中文版: experience/audit_summary_zh.md\n"
                          f"  英文版: experience/audit_summary_en.md")
        self.statusBar().showMessage(f"审计报告已生成: {path}", 5000)

    def _open_experience_folder(self):
        exp_dir = str(BASE_DIR / "experience")
        os.makedirs(exp_dir, exist_ok=True)
        import subprocess
        try:
            subprocess.Popen(["explorer", exp_dir])
        except Exception:
            self._append_chat("system", f"经验文件夹: {exp_dir}")

    def _create_docs_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        toolbar = QHBoxLayout()
        import_btn = QPushButton("导入文档")
        import_btn.setToolTip("导入单个文档进行分析 (支持PDF/Word/Excel/PPT/Markdown等)")
        import_btn.setCursor(Qt.PointingHandCursor)
        import_btn.clicked.connect(self._import_document)
        toolbar.addWidget(import_btn)

        import_dir_btn = QPushButton("导入目录")
        import_dir_btn.setToolTip("批量导入一个目录下的所有文档")
        import_dir_btn.setCursor(Qt.PointingHandCursor)
        import_dir_btn.clicked.connect(self._import_directory)
        toolbar.addWidget(import_dir_btn)

        reqif_btn = QPushButton("导入ReqIF")
        reqif_btn.setToolTip("导入DOORS/Polarion导出的ReqIF需求文件")
        reqif_btn.setCursor(Qt.PointingHandCursor)
        reqif_btn.clicked.connect(self._import_reqif)
        toolbar.addWidget(reqif_btn)

        archive_btn = QPushButton("自动归档")
        archive_btn.setObjectName("successBtn")
        archive_btn.setToolTip("将文档自动分类归档到对应的项目文件夹")
        archive_btn.setCursor(Qt.PointingHandCursor)
        archive_btn.clicked.connect(self._auto_archive)
        toolbar.addWidget(archive_btn)

        toolbar.addStretch()
        layout.addLayout(toolbar)

        self.doc_list = QListWidget()
        layout.addWidget(self.doc_list, stretch=1)

        self._refresh_doc_list()

        if self.doc_list.count() == 0:
            self.doc_list.addItem("暂无已导入的文档，请点击上方按钮导入文档，或拖拽文件到对话窗口。")

        return tab

    # ---- Signals ----

    def _connect_signals(self):
        self.send_btn.clicked.connect(self._send_message)
        self.stop_btn.clicked.connect(self._stop_generation)
        self.chat_input.returnPressed.connect(self._send_message)
        self.graph_tree.itemClicked.connect(self._on_node_selected)

        esc_shortcut = QShortcut(QKeySequence(Qt.Key_Escape), self)
        esc_shortcut.activated.connect(self._stop_generation)
        QShortcut(QKeySequence("Ctrl+Z"), self).activated.connect(self._undo_graph)
        QShortcut(QKeySequence("Ctrl+Y"), self).activated.connect(self._redo_graph)

    # ================================================================
    #  Chat
    # ================================================================

    def _send_message(self):
        text = self.chat_input.text().strip()
        if not text:
            return
        self.chat_input.clear()

        if text.startswith("/"):
            self._handle_quick_cmd(text)
            return

        self._abort_flag = False
        self._append_chat("user", text)
        self._set_busy(True)

        rag_ctx = self.rag.build_context(text, top_k=3, max_chars=2000)
        if rag_ctx:
            augmented = (
                f"{text}\n\n"
                f"[以下是与问题相关的文档片段，请参考后回答]\n{rag_ctx}"
            )
        else:
            augmented = text

        self._append_chat_start("assistant")

        worker = LLMWorker(self.agent, augmented, "chat")
        worker.chunk_received.connect(self._on_chat_chunk)
        worker.finished_signal.connect(self._on_chat_finished)
        worker.error_signal.connect(self._on_error)
        worker.aborted_signal.connect(self._on_generation_aborted)
        self.current_worker = worker
        worker.start()
        self._workers.append(worker)

    def _stop_generation(self):
        self._abort_flag = True
        if self.current_worker and self.current_worker.isRunning():
            self.current_worker.abort()
            self.stop_btn.setText("正在停止...")
            self.stop_btn.setEnabled(False)
        self.statusBar().showMessage("正在停止生成...", 3000)

    def _on_generation_aborted(self):
        self._on_chat_chunk("\n\n[已停止生成]")
        self.chat_display.insertHtml("</div>")
        self.current_worker = None
        self.stop_btn.setText("■ 停止生成")
        self.stop_btn.setEnabled(True)
        self._set_busy(False)
        self._refresh_graph_tree()
        self.statusBar().showMessage("已停止 — 可继续对话", 3000)

    def _handle_quick_cmd(self, cmd):
        parts = cmd.strip().split(maxsplit=1)
        base = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        dispatch = {
            "/analyze_demo":    self._analyze_demo_docs,
            "/safety_assess":   self._run_safety_assessment,
            "/trace_check":     self._check_do178c_traceability,
            "/impact_analysis": self._run_impact_analysis,
            "/find_missing":    self._find_missing_links,
            "/next_gen":        self._suggest_next_gen,
            "/trace_matrix":    self._show_traceability,
            "/auto_archive":    self._auto_archive,
            "/help":            lambda: self.chat_display.setHtml(self._welcome_html()),
            "/clear":           self._clear_chat_history,
            "/undo":            self._undo_graph,
            "/redo":            self._redo_graph,
            "/rag_status":      self._show_rag_status,
        }
        handler = dispatch.get(base)
        if handler:
            handler()
        elif base == "/rag_search" and arg:
            self._rag_search(arg)
        else:
            self._append_chat(
                "system",
                f"未知命令: {base}\n\n"
                "可用命令:\n"
                "  /analyze_demo   — 分析演示文档\n"
                "  /safety_assess  — 安全评估\n"
                "  /trace_check    — 追溯完整性检查\n"
                "  /impact_analysis — 变更影响分析\n"
                "  /find_missing   — 缺失链接发现\n"
                "  /next_gen       — 推导知识演进\n"
                "  /auto_archive   — 自动归档\n"
                "  /undo           — 撤销上一步\n"
                "  /redo           — 重做\n"
                "  /rag_status     — RAG索引状态\n"
                "  /rag_search <关键词> — RAG文档检索\n"
                "  /clear          — 清空对话\n"
                "  /help           — 显示欢迎页面"
            )

    def _show_rag_status(self):
        stats = self.rag.get_statistics()
        msg = (
            f"RAG索引状态:\n"
            f"  已索引文档: {stats['total_docs']}\n"
            f"  文本段落数: {stats['total_chunks']}\n"
            f"  词汇量: {stats['vocab_size']}\n"
        )
        if stats['doc_names']:
            msg += "\n已索引文档列表:\n"
            for d in stats['doc_names']:
                msg += f"  • {d}\n"
        self._append_chat("system", msg)

    def _rag_search(self, query):
        results = self.rag.search(query, top_k=5)
        if not results:
            self._append_chat("system", f"未找到与「{query}」相关的内容")
            return
        msg = f"RAG检索「{query}」结果 ({len(results)}条):\n\n"
        for i, r in enumerate(results, 1):
            msg += (
                f"--- 结果 {i} [相关度: {r['score']:.3f}] ---\n"
                f"来源: {r['doc_name']}\n"
                f"{r['text'][:300]}{'...' if len(r['text']) > 300 else ''}\n\n"
            )
        self._append_chat("system", msg)

    def _analyze_demo_docs(self):
        self._append_chat("system", "开始分析演示文档 (波音/空客民机设计资料)...")
        self._set_busy(True)

        from core.doc_parser import scan_directory
        demo_dirs = [
            str(BASE_DIR / "docs" / "demo_boeing"),
            str(BASE_DIR / "docs" / "demo_airbus"),
            str(BASE_DIR / "docs"),
        ]
        all_docs = []
        seen = set()
        for d in demo_dirs:
            if os.path.exists(d):
                for doc in scan_directory(d):
                    key = doc["name"]
                    if key not in seen:
                        seen.add(key)
                        all_docs.append(doc)

        if not all_docs:
            self._append_chat("system", "未找到文档，请检查 docs/ 目录")
            self._set_busy(False)
            return

        self._append_chat("system",
                          f"找到 {len(all_docs)} 个文档，开始逐个分析...")

        self.ontology.snapshot("分析演示文档")
        self._abort_flag = False

        def analyze_all():
            for i, doc in enumerate(all_docs):
                if self._abort_flag:
                    self._safe_append("system",
                        f"[已停止] 在第 {i}/{len(all_docs)} 个文档处停止")
                    self._safe_refresh()
                    return
                self._safe_append(
                    "system",
                    f"[{i+1}/{len(all_docs)}] 分析: {doc['name']} ..."
                )
                try:
                    self.rag.add_document(doc["name"], doc["content"])
                    analysis = self.agent.analyze_document(
                        doc["content"], doc["name"]
                    )
                    if self._abort_flag:
                        self._safe_append("system", "[已停止]")
                        self._safe_refresh()
                        return
                    self.agent.build_graph_from_analysis(
                        analysis, source_doc=doc["name"]
                    )
                    ent_count = len(analysis.get("entities", []))
                    rel_count = len(analysis.get("relations", []))
                    self._safe_append(
                        "system",
                        f"  ✓ 提取 {ent_count} 个实体, {rel_count} 条关系"
                    )
                    self._safe_refresh()
                except Exception as e:
                    if self._abort_flag:
                        self._safe_append("system", "[已停止]")
                        self._safe_refresh()
                        return
                    self._safe_append("system", f"  ✗ 分析失败: {e}")

            rag_stats = self.rag.get_statistics()
            exp_count = len(self.experience.entries) if self.experience else 0
            self._safe_append(
                "system",
                f"\n全部文档分析完成!\n"
                f"RAG索引: {rag_stats['total_docs']}文档, {rag_stats['total_chunks']}段落\n"
                f"经验积累: {exp_count} 条\n\n"
                f"现在可以直接用自然语言提问，系统将RAG检索+图谱知识综合回答。\n"
                f"也可切换「知识图谱」标签页查看可视化结果。"
            )
            self._safe_refresh()

        threading.Thread(target=analyze_all, daemon=True).start()

    def _find_missing_links(self):
        if not self.ontology.nodes:
            self._append_chat("system",
                              "知识图谱为空 Graph empty, 请先分析文档 analyze docs first.")
            return
        self._append_chat("system",
                          "正在推理缺失链接 Reasoning on missing links ...")
        self._set_busy(True)

        topo_results = self.ontology.suggest_missing_links()
        if topo_results:
            lines = ["图谱拓扑分析 Topology analysis:"]
            for item in topo_results[:10]:
                if isinstance(item, dict):
                    lines.append(f"  - {item.get('message', item)}")
                else:
                    lines.append(f"  - {item}")
            self._append_chat("system", "\n".join(lines))

        self._append_chat_start("assistant")
        worker = LLMWorker(self.agent, "", "reason")
        worker.finished_signal.connect(lambda result: (
            self._on_chat_chunk(result),
            self._on_chat_finished(result),
        ))
        worker.error_signal.connect(self._on_error)
        worker.aborted_signal.connect(self._on_generation_aborted)
        self.current_worker = worker
        worker.start()
        self._workers.append(worker)

    def _suggest_next_gen(self):
        if not self.ontology.nodes:
            self._append_chat("system",
                              "知识图谱为空 Graph empty, 请先分析文档 analyze docs first.")
            return

        suggestions = self.ontology.suggest_next_gen()
        if suggestions:
            lines = ["基于图谱拓扑的知识演进建议 Knowledge evolution suggestions:"]
            for s in suggestions:
                if isinstance(s, dict):
                    lines.append(
                        f"  [{s.get('priority', '?')}] "
                        f"{s.get('direction', s.get('message', str(s)))}"
                    )
                else:
                    lines.append(f"  - {s}")
            self._append_chat("assistant", "\n".join(lines))

        self._append_chat("system",
                          "正在使用AI深度推理 AI deep reasoning ...")
        self._set_busy(True)
        self._append_chat_start("assistant")

        prompt = (
            "请基于当前知识图谱的拓扑结构，从以下维度推导知识演进方向:\n"
            "Based on current ontology topology, derive knowledge evolution:\n"
            "1. 技术趋势 Technology trends\n"
            "2. 标准/规范更新 Standards evolution\n"
            "3. 跨领域融合机遇 Cross-domain opportunities\n"
            "4. 当前图谱薄弱环节 Weak areas in current graph\n"
            "5. 优先级排序 Priority ranking\n\n"
            "请给出具体条目和推理依据。"
        )
        worker = LLMWorker(self.agent, prompt, "chat")
        worker.chunk_received.connect(self._on_chat_chunk)
        worker.finished_signal.connect(self._on_chat_finished)
        worker.error_signal.connect(self._on_error)
        worker.aborted_signal.connect(self._on_generation_aborted)
        self.current_worker = worker
        worker.start()
        self._workers.append(worker)

    def _show_clusters(self):
        if not self.ontology.nodes:
            self._append_chat("system", "图谱为空 Graph empty.")
            return
        clusters = self.ontology.find_clusters()
        lines = [f"发现 {len(clusters)} 个知识簇 Found {len(clusters)} clusters:\n"]
        for i, c in enumerate(clusters[:10]):
            if isinstance(c, dict):
                lines.append(
                    f"  Cluster {i+1}: {c.get('size', '?')} 节点 nodes — "
                    f"{', '.join(str(x) for x in c.get('labels', c.get('nodes', []))[:5])}"
                )
            else:
                lines.append(f"  Cluster {i+1}: {c}")
        self._append_chat("assistant", "\n".join(lines))

    def _show_bridge_nodes(self):
        if not self.ontology.nodes:
            self._append_chat("system", "图谱为空 Graph empty.")
            return
        bridges = self.ontology.find_bridge_nodes()
        if bridges:
            lines = [f"桥接节点 Bridge nodes ({len(bridges)}):"]
            for b in bridges[:15]:
                if isinstance(b, dict):
                    lines.append(
                        f"  ◉ {b.get('label', b.get('id', '?'))} "
                        f"(betweenness: {b.get('betweenness', '?'):.4f})"
                        if isinstance(b.get('betweenness'), (int, float))
                        else f"  ◉ {b.get('label', b.get('id', '?'))}"
                    )
                else:
                    lines.append(f"  ◉ {b}")
            self._append_chat("assistant", "\n".join(lines))
        else:
            self._append_chat("system", "未发现桥接节点 No bridge nodes found.")

    # ================================================================
    #  Graph
    # ================================================================

    def _generate_graph_view(self):
        if not self.ontology.nodes:
            QMessageBox.information(
                self, "提示 Info",
                "知识图谱为空 Graph empty, 请先分析文档 analyze documents first."
            )
            return
        from core.graph_visualizer import generate_graph_html
        output_dir = BASE_DIR / "output" / "graphs"
        output_dir.mkdir(parents=True, exist_ok=True)
        output = str(output_dir / "knowledge_graph.html")
        generate_graph_html(self.ontology, output, physics=self._physics_on)

        if HAS_WEBENGINE:
            self.graph_view.setUrl(QUrl.fromLocalFile(output))
        else:
            import webbrowser
            webbrowser.open(output)
        self.statusBar().showMessage(f"知识图谱已生成: {output}", 5000)

    def _show_traceability(self):
        if not self.ontology.nodes:
            QMessageBox.information(
                self, "提示 Info",
                "知识图谱为空 Graph empty, 请先分析文档 analyze documents first."
            )
            return
        from core.graph_visualizer import generate_traceability_html
        output_dir = BASE_DIR / "output" / "reports"
        output_dir.mkdir(parents=True, exist_ok=True)
        output = str(output_dir / "traceability_matrix.html")
        generate_traceability_html(self.ontology, output)

        if HAS_WEBENGINE:
            self.trace_view.setUrl(QUrl.fromLocalFile(output))
            self.tabs.setCurrentIndex(2)
        else:
            import webbrowser
            webbrowser.open(output)
        self.statusBar().showMessage(f"追溯报告已生成: {output}", 5000)

    def _toggle_physics(self):
        self._physics_on = not self._physics_on
        cn = "开" if self._physics_on else "关"
        self.physics_toggle.setText(f"物理引擎: {cn}")

    # ================================================================
    #  适航认证工作流
    # ================================================================

    def _run_safety_assessment(self):
        if not self.ontology.nodes:
            self._append_chat("system", "知识图谱为空，请先分析文档。")
            return
        self._append_chat("system", "正在执行安全评估 (ARP4761 FHA/DAL分配)...")
        self._set_busy(True)
        self.tabs.setCurrentIndex(3)

        self._abort_flag = False

        def do_assess():
            result = self.agent.run_safety_assessment()
            if self._abort_flag:
                self._safe_append("system", "[安全评估已停止]")
                self._safe_set_busy(False)
                return
            result_text = json.dumps(result, ensure_ascii=False, indent=2)

            lines = ["◆ 安全评估结果 (ARP4761)\n"]
            fha = result.get("fha_results", [])
            if fha:
                lines.append(f"▲ FHA识别 {len(fha)} 个失效状态:")
                for item in fha:
                    if isinstance(item, dict):
                        lines.append(
                            f"  [{item.get('severity', '?')}] "
                            f"{item.get('function', '?')} → "
                            f"{item.get('failure_condition', '?')} "
                            f"(DAL {item.get('dal', '?')})"
                        )

            dal = result.get("dal_allocation", [])
            if dal:
                lines.append(f"\n◆ DAL等级分配 ({len(dal)} 项):")
                for item in dal:
                    if isinstance(item, dict):
                        lines.append(
                            f"  ◆ {item.get('item', '?')} → DAL {item.get('dal', '?')}"
                            f" ({item.get('rationale', '')})"
                        )

            so = result.get("safety_objectives", [])
            if so:
                lines.append(f"\n◆ 安全目标 ({len(so)} 项):")
                for item in so:
                    if isinstance(item, dict):
                        lines.append(
                            f"  ◆ {item.get('id', '?')}: {item.get('description', '?')}"
                        )

            display_text = "\n".join(lines)
            self._safe_append("assistant", display_text)

            html = (
                '<div style="padding:16px; color:#c9d1d9; background:#0d1117;">'
                f'<h2 style="color:#f85149;">安全评估结果</h2>'
                f'<pre style="color:#c9d1d9; font-size:13px; white-space:pre-wrap;">'
                f'{display_text}</pre>'
                f'<hr style="border:1px solid #30363d;">'
                f'<h3 style="color:#58a6ff;">原始JSON</h3>'
                f'<pre style="color:#8b949e; font-size:12px; white-space:pre-wrap;">'
                f'{result_text}</pre>'
                '</div>'
            )
            QTimer.singleShot(0, lambda: self.safety_display.setHtml(html))
            self._safe_set_busy(False)

        threading.Thread(target=do_assess, daemon=True).start()

    def _check_do178c_traceability(self):
        if not self.ontology.nodes:
            self._append_chat("system", "知识图谱为空，请先分析文档。")
            return
        self._append_chat("system", "正在检查DO-178C追溯完整性...")
        self._set_busy(True)

        self._abort_flag = False

        def do_check():
            result = self.agent.check_traceability()
            if self._abort_flag:
                self._safe_append("system", "[追溯检查已停止]")
                self._safe_set_busy(False)
                return
            result_text = json.dumps(result, ensure_ascii=False, indent=2)

            lines = ["◆ DO-178C追溯完整性检查结果\n"]

            completeness = result.get("completeness", {})
            if completeness:
                lines.append("▲ 追溯覆盖率:")
                for key, val in completeness.items():
                    pct = val * 100 if isinstance(val, (int, float)) and val <= 1 else val
                    lines.append(f"  {key}: {pct:.1f}%")

            orphans = result.get("orphans", {})
            if orphans:
                lines.append("\n▲ 孤儿节点:")
                for cat, items in orphans.items():
                    if items:
                        lines.append(f"  {cat}: {len(items)} 个")
                        for item in items[:5]:
                            lines.append(f"    - {item}")

            chains = result.get("trace_chains", [])
            if chains:
                lines.append(f"\n▲ 追溯链路 ({len(chains)} 条):")
                for c in chains[:8]:
                    if isinstance(c, dict):
                        status = c.get("status", "?")
                        gaps = c.get("gaps", [])
                        lines.append(
                            f"  [{status}] {c.get('chain_id', '?')}: "
                            f"{' → '.join(c.get('path', []))}"
                        )
                        if gaps:
                            lines.append(f"    缺失: {', '.join(gaps)}")

            display_text = "\n".join(lines)
            self._safe_append("assistant", display_text)
            self._safe_set_busy(False)

        threading.Thread(target=do_check, daemon=True).start()

    def _run_impact_analysis(self):
        if not self.ontology.nodes:
            self._append_chat("system", "知识图谱为空，请先分析文档。")
            return

        from PyQt5.QtWidgets import QInputDialog
        text, ok = QInputDialog.getText(
            self, "变更影响分析",
            "请输入发生变更的节点名称\n(例如: 座舱增压, ELAC, AOA保护, 外流活门...):"
        )
        if not ok or not text.strip():
            return

        self._append_chat("system", f"正在分析「{text}」的变更影响...")
        self._set_busy(True)

        self._abort_flag = False

        def do_impact():
            result = self.agent.analyze_change_impact(text.strip())
            if self._abort_flag:
                self._safe_append("system", "[影响分析已停止]")
                self._safe_set_busy(False)
                return
            self._safe_append("assistant", result)
            self._safe_set_busy(False)

        threading.Thread(target=do_impact, daemon=True).start()

    def _import_reqif(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "导入ReqIF文件 (DOORS/Polarion导出)",
            str(BASE_DIR / "docs"),
            "ReqIF (*.reqif *.xml);;所有文件 (*)",
        )
        if not path:
            return
        self._append_chat("system", f"正在解析ReqIF: {Path(path).name} ...")
        self._set_busy(True)

        def do_import():
            result = self.agent.import_reqif(path)
            if "error" in result:
                self._safe_append("system", f"ReqIF解析错误: {result['error']}")
            else:
                entities = result.get("entities", [])
                self._safe_append("system",
                                  f"从ReqIF导入 {len(entities)} 条需求")
                self.agent.build_graph_from_analysis(result, source_doc=path)
                self._safe_refresh()
            self._safe_set_busy(False)

        threading.Thread(target=do_import, daemon=True).start()

    # ================================================================
    #  Documents
    # ================================================================

    def _import_document(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "选择文档 Select Documents",
            str(BASE_DIR / "docs"),
            "所有文件 All (*);;PDF (*.pdf);;Word (*.docx);;"
            "文本 Text (*.txt *.md);;Excel (*.xlsx);;PPT (*.pptx)",
        )
        if not paths:
            return
        from core.doc_parser import parse_document
        for path in paths:
            doc = parse_document(path)
            if doc:
                self._append_chat(
                    "system",
                    f"已导入 Imported: {doc['name']} "
                    f"({doc.get('size_kb', '?')}KB)"
                )
                self._analyze_single_doc(doc)
            else:
                self._append_chat("system",
                                  f"无法解析 Cannot parse: {Path(path).name}")
        self._refresh_doc_list()

    def _import_directory(self):
        dir_path = QFileDialog.getExistingDirectory(
            self, "选择目录 Select Directory", str(BASE_DIR / "docs")
        )
        if not dir_path:
            return
        from core.doc_parser import scan_directory
        docs = scan_directory(dir_path)
        self._append_chat(
            "system",
            f"从 {dir_path} 找到 Found {len(docs)} 个文档 documents"
        )
        for doc in docs:
            self._append_chat("system",
                              f"  - {doc['name']} ({doc.get('size_kb', '?')}KB)")
        self._refresh_doc_list()

    def _analyze_single_doc(self, doc):
        if not doc or "[解析失败" in doc.get("content", ""):
            self._append_chat("system",
                              f"文档解析失败 Parse failed: {doc.get('name', '?')}")
            return
        self._append_chat("system",
                          f"正在分析 Analyzing: {doc['name']} ...")
        self._set_busy(True)

        worker = DocAnalyzeWorker(self.agent, doc)
        worker.progress.connect(
            lambda msg: self._append_chat("system", msg)
        )
        worker.finished_signal.connect(lambda result: (
            self._on_analysis_complete(result),
            self._set_busy(False),
        ))
        worker.error_signal.connect(self._on_error)
        worker.aborted_signal.connect(lambda: (
            self._append_chat("system", "[文档分析已停止]"),
            self._set_busy(False),
        ))
        self.current_worker = worker
        worker.start()
        self._workers.append(worker)

    def _on_analysis_complete(self, result):
        ent_count = len(result.get("entities", []))
        rel_count = len(result.get("relations", []))
        self._append_chat(
            "system",
            f"分析完成: {ent_count} 个实体, {rel_count} 条关系 — 图谱已更新"
        )
        self._refresh_graph_tree()
        self._update_status_backend()
        if self.experience:
            self._refresh_experience_list()

    # ================================================================
    #  Archive
    # ================================================================

    def _auto_archive(self):
        self._append_chat("system",
                          "开始自动归档 Starting auto-archive ...")
        from core.archiver import DocumentArchiver
        docs_dir = str(BASE_DIR / "docs")
        archive_dir = str(BASE_DIR / "docs" / "archived")
        archiver = DocumentArchiver(docs_dir, archive_dir, self.agent)

        def do_archive():
            results = archiver.auto_archive_directory(
                callback=lambda r: self._safe_append(
                    "system",
                    f"  归档 Archived: {Path(r['original']).name} → "
                    f"{r.get('classification', {}).get('category', 'other')}"
                )
            )
            self._safe_append(
                "system",
                f"\n归档完成 Archive done: {len(results)} 个文档 documents"
            )
            self._safe_set_busy(False)

        self._set_busy(True)
        threading.Thread(target=do_archive, daemon=True).start()

    # ================================================================
    #  Export
    # ================================================================

    def _export_graph(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "导出知识图谱 Export Graph",
            "knowledge_graph.json", "JSON (*.json)"
        )
        if path:
            data = self.ontology.to_dict()
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.statusBar().showMessage(f"已导出: {path}", 5000)

    def _export_rdf(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "导出RDF Export RDF",
            "ontology.ttl", "Turtle (*.ttl)"
        )
        if path:
            self.ontology.export_rdf_turtle(path)
            self.statusBar().showMessage(f"已导出RDF: {path}", 5000)

    # ================================================================
    #  Graph Tree Browser
    # ================================================================

    def _refresh_graph_tree(self, _index=None):
        self.graph_tree.clear()
        view_mode = self.tree_view_combo.currentIndex() if hasattr(self, 'tree_view_combo') else 0

        if view_mode == 1:
            self._build_tree_by_doc()
        elif view_mode == 2:
            self._build_tree_by_ata()
        elif view_mode == 3:
            self._build_tree_flat()
        else:
            self._build_tree_by_type()

        stats = self.ontology.get_statistics()
        n_nodes = stats.get("total_nodes", 0)
        n_edges = stats.get("total_edges", 0)
        avg_str = stats.get("avg_strength", 0)
        components = stats.get("connected_components", 0)
        undo_info = f" | 撤销: {len(self.ontology._undo_stack)}" if self.ontology._undo_stack else ""
        self.stats_label.setText(
            f"节点: {n_nodes} | 边: {n_edges}\n"
            f"平均关联强度: {avg_str:.3f}\n"
            f"连通分量: {components}{undo_info}"
        )
        if hasattr(self, "undo_btn"):
            self.undo_btn.setEnabled(self.ontology.can_undo)
            self.redo_btn.setEnabled(self.ontology.can_redo)

    def _build_tree_by_type(self):
        type_groups = {}
        for n in self.ontology.nodes.values():
            t = n.get("type", "unknown")
            type_groups.setdefault(t, []).append(n)
        for t, nodes in sorted(type_groups.items()):
            type_info = TYPE_HIERARCHY.get(t, {})
            label = type_info.get("label", t)
            icon = type_info.get("icon", "●")
            color = type_info.get("base_color", "#8b949e")
            parent = QTreeWidgetItem([f"{icon} {label} ({len(nodes)})", t, ""])
            parent.setForeground(0, QColor(color))
            parent.setForeground(1, QColor("#8b949e"))
            for n in nodes:
                child = QTreeWidgetItem([n.get("label", "?"), label, n.get("id", "")])
                child.setForeground(1, QColor("#8b949e"))
                parent.addChild(child)
            self.graph_tree.addTopLevelItem(parent)
            parent.setExpanded(len(nodes) <= 20)

    def _build_tree_by_doc(self):
        doc_groups = self.ontology.get_source_docs()
        for doc_name, node_ids in sorted(doc_groups.items()):
            short = Path(doc_name).stem if doc_name != "未分类" else "未分类"
            parent = QTreeWidgetItem([f"📄 {short} ({len(node_ids)})", "文档", ""])
            parent.setForeground(0, QColor("#58a6ff"))
            parent.setForeground(1, QColor("#8b949e"))
            for nid in node_ids:
                node = self.ontology.nodes.get(nid, {})
                t = node.get("type", "")
                info = TYPE_HIERARCHY.get(t, {})
                child = QTreeWidgetItem([
                    node.get("label", "?"),
                    info.get("label", t),
                    nid,
                ])
                child.setForeground(0, QColor(info.get("base_color", "#c9d1d9")))
                child.setForeground(1, QColor("#8b949e"))
                parent.addChild(child)
            self.graph_tree.addTopLevelItem(parent)
            parent.setExpanded(len(node_ids) <= 15)

    def _build_tree_by_ata(self):
        from core.ontology_engine import ATA_STRUCTURE
        ata_map = self.ontology.get_ata_mapping()
        if not ata_map:
            empty = QTreeWidgetItem(["暂无ATA标注的节点", "", ""])
            empty.setForeground(0, QColor("#d29922"))
            self.graph_tree.addTopLevelItem(empty)
            return
        for ata_num in sorted(ata_map.keys()):
            items = ata_map[ata_num]
            info = ATA_STRUCTURE.get(ata_num, {})
            parent = QTreeWidgetItem([
                f"ATA-{ata_num} {info.get('name', '')} ({len(items)})",
                info.get("zone", ""),
                "",
            ])
            parent.setForeground(0, QColor("#3fb950"))
            parent.setForeground(1, QColor("#d29922"))
            parent.setToolTip(0, f"ATA {ata_num}: {info.get('en', '')} — {info.get('zone', '')}")
            for item in items:
                child = QTreeWidgetItem([
                    item["label"], item["type"], item["node_id"],
                ])
                child.setToolTip(0, f"结构位置: {item['zone']}")
                parent.addChild(child)
            self.graph_tree.addTopLevelItem(parent)
            parent.setExpanded(True)

        unmapped = [n for n in self.ontology.nodes.values()
                    if not n.get("properties", {}).get("ata_chapter")]
        if unmapped:
            parent = QTreeWidgetItem([f"未标注ATA ({len(unmapped)})", "", ""])
            parent.setForeground(0, QColor("#8b949e"))
            for n in unmapped[:50]:
                child = QTreeWidgetItem([n.get("label", "?"), n.get("type", ""), n.get("id", "")])
                parent.addChild(child)
            self.graph_tree.addTopLevelItem(parent)

    def _build_tree_flat(self):
        for nid, n in sorted(self.ontology.nodes.items(), key=lambda x: x[1].get("label", "")):
            t = n.get("type", "")
            info = TYPE_HIERARCHY.get(t, {})
            item = QTreeWidgetItem([
                n.get("label", "?"),
                info.get("label", t),
                nid,
            ])
            item.setForeground(0, QColor(info.get("base_color", "#c9d1d9")))
            item.setForeground(1, QColor("#8b949e"))
            self.graph_tree.addTopLevelItem(item)

    def _search_nodes(self):
        keyword = self.search_input.text().strip()
        if not keyword:
            self._refresh_graph_tree()
            return
        results = self.ontology.search_nodes(keyword)
        self.graph_tree.clear()
        if results:
            parent = QTreeWidgetItem(
                [f"搜索「{keyword}」({len(results)}个结果)", "", ""]
            )
            parent.setForeground(0, QColor("#58a6ff"))
            for n in results:
                child = QTreeWidgetItem(
                    [n.get("label", "?"), n.get("type", "?"), n.get("id", "")]
                )
                parent.addChild(child)
            self.graph_tree.addTopLevelItem(parent)
            parent.setExpanded(True)
            self.statusBar().showMessage(f"找到 {len(results)} 个匹配节点", 3000)
        else:
            empty = QTreeWidgetItem([f"未找到「{keyword}」相关节点", "", ""])
            empty.setForeground(0, QColor("#d29922"))
            self.graph_tree.addTopLevelItem(empty)
            self.statusBar().showMessage(f"未找到「{keyword}」相关节点", 3000)

    def _on_node_selected(self, item, column):
        nid = item.text(2)
        if not nid:
            return
        node = self.ontology.nodes.get(nid)
        if not node:
            return

        neighbors = self.ontology.get_neighbors(nid)
        type_info = TYPE_HIERARCHY.get(node.get("type", ""), {})
        icon = type_info.get("icon", "●")

        info = (
            f"{icon} {node.get('label', '?')}\n"
            f"类型 Type: {node.get('type', '?')} | ID: {nid}\n"
        )
        props = node.get("properties", {})
        if props:
            for k, v in props.items():
                info += f"  {k}: {v}\n"
        if neighbors:
            info += f"\n关联节点 Neighbors ({len(neighbors)}):\n"
            for nb in neighbors:
                direction = "→" if nb.get("direction") == "out" else "←"
                rel = nb.get("relation", "")
                strength = nb.get("strength", 0)
                from core.ontology_engine import strength_to_color
                color_hex, color_name, _ = strength_to_color(strength)
                info += (
                    f"  {direction} [{rel}] "
                    f"{nb.get('label', nb.get('id', '?'))} "
                    f"({color_name} {strength:.2f})\n"
                )
        self._append_chat("system", info)

    def _clear_graph(self):
        reply = QMessageBox.question(
            self, "确认 Confirm",
            "确定清空知识图谱？\n（可通过「撤销」恢复）",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self.ontology.snapshot("清空图谱")
            self.ontology.nodes.clear()
            self.ontology.edges.clear()
            self.ontology.nx_graph.clear()
            self.ontology.save()
            self._refresh_graph_tree()
            self._append_chat("system", "知识图谱已清空 (可撤销恢复)")

    def _undo_graph(self):
        if not self.ontology.can_undo:
            self.statusBar().showMessage("没有可撤销的操作", 3000)
            return
        label = self.ontology.undo()
        self.ontology.save()
        self._refresh_graph_tree()
        self._append_chat("system", f"已撤销: {label or '上一步操作'}")
        self.statusBar().showMessage(f"撤销: {label}", 3000)

    def _redo_graph(self):
        if not self.ontology.can_redo:
            self.statusBar().showMessage("没有可重做的操作", 3000)
            return
        label = self.ontology.redo()
        self.ontology.save()
        self._refresh_graph_tree()
        self._append_chat("system", f"已重做: {label or '操作'}")
        self.statusBar().showMessage(f"重做: {label}", 3000)

    def _refresh_doc_list(self):
        self.doc_list.clear()
        docs_dir = BASE_DIR / "docs"
        if docs_dir.exists():
            for root, dirs, files in os.walk(str(docs_dir)):
                dirs[:] = [d for d in dirs if d != "archived"]
                for f in sorted(files):
                    rel = os.path.relpath(os.path.join(root, f), str(docs_dir))
                    self.doc_list.addItem(f"  {rel}")

    # ================================================================
    #  Chat display helpers
    # ================================================================

    def _welcome_html(self):
        spectrum_html = ""
        for threshold, color, cn_name, desc in STRENGTH_SPECTRUM:
            spectrum_html += (
                f'<span style="display:inline-block; background:{color}; '
                f'color:#fff; padding:3px 10px; border-radius:4px; margin:2px; '
                f'font-size:12px; font-weight:bold;">'
                f'{cn_name} {desc}</span> '
            )

        node_count = len(self.ontology.nodes) if self.ontology else 0
        edge_count = len(self.ontology.edges) if self.ontology else 0
        status_color = "#3fb950" if node_count > 0 else "#d29922"
        status_text = (f"已加载 {node_count} 个实体, {edge_count} 条关系"
                       if node_count > 0 else "知识库为空，请先分析文档")

        return f"""
        <div style="padding:28px; font-family:'Microsoft YaHei','Segoe UI',sans-serif;
                    color:#c9d1d9; background:#0d1117;">

        <h2 style="color:#58a6ff; margin-bottom:4px; font-size:22px;">
            民机适航知识库 Agent
        </h2>
        <p style="color:#8b949e; font-size:13px; margin-top:4px; line-height:1.6;">
            面向空客/波音民机设计团队 · ARP4754A/DO-178C/ARP4761 ·
            本地离线运行 (Ollama / 昇腾910B)
        </p>

        <div style="background:#161b22; border:1px solid #30363d; border-radius:10px;
                    padding:12px 16px; margin:12px 0; display:inline-block;">
            <span style="color:{status_color}; font-weight:bold;">●</span>
            <span style="color:{status_color};">{status_text}</span>
        </div>

        <hr style="border:1px solid #21262d; margin:16px 0;">

        <h3 style="color:#58a6ff; margin-bottom:12px;">三步快速上手</h3>
        <div style="display:flex; gap:12px; flex-wrap:wrap; margin-bottom:20px;">
            <div style="background:#0d2818; border:1px solid #238636; border-radius:10px;
                        padding:14px 18px; flex:1; min-width:180px;">
                <span style="color:#3fb950; font-size:24px; font-weight:bold;">1</span>
                <p style="color:#3fb950; font-weight:bold; margin:6px 0 4px;">分析文档</p>
                <p style="color:#8b949e; font-size:12px; margin:0;">
                    点击上方「分析演示文档」或拖拽文件到此窗口</p>
            </div>
            <div style="background:#0a1929; border:1px solid #1a3a5c; border-radius:10px;
                        padding:14px 18px; flex:1; min-width:180px;">
                <span style="color:#58a6ff; font-size:24px; font-weight:bold;">2</span>
                <p style="color:#58a6ff; font-weight:bold; margin:6px 0 4px;">查看图谱</p>
                <p style="color:#8b949e; font-size:12px; margin:0;">
                    切换到「知识图谱」标签页生成可视化</p>
            </div>
            <div style="background:#1c0a0a; border:1px solid #3d1e1e; border-radius:10px;
                        padding:14px 18px; flex:1; min-width:180px;">
                <span style="color:#f85149; font-size:24px; font-weight:bold;">3</span>
                <p style="color:#f85149; font-weight:bold; margin:6px 0 4px;">安全评估</p>
                <p style="color:#8b949e; font-size:12px; margin:0;">
                    执行FHA/DAL分配、追溯检查、变更影响分析</p>
            </div>
        </div>

        <h3 style="color:#58a6ff; margin-bottom:8px;">对话快捷指令</h3>
        <table style="color:#c9d1d9; border-collapse:collapse; width:100%; font-size:13px;">
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#79c0ff; font-family:monospace;">/analyze_demo</td>
                <td style="padding:5px 8px;">分析内置波音/空客演示文档</td>
            </tr>
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#79c0ff; font-family:monospace;">/safety_assess</td>
                <td style="padding:5px 8px;">ARP4761安全评估 + DAL分配</td>
            </tr>
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#79c0ff; font-family:monospace;">/trace_check</td>
                <td style="padding:5px 8px;">DO-178C追溯完整性检查</td>
            </tr>
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#79c0ff; font-family:monospace;">/impact_analysis</td>
                <td style="padding:5px 8px;">需求/设计变更影响分析</td>
            </tr>
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#79c0ff; font-family:monospace;">/find_missing</td>
                <td style="padding:5px 8px;">发现被忽视的潜在关联</td>
            </tr>
            <tr>
                <td style="padding:5px 8px; color:#79c0ff; font-family:monospace;">/auto_archive</td>
                <td style="padding:5px 8px;">自动归档整理文档</td>
            </tr>
        </table>

        <h3 style="color:#58a6ff; margin-top:16px; margin-bottom:8px;">关联强度色谱</h3>
        <p>{spectrum_html}</p>

        <h3 style="color:#58a6ff; margin-bottom:8px;">适航认证能力</h3>
        <table style="color:#c9d1d9; border-collapse:collapse; width:100%; font-size:13px;">
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#f85149; width:80px;"><b>安全评估</b></td>
                <td style="padding:5px 8px;">ARP4761 FHA/PSSA/SSA/CCA, DAL A~E, 故障树</td>
            </tr>
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#3fb950;"><b>需求追溯</b></td>
                <td style="padding:5px 8px;">飞机→系统→HLR→LLR→代码→测试 完整追溯链</td>
            </tr>
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#58a6ff;"><b>MBSE</b></td>
                <td style="padding:5px 8px;">Capella/Arcadia · ReqIF (DOORS/Polarion)</td>
            </tr>
            <tr style="border-bottom:1px solid #21262d;">
                <td style="padding:5px 8px; color:#d29922;"><b>变更管理</b></td>
                <td style="padding:5px 8px;">上下游影响 · 安全/认证合规 · 构型追溯</td>
            </tr>
            <tr>
                <td style="padding:5px 8px; color:#a371f7;"><b>推理</b></td>
                <td style="padding:5px 8px;">缺失链接 · 隐含需求 · 风险 · 知识演进</td>
            </tr>
        </table>

        <div style="margin-top:16px; padding:10px 14px; background:#161b22;
                    border:1px solid #21262d; border-radius:8px;">
            <span style="color:#484f58; font-size:11px;">
                支持格式: PDF · Word · Excel · PowerPoint · Markdown · HTML · XML · ReqIF · JSON · YAML · CSV · LaTeX
                &nbsp;|&nbsp; 拖拽文件到窗口即可分析 &nbsp;|&nbsp; Esc键可随时停止生成
            </span>
        </div>
        </div>
        """

    def _append_chat(self, role, text):
        cursor = self.chat_display.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.chat_display.setTextCursor(cursor)

        ts = datetime.now().strftime("%H:%M:%S")
        text_escaped = (text.replace("&", "&amp;")
                            .replace("<", "&lt;")
                            .replace(">", "&gt;"))
        text_html = text_escaped.replace("\n", "<br>")

        if role == "user":
            html = (
                f'<div style="margin:6px 0; padding:10px 14px; '
                f'background:#161b22; border-radius:8px; '
                f'border-left:3px solid #58a6ff;">'
                f'<span style="color:#58a6ff;font-weight:bold;">用户</span> '
                f'<span style="color:#484f58;font-size:11px;">{ts}</span><br>'
                f'<span style="color:#c9d1d9;">{text_html}</span></div>'
            )
        elif role == "assistant":
            html = (
                f'<div style="margin:6px 0; padding:10px 14px; '
                f'background:#0d2818; border-radius:8px; '
                f'border-left:3px solid #3fb950;">'
                f'<span style="color:#3fb950;font-weight:bold;">AI助手</span> '
                f'<span style="color:#484f58;font-size:11px;">{ts}</span><br>'
                f'<span style="color:#c9d1d9;">{text_html}</span></div>'
            )
        else:
            html = (
                f'<div style="margin:4px 0; padding:8px 12px; '
                f'background:#1c1608; border-radius:8px; '
                f'border-left:3px solid #d29922; font-size:13px;">'
                f'<span style="color:#d29922;">系统</span> '
                f'<span style="color:#484f58;font-size:11px;">{ts}</span><br>'
                f'<span style="color:#c9d1d9;">{text_html}</span></div>'
            )
        self.chat_display.insertHtml(html)
        sb = self.chat_display.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _append_chat_start(self, role):
        cursor = self.chat_display.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.chat_display.setTextCursor(cursor)
        ts = datetime.now().strftime("%H:%M:%S")
        html = (
            f'<div style="margin:6px 0; padding:10px 14px; '
            f'background:#0d2818; border-radius:8px; '
            f'border-left:3px solid #3fb950;">'
            f'<span style="color:#3fb950;font-weight:bold;">AI助手</span> '
            f'<span style="color:#484f58;font-size:11px;">{ts}</span><br>'
        )
        self.chat_display.insertHtml(html)

    def _on_chat_chunk(self, chunk):
        cursor = self.chat_display.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.chat_display.setTextCursor(cursor)
        self.chat_display.insertPlainText(chunk)
        sb = self.chat_display.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _on_chat_finished(self, full_text):
        cursor = self.chat_display.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.chat_display.setTextCursor(cursor)
        self.chat_display.insertHtml("</div>")
        self.current_worker = None
        self._set_busy(False)
        self._refresh_graph_tree()
        self._update_status_backend()

    def _on_error(self, error_text):
        if "Connection refused" in error_text or "连接" in error_text:
            msg = (f"连接失败: {error_text}\n\n"
                   "请检查:\n"
                   "  1. Ollama是否已启动 (终端运行 ollama serve)\n"
                   "  2. 模型是否已下载 (ollama pull qwen2.5:7b-instruct)\n"
                   "  3. 端口11434是否被占用")
        elif "timeout" in error_text.lower():
            msg = (f"请求超时: {error_text}\n\n"
                   "可能的原因:\n"
                   "  1. 模型较大，推理需要更多时间\n"
                   "  2. 系统资源不足")
        else:
            msg = f"错误: {error_text}"
        self._append_chat("system", msg)
        self.current_worker = None
        self._set_busy(False)

    # ================================================================
    #  Busy state
    # ================================================================

    def _set_busy(self, busy):
        self.send_btn.setEnabled(not busy)
        self.send_btn.setVisible(not busy)
        self.stop_btn.setVisible(busy)
        self.chat_input.setEnabled(not busy)
        self.progress_bar.setVisible(busy)
        if busy:
            self.progress_bar.setRange(0, 0)
            self.chat_input.setPlaceholderText("AI正在思考中... 按 Esc 或点击「停止」终止")
        else:
            self.progress_bar.setRange(0, 1)
            self.chat_input.setPlaceholderText(
                "请输入问题，或拖拽文档到此窗口分析... (Enter 发送, Esc 停止)"
            )

    # ================================================================
    #  Thread-safe UI updates via QTimer.singleShot
    # ================================================================

    def _safe_append(self, role, text):
        QTimer.singleShot(0, lambda: self._append_chat(role, text))

    def _safe_append_chunk(self, chunk):
        QTimer.singleShot(0, lambda: self._on_chat_chunk(chunk))

    def _safe_refresh(self):
        def _do_refresh():
            self._refresh_graph_tree()
            self._set_busy(False)
            if self.experience:
                self._refresh_experience_list()
            if hasattr(self, "tabs") and self.tabs.currentIndex() == 1:
                if self.ontology.nodes:
                    self._generate_graph_view()
        QTimer.singleShot(0, _do_refresh)

    def _safe_set_busy(self, busy):
        QTimer.singleShot(0, lambda: self._set_busy(busy))

    # ================================================================
    #  About
    # ================================================================

    def _show_about(self):
        QMessageBox.about(
            self, "关于",
            '<div style="color:#c9d1d9;">'
            "<h3>民机适航知识库Agent v4.0</h3>"
            "<p>面向空客/波音民机设计团队的适航知识图谱系统</p>"
            "<hr>"
            "<p><b>核心能力:</b></p>"
            "<ul>"
            "<li>ARP4761安全评估 (FHA/PSSA/SSA/CCA/DAL分配)</li>"
            "<li>DO-178C追溯完整性检查 (需求→代码→测试)</li>"
            "<li>ARP4754A V模型全生命周期追溯</li>"
            "<li>变更影响分析 (上下游/横向/安全/认证)</li>"
            "<li>Capella/Arcadia MBSE架构支持</li>"
            "<li>DOORS/Polarion ReqIF需求导入</li>"
            "<li>IOF/BFO三层本体架构</li>"
            "<li>赤橙黄绿青蓝紫关联强度色谱</li>"
            "<li>Ollama/vLLM-Ascend(昇腾910B)双后端</li>"
            "<li>知识推理: 缺失链接发现/风险识别/知识演进</li>"
            "<li>自动文档归档 (民机项目文档体系)</li>"
            "<li><b>适航标准库: 中(CAAC)/美(FAA)/欧(EASA)三方标准体系</b></li>"
            "</ul>"
            '<p style="color:#8b949e;">IOF/BFO Ontology · '
            "Hedi Karray / UTTOP-Toulouse INP<br>"
            "ARP4754A · DO-178C · DO-254 · ARP4761<br>"
            "标准库: FAA/EASA/CAAC 交叉引用体系</p>"
            "</div>"
        )

    # ================================================================
    #  标准库 Tab
    # ================================================================

    def _create_standards_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 8, 8, 8)

        toolbar = QHBoxLayout()

        self.std_search_input = QLineEdit()
        self.std_search_input.setPlaceholderText("搜索标准 (如: DO-178C, 安全评估, EWIS ...)")
        self.std_search_input.returnPressed.connect(self._do_search_standards)
        toolbar.addWidget(self.std_search_input, 3)

        btn_search = QPushButton("搜索")
        btn_search.setStyleSheet("background:#1f6feb; font-weight:bold;")
        btn_search.clicked.connect(self._do_search_standards)
        toolbar.addWidget(btn_search)

        self.std_authority_combo = QComboBox()
        self.std_authority_combo.addItems(["全部当局", "FAA", "EASA", "CAAC"])
        self.std_authority_combo.currentIndexChanged.connect(self._filter_standards_by_authority)
        toolbar.addWidget(self.std_authority_combo)

        self.std_category_combo = QComboBox()
        self.std_category_combo.addItem("全部类别", "")
        from core.standards_library import CATEGORY_LABELS
        for cat_key, (cat_zh, _) in CATEGORY_LABELS.items():
            self.std_category_combo.addItem(cat_zh, cat_key)
        self.std_category_combo.currentIndexChanged.connect(self._filter_standards_by_category)
        toolbar.addWidget(self.std_category_combo)

        layout.addLayout(toolbar)

        stats_bar = QHBoxLayout()
        self.std_stats_label = QLabel()
        self.std_stats_label.setStyleSheet("color: #8b949e; font-size: 12px;")
        stats_bar.addWidget(self.std_stats_label)
        stats_bar.addStretch()
        layout.addLayout(stats_bar)

        splitter = QSplitter(Qt.Vertical)

        self.std_tree = QTreeWidget()
        self.std_tree.setHeaderLabels(["标准编号", "名称", "类别", "当局"])
        self.std_tree.setAlternatingRowColors(True)
        self.std_tree.setColumnWidth(0, 160)
        self.std_tree.setColumnWidth(1, 320)
        self.std_tree.setColumnWidth(2, 100)
        self.std_tree.setColumnWidth(3, 60)
        self.std_tree.currentItemChanged.connect(self._on_standard_selected)
        splitter.addWidget(self.std_tree)

        self.std_detail = QTextBrowser()
        self.std_detail.setOpenExternalLinks(True)
        splitter.addWidget(self.std_detail)

        splitter.setSizes([320, 360])
        layout.addWidget(splitter)

        self._populate_standards_tree()
        return tab

    def _populate_standards_tree(self, authority_filter="", category_filter=""):
        self.std_tree.clear()
        if not self.standards:
            return

        authority_groups = {}
        for authority, auth_data in self.standards.db.items():
            if authority_filter and authority != authority_filter:
                continue
            for std_key, std in auth_data.get("standards", {}).items():
                cat = std.get("category", "")
                if category_filter and cat != category_filter:
                    continue
                if authority not in authority_groups:
                    authority_groups[authority] = []
                authority_groups[authority].append((std_key, std))

        total = 0
        for authority in ["FAA", "EASA", "CAAC"]:
            if authority not in authority_groups:
                continue
            items = authority_groups[authority]
            auth_zh = self.standards.db[authority]["authority_zh"]
            parent = QTreeWidgetItem(self.std_tree,
                                     [f"■ {auth_zh} ({len(items)}项)", "", "", authority])
            parent.setForeground(0, QColor("#58a6ff"))
            parent.setExpanded(True)

            from core.standards_library import CATEGORY_LABELS
            for std_key, std in items:
                std_id = std.get("id", std_key)
                title_zh = std.get("title_zh", "")
                cat_zh, _ = CATEGORY_LABELS.get(std.get("category", ""), ("", ""))
                child = QTreeWidgetItem(parent,
                                        [std_id, title_zh, cat_zh, authority])
                child.setData(0, Qt.UserRole, std_key)

                cat = std.get("category", "")
                color_map = {
                    "airworthiness_regulation": "#f85149",
                    "software_certification": "#58a6ff",
                    "hardware_certification": "#d2a8ff",
                    "system_development": "#3fb950",
                    "safety_assessment": "#f0883e",
                    "environmental_test": "#56d364",
                    "avionics_standard": "#79c0ff",
                    "cybersecurity": "#ff7b72",
                }
                child.setForeground(2, QColor(color_map.get(cat, "#8b949e")))
                total += 1

        stats = self.standards.get_statistics() if self.standards else {}
        self.std_stats_label.setText(
            f"标准总数: {stats.get('total_standards', 0)} | "
            f"FAA: {stats.get('by_authority', {}).get('FAA', 0)} | "
            f"EASA: {stats.get('by_authority', {}).get('EASA', 0)} | "
            f"CAAC: {stats.get('by_authority', {}).get('CAAC', 0)} | "
            f"当前显示: {total}项"
        )

    def _on_standard_selected(self, current, previous):
        if not current or not self.standards:
            return
        std_key = current.data(0, Qt.UserRole)
        if not std_key:
            return
        std = self.standards.get_standard(std_key)
        if not std:
            return

        from core.standards_library import CATEGORY_LABELS
        cat_zh, cat_en = CATEGORY_LABELS.get(std.get("category", ""), ("", ""))

        html = f'''
        <div style="font-family: Microsoft YaHei, sans-serif; color: #c9d1d9;">
        <h2 style="color:#58a6ff; margin-bottom:4px;">{std.get("id", "")}</h2>
        <h3 style="color:#c9d1d9; margin-top:0;">{std.get("title_zh", "")}</h3>
        '''
        if std.get("title_en"):
            html += f'<p style="color:#8b949e; font-style:italic;">{std["title_en"]}</p>'

        html += f'''
        <table style="border-collapse:collapse; width:100%; margin:10px 0;">
        <tr style="border-bottom:1px solid #30363d;">
            <td style="color:#8b949e; padding:4px 8px; width:100px;">适航当局</td>
            <td style="padding:4px 8px;">{std.get("authority_zh", "")} ({std.get("authority", "")})</td>
        </tr>
        <tr style="border-bottom:1px solid #30363d;">
            <td style="color:#8b949e; padding:4px 8px;">类别</td>
            <td style="padding:4px 8px;">{cat_zh} ({cat_en})</td>
        </tr>
        '''
        if std.get("publisher"):
            html += f'''
            <tr style="border-bottom:1px solid #30363d;">
                <td style="color:#8b949e; padding:4px 8px;">发布机构</td>
                <td style="padding:4px 8px;">{std["publisher"]}</td>
            </tr>'''
        if std.get("year"):
            html += f'''
            <tr style="border-bottom:1px solid #30363d;">
                <td style="color:#8b949e; padding:4px 8px;">年份</td>
                <td style="padding:4px 8px;">{std["year"]}</td>
            </tr>'''
        html += '</table>'

        if std.get("scope_zh"):
            html += f'''
            <div style="background:#161b22; border:1px solid #30363d;
                        border-radius:6px; padding:10px; margin:8px 0;">
            <b style="color:#3fb950;">适用范围</b><br>
            <span>{std["scope_zh"]}</span>
            </div>'''

        sections = std.get("key_sections", {})
        if sections:
            html += '<h3 style="color:#f0883e; margin-top:16px;">关键条款</h3>'
            for sec_key, sec in sections.items():
                sec_title = sec.get("title_zh", sec_key)
                html += f'''
                <div style="background:#0d1117; border-left:3px solid #f0883e;
                            padding:8px 12px; margin:6px 0;">
                <b style="color:#f0883e;">{sec_title}</b>'''
                if sec.get("title_en"):
                    html += f'<br><i style="color:#484f58;">{sec["title_en"]}</i>'
                if sec.get("content_zh"):
                    html += f'<br><span style="color:#c9d1d9;">{sec["content_zh"]}</span>'
                if sec.get("dal_relevance"):
                    html += f'<br><span style="color:#d2a8ff;">DAL: {sec["dal_relevance"]}</span>'
                html += '</div>'

        xrefs = self.standards.get_cross_references(std_key)
        if xrefs:
            html += '<h3 style="color:#79c0ff; margin-top:16px;">交叉引用(等效标准)</h3><ul>'
            for xr in xrefs:
                html += f'<li style="color:#79c0ff;">{xr["authority"]}: {xr["id"]} — {xr["title_zh"]}</li>'
            html += '</ul>'

        if std.get("supplements"):
            html += '<h3 style="color:#d2a8ff; margin-top:16px;">补充文件</h3><ul>'
            for s in std["supplements"]:
                html += f'<li>{s}</li>'
            html += '</ul>'

        if std.get("note_zh"):
            html += f'''
            <div style="background:#161b22; border:1px solid #484f58;
                        border-radius:6px; padding:8px; margin-top:12px;">
            <b style="color:#8b949e;">备注:</b> {std["note_zh"]}
            </div>'''

        html += '</div>'
        self.std_detail.setHtml(html)

    def _do_search_standards(self):
        keyword = self.std_search_input.text().strip()
        if not keyword or not self.standards:
            self._populate_standards_tree()
            return

        results = self.standards.search(keyword)
        self.std_tree.clear()
        if not results:
            self.std_stats_label.setText(f"未找到与 [{keyword}] 相关的标准")
            return

        from core.standards_library import CATEGORY_LABELS
        for r in results:
            cat_zh, _ = CATEGORY_LABELS.get(r.get("category", ""), ("", ""))
            item = QTreeWidgetItem(self.std_tree,
                                   [r["id"], r["title_zh"], cat_zh, r["authority"]])
            item.setData(0, Qt.UserRole, r["standard_key"])
            item.setForeground(3, QColor("#58a6ff"))

        self.std_stats_label.setText(f"搜索 [{keyword}]: 找到 {len(results)} 项标准")

        if results:
            self.std_tree.setCurrentItem(self.std_tree.topLevelItem(0))

    def _filter_standards_by_authority(self):
        auth = self.std_authority_combo.currentText()
        auth_filter = "" if auth == "全部当局" else auth
        cat_filter = self.std_category_combo.currentData() or ""
        self._populate_standards_tree(auth_filter, cat_filter)

    def _filter_standards_by_category(self):
        auth = self.std_authority_combo.currentText()
        auth_filter = "" if auth == "全部当局" else auth
        cat_filter = self.std_category_combo.currentData() or ""
        self._populate_standards_tree(auth_filter, cat_filter)

    def _search_standards(self):
        self.tabs.setCurrentIndex(
            next(i for i in range(self.tabs.count())
                 if self.tabs.tabText(i) == "标准库")
        )
        self.std_search_input.setFocus()

    def _show_cross_reference(self):
        if not self.standards:
            return
        xref_path = self.standards.base_dir / "cross_reference.md"
        if xref_path.exists():
            content = xref_path.read_text(encoding="utf-8")
            html = f'''
            <div style="font-family:Microsoft YaHei; color:#c9d1d9; padding:12px;">
            <pre style="white-space:pre-wrap; font-size:13px;">{content}</pre>
            </div>'''

            self.tabs.setCurrentIndex(
                next(i for i in range(self.tabs.count())
                     if self.tabs.tabText(i) == "标准库")
            )
            self.std_detail.setHtml(html)

    def _open_standards_folder(self):
        if self.standards:
            folder = str(self.standards.base_dir)
            import subprocess
            subprocess.Popen(["explorer", folder])

    # ================================================================
    #  主题颜色自定义编辑器
    # ================================================================

    def _open_theme_editor(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("自定义主题颜色")
        dlg.setMinimumSize(520, 420)
        dlg.setStyleSheet(self.styleSheet())

        layout = QVBoxLayout(dlg)
        hint = QLabel("点击色块选取颜色，实时预览效果。")
        hint.setStyleSheet("color:#8b949e; font-size:12px; padding:4px;")
        layout.addWidget(hint)

        grid = QGridLayout()
        grid.setSpacing(10)

        labels_map = {
            "bg":     "主背景色",
            "panel":  "面板/侧栏色",
            "border": "边框/分隔线",
            "text":   "正文字体色",
            "accent": "强调/高亮色",
            "dim":    "次要文字色",
        }

        theme = dict(self._current_theme)
        color_btns = {}

        def make_picker(key):
            def on_click():
                c = QColorDialog.getColor(
                    QColor(theme[key]), dlg, f"选择 {labels_map[key]}")
                if c.isValid():
                    theme[key] = c.name()
                    color_btns[key].setStyleSheet(
                        f"background-color:{c.name()}; border:2px solid #fff;"
                        f" border-radius:4px; min-width:60px; min-height:30px;")
                    self._apply_theme(dict(theme))
            return on_click

        for row, (key, label_zh) in enumerate(labels_map.items()):
            lbl = QLabel(label_zh)
            lbl.setStyleSheet("font-size:14px; font-weight:bold; background:transparent;")
            grid.addWidget(lbl, row, 0)

            hex_lbl = QLabel(theme.get(key, "#000000"))
            hex_lbl.setObjectName(f"hex_{key}")
            hex_lbl.setStyleSheet("font-size:12px; color:#8b949e; font-family:Consolas;"
                                  " background:transparent;")
            grid.addWidget(hex_lbl, row, 1)

            btn = QPushButton()
            btn.setFixedSize(60, 30)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet(
                f"background-color:{theme.get(key,'#000')}; border:2px solid #555;"
                f" border-radius:4px;")
            btn.clicked.connect(make_picker(key))
            color_btns[key] = btn
            grid.addWidget(btn, row, 2)

        layout.addLayout(grid)
        layout.addStretch()

        preset_lbl = QLabel("快速应用预设:")
        preset_lbl.setStyleSheet("font-size:12px; color:#8b949e; background:transparent;")
        layout.addWidget(preset_lbl)

        preset_row = QHBoxLayout()
        for name, vals in THEME_PRESETS.items():
            pbtn = QPushButton(name.split("(")[0].strip())
            pbtn.setFixedHeight(28)
            pbtn.setStyleSheet(
                f"background-color:{vals['bg']}; color:{vals['text']};"
                f" border:1px solid {vals['accent']}; border-radius:4px;"
                f" font-size:11px; padding:2px 8px;")
            def apply_preset(v=vals):
                for k in labels_map:
                    theme[k] = v[k]
                    color_btns[k].setStyleSheet(
                        f"background-color:{v[k]}; border:2px solid #fff;"
                        f" border-radius:4px; min-width:60px; min-height:30px;")
                self._apply_theme(dict(theme))
            pbtn.clicked.connect(apply_preset)
            preset_row.addWidget(pbtn)
        layout.addLayout(preset_row)

        btn_box = QDialogButtonBox(QDialogButtonBox.Close)
        btn_box.rejected.connect(dlg.close)
        btn_box.setStyleSheet(
            "QPushButton{padding:6px 20px; font-size:13px;}")
        layout.addWidget(btn_box)

        dlg.exec_()
