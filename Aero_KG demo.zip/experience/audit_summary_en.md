# Cross-Program Experience Audit Summary

> Generated: 2026-04-17 07:47
> Programs: 1
> Total Entries: 3

---

## Cross-Program (Global)

| Metric | Value |
|--------|-------|
| Permanent | 2 |
| Temporary | 1 |
| Approved | 0 |
| Pending | 3 |

### Permanent Lessons Summary
- [Verification & Testing] Requirement-Driven Design and Verification (85%, used 15x)
- [Requirements Traceability] 软件与硬件需求的一致性分配 (85%, used 15x)
