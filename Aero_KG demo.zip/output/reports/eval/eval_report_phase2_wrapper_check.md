# Evaluation Report (phase2_wrapper_check)

- Mode: `current`
- Benchmark size: `50`
- Recall@10: `0.82`
- MRR: `0.629`
- Citation precision: `0.4`
- Retrieval errors: `9`
- Generation errors: `16`
- Mean latency (ms): `32.65`
- P90 latency (ms): `39.38`
