# Evaluation Report (phase2_baseline)

- Mode: `current`
- Benchmark size: `50`
- Recall@10: `0.82`
- MRR: `0.629`
- Citation precision: `0.4`
- Retrieval errors: `9`
- Generation errors: `16`
- Mean latency (ms): `22.44`
- P90 latency (ms): `24.4`
