# Evaluation Report (ci_service)

- Mode: `service`
- Benchmark size: `50`
- Recall@10: `1.0`
- MRR: `0.9192`
- Citation precision: `0.96`
- Retrieval errors: `0`
- Generation errors: `0`
- Mean latency (ms): `596.57`
- P90 latency (ms): `714.64`
