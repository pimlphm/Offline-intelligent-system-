# Evaluation Report (phase4_agentic_all)

- Mode: `agentic`
- Benchmark size: `50`
- Recall@10: `1.0`
- MRR: `0.9192`
- Citation precision: `0.96`
- Retrieval errors: `0`
- Generation errors: `0`
- Mean latency (ms): `614.69`
- P90 latency (ms): `764.47`
- Agentic requests: `34`
- Agentic usage rate: `0.68`
- Self-check mean: `1.0`
