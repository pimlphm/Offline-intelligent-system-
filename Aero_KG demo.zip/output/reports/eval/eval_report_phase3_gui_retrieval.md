# Evaluation Report (phase3_gui_retrieval)

- Mode: `service`
- Benchmark size: `50`
- Recall@10: `1.0`
- MRR: `0.9192`
- Citation precision: `0.96`
- Retrieval errors: `0`
- Generation errors: `0`
- Mean latency (ms): `692.78`
- P90 latency (ms): `711.76`
