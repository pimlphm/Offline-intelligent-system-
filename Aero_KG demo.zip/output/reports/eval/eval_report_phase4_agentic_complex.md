# Evaluation Report (phase4_agentic_complex)

- Mode: `agentic`
- Benchmark size: `20`
- Recall@10: `1.0`
- MRR: `0.95`
- Citation precision: `0.9`
- Retrieval errors: `0`
- Generation errors: `0`
- Mean latency (ms): `705.03`
- P90 latency (ms): `999.68`
- Agentic requests: `20`
- Agentic usage rate: `1.0`
- Self-check mean: `1.0`
