# Evaluation Report (phase3_service_bootstrap)

- Mode: `service`
- Benchmark size: `50`
- Recall@10: `0.84`
- MRR: `0.6247`
- Citation precision: `0.59`
- Retrieval errors: `8`
- Generation errors: `6`
- Mean latency (ms): `23108.1`
- P90 latency (ms): `35404.44`
