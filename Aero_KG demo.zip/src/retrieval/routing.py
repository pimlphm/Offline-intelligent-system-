from __future__ import annotations

from dataclasses import asdict, dataclass


COMPLEX_MARKERS = {
    "compare",
    "difference",
    "timeline",
    "why",
    "root cause",
    "multi-hop",
    "contrast",
    "which files together",
    "对比",
    "原因",
    "多跳",
    "时间线",
}


@dataclass
class RouteDecision:
    mode: str
    complexity: str
    use_agentic: bool
    use_graph: bool
    reason: str

    def to_dict(self) -> dict:
        return asdict(self)


class QueryRouter:
    def __init__(self, config: dict) -> None:
        flags = config.get("feature_flags", {})
        self.agentic_enabled = bool(flags.get("ENABLE_AGENTIC", False))
        self.graph_enabled = bool(flags.get("ENABLE_GRAPH_LAYER", False))

    def route(self, query: str) -> RouteDecision:
        lowered = query.lower()
        complex_hit = any(marker in lowered for marker in COMPLEX_MARKERS)
        long_query = len(query.split()) >= 18 or len(query) >= 80
        complexity = "complex" if complex_hit or long_query else "simple"
        use_agentic = self.agentic_enabled and complexity == "complex"
        use_graph = self.graph_enabled and ("entity" in lowered or "ontology" in lowered or "graph" in lowered)
        reason = "complexity markers detected" if complexity == "complex" else "baseline retrieval is sufficient"
        mode = "agentic" if use_agentic else "baseline"
        return RouteDecision(mode=mode, complexity=complexity, use_agentic=use_agentic, use_graph=use_graph, reason=reason)
