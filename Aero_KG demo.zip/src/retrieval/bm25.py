from __future__ import annotations

import math
import re
from collections import Counter


def tokenize(text: str) -> list[str]:
    lowered = text.lower()
    cjk = re.findall(r"[\u4e00-\u9fff\u3400-\u4dbf]+", lowered)
    cjk_tokens: list[str] = []
    for segment in cjk:
        cjk_tokens.extend(list(segment))
        cjk_tokens.extend(segment[i : i + 2] for i in range(len(segment) - 1))
    preserved_tokens = re.findall(r"[a-z0-9][\w\-.]*[a-z0-9]|[a-z0-9]", lowered)
    split_text = re.sub(r"[_./\\-]+", " ", lowered)
    split_tokens = re.findall(r"[a-z0-9]+", split_text)
    return preserved_tokens + split_tokens + cjk_tokens


def metadata_text(chunk: dict) -> str:
    metadata = chunk.get("metadata", {}) or {}
    values: list[str] = [
        chunk.get("chunk_id", ""),
        chunk.get("source", ""),
        metadata.get("doc_name", ""),
        metadata.get("doc_id", ""),
        metadata.get("path", ""),
        " ".join(chunk.get("entities", []) or []),
        " ".join(chunk.get("conditions", []) or []),
    ]
    doc_name = metadata.get("doc_name") or chunk.get("source", "")
    if doc_name:
        stem = re.sub(r"\.[a-z0-9]+$", "", str(doc_name).lower())
        values.append(stem.replace("_", " ").replace("-", " "))
    return " ".join(str(value) for value in values if value)


class BM25Retriever:
    def __init__(self) -> None:
        self.chunks: list[dict] = []
        self.df: Counter[str] = Counter()

    def build(self, chunks: list[dict]) -> None:
        self.chunks = []
        self.df = Counter()
        for chunk in chunks:
            body_tokens = tokenize(chunk.get("text", ""))
            meta_tokens = tokenize(metadata_text(chunk))
            tokens = body_tokens + meta_tokens * 4
            indexed = dict(chunk)
            indexed["_tokens"] = tokens
            indexed["_tf"] = Counter(tokens)
            self.chunks.append(indexed)
            for token in set(tokens):
                self.df[token] += 1

    def search(self, query: str, top_k: int = 8, min_score: float = 0.0) -> list[dict]:
        query_tokens = tokenize(query)
        if not query_tokens or not self.chunks:
            return []

        total = len(self.chunks)
        avg_dl = sum(len(item["_tokens"]) for item in self.chunks) / max(total, 1)
        k1, b = 1.5, 0.75
        results = []

        for chunk in self.chunks:
            score = 0.0
            dl = len(chunk["_tokens"])
            for token in query_tokens:
                tf = chunk["_tf"].get(token, 0)
                df = self.df.get(token, 0)
                if tf == 0 or df == 0:
                    continue
                idf = math.log((total - df + 0.5) / (df + 0.5) + 1.0)
                tf_norm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / max(avg_dl, 1)))
                score += idf * tf_norm
            if score >= min_score:
                results.append(self._format_result(chunk, score))

        results.sort(key=lambda item: item["sparse_score"], reverse=True)
        return results[:top_k]

    def _format_result(self, chunk: dict, score: float) -> dict:
        return {
            "chunk_id": chunk["chunk_id"],
            "chunk_type": chunk.get("chunk_type", "evidence"),
            "doc_name": chunk.get("metadata", {}).get("doc_name", chunk.get("source", "")),
            "source": chunk.get("source", ""),
            "text": chunk.get("text", ""),
            "metadata": chunk.get("metadata", {}),
            "entities": chunk.get("entities", []),
            "conditions": chunk.get("conditions", []),
            "sparse_score": round(score, 6),
            "score": round(score, 6),
        }
