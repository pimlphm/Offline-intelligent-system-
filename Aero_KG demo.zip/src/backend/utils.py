from __future__ import annotations

from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[2]


def load_config(path: Path | None = None) -> dict:
    config_path = path or (ROOT / "config.yaml")
    return yaml.safe_load(config_path.read_text(encoding="utf-8"))


def resolve_repo_path(value: str | Path) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    return (ROOT / path).resolve()


def ensure_dir(path: str | Path) -> Path:
    resolved = resolve_repo_path(path)
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def list_demo_documents() -> list[str]:
    docs = []
    for pattern in ("docs/demo_airbus/*.md", "docs/demo_boeing/*.md"):
        docs.extend(str(path) for path in sorted(ROOT.glob(pattern)))
    return docs
