from __future__ import annotations

from typing import List, Optional
from pathlib import Path

from src.backend.service import KnowledgeBaseService
from src.backend.utils import load_config


try:  # pragma: no cover - optional dependency during bootstrap
    from fastapi import FastAPI, File, Form, HTTPException, UploadFile
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import RedirectResponse
    from fastapi.staticfiles import StaticFiles
    from pydantic import BaseModel, Field
except ImportError:  # pragma: no cover - handled gracefully at runtime
    FastAPI = None
    File = None
    Form = None
    HTTPException = RuntimeError
    UploadFile = object
    CORSMiddleware = None
    RedirectResponse = None
    StaticFiles = None
    BaseModel = object
    Field = lambda default=None, **_: default


ROOT = Path(__file__).resolve().parents[2]
WEB_DIR = ROOT / "web"


class InlineDocument(BaseModel):
    name: str
    content: str


class IngestRequest(BaseModel):
    paths: List[str] = Field(default_factory=list)
    documents: List[InlineDocument] = Field(default_factory=list)


class RetrieveRequest(BaseModel):
    query: str
    top_k: int = 8


class GenerateRequest(BaseModel):
    query: str
    top_k: int = 8


def create_app() -> "FastAPI":
    if FastAPI is None:
        raise RuntimeError("FastAPI is not installed. Install requirements.txt to run the backend API.")

    config = load_config()
    service = KnowledgeBaseService(config)
    app = FastAPI(title="Knowledge RAG Service", version="0.1.0")

    if config.get("api", {}).get("enable_cors", True):
        app.add_middleware(
            CORSMiddleware,
            allow_origins=config.get("api", {}).get("allowed_origins", ["*"]),
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    if WEB_DIR.exists():
        app.mount("/ui", StaticFiles(directory=str(WEB_DIR), html=True), name="ui")
    wiki_dir = service.config.get("storage", {}).get("wiki_dir", "./knowledge/wiki")
    wiki_path = Path(wiki_dir)
    if not wiki_path.is_absolute():
        wiki_path = ROOT / wiki_path
    if wiki_path.exists():
        app.mount("/wiki", StaticFiles(directory=str(wiki_path), html=False), name="wiki")

    @app.get("/")
    def root_redirect():
        return RedirectResponse(url="/ui/") if WEB_DIR.exists() else {"service": "Knowledge RAG Service"}

    @app.get("/health")
    def health() -> dict:
        return {
            "status": "ok",
            "backend": config.get("backend", "ollama"),
            "ollama_available": service.provider.check_connection(),
            "indexed_chunk_count": service._indexed_chunk_count,
        }

    @app.post("/ingest")
    def ingest(request: IngestRequest) -> dict:
        if not request.paths and not request.documents:
            raise HTTPException(status_code=400, detail="Provide either document paths or inline documents.")
        summary = {"documents_processed": 0, "chunks_written": 0, "wiki_pages_written": 0}
        if request.paths:
            result = service.ingest_paths(request.paths)
            for key, value in result.items():
                summary[key] += value
        if request.documents:
            payloads = [{"name": item.name, "content": item.content} for item in request.documents]
            result = service.ingest_documents(payloads)
            for key, value in result.items():
                summary[key] += value
        return summary

    @app.post("/upload")
    def upload(files: List[UploadFile] = File(...)) -> dict:
        saved_paths: list[str] = []
        for upload_file in files:
            target = _unique_upload_target(service.raw_dir, upload_file.filename or "upload.bin")
            target.write_bytes(upload_file.file.read())
            saved_paths.append(str(target))

        summary = service.ingest_paths(saved_paths)
        summary["files_saved"] = saved_paths
        return summary

    @app.post("/upload/chunk")
    def upload_chunk(
        file_id: str = Form(...),
        filename: str = Form(...),
        chunk_index: int = Form(...),
        total_chunks: int = Form(...),
        chunk: UploadFile = File(...),
    ) -> dict:
        safe_file_id = Path(file_id).name.replace(".", "_")
        chunk_dir = service.raw_dir / ".upload_chunks" / safe_file_id
        chunk_dir.mkdir(parents=True, exist_ok=True)
        (chunk_dir / f"{chunk_index:06d}.part").write_bytes(chunk.file.read())

        expected = [chunk_dir / f"{idx:06d}.part" for idx in range(total_chunks)]
        if not all(path.exists() for path in expected):
            return {"complete": False, "received_chunk": chunk_index, "total_chunks": total_chunks}

        target = _unique_upload_target(service.raw_dir, filename)
        with target.open("wb") as output:
            for part in expected:
                output.write(part.read_bytes())
                part.unlink()
        chunk_dir.rmdir()

        summary = service.ingest_paths([str(target)])
        summary["complete"] = True
        summary["files_saved"] = [str(target)]
        return summary

    @app.post("/retrieve")
    def retrieve(request: RetrieveRequest) -> dict:
        return service.retrieve(request.query, top_k=request.top_k)

    @app.post("/generate")
    def generate(request: GenerateRequest) -> dict:
        return service.generate(request.query, top_k=request.top_k)

    @app.get("/tree")
    def tree() -> dict:
        return service.get_knowledge_tree()

    return app


app = create_app() if FastAPI is not None else None


def _unique_upload_target(raw_dir: Path, filename: str) -> Path:
    safe_name = Path(filename).name
    target = raw_dir / safe_name
    if not target.exists():
        return target
    suffix = target.suffix
    stem = target.stem
    counter = 2
    while target.exists():
        target = raw_dir / f"{stem}_{counter}{suffix}"
        counter += 1
    return target
