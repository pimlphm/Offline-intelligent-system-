from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

from knowledge.ingestion.ingest_pipeline import IngestPipeline
from src.backend.providers.ollama import OllamaProvider
from src.backend.utils import ensure_dir, list_demo_documents, load_config
from src.generation.generator import EvidenceGroundedGenerator
from src.retrieval.hybrid import HybridRetriever
from src.retrieval.routing import QueryRouter


class KnowledgeBaseService:
    def __init__(self, config: dict | None = None) -> None:
        self.config = config or load_config()
        self.provider = OllamaProvider(self.config)
        retrieval_cfg = self.config.get("retrieval", {})
        flags = self.config.get("feature_flags", {})
        self.flags = flags

        self.chunk_dir = ensure_dir(self.config.get("storage", {}).get("chunk_dir", "./knowledge/chunks"))
        self.raw_dir = ensure_dir(self.config.get("storage", {}).get("raw_dir", "./data/raw"))
        self.processed_dir = ensure_dir(self.config.get("storage", {}).get("processed_dir", "./data/processed"))

        self.pipeline = IngestPipeline(self.config)
        self.router = QueryRouter(self.config)
        self.retriever = HybridRetriever(
            provider=self.provider,
            dense_weight=retrieval_cfg.get("dense_weight", 0.45),
            sparse_weight=retrieval_cfg.get("sparse_weight", 0.55),
            dense_dim=retrieval_cfg.get("dense_embedding_dim", 128),
            dense_enabled=bool(flags.get("ENABLE_DENSE_RETRIEVAL", False) or flags.get("ENABLE_HYBRID_RETRIEVAL", False)),
            reranker_enabled=bool(flags.get("ENABLE_RERANKER", False) or flags.get("ENABLE_HYBRID_RETRIEVAL", False)),
        )
        self.generator = EvidenceGroundedGenerator(provider=self.provider, config=self.config)
        self._indexed_chunk_count = 0
        self._provider_available = self.provider.check_connection()
        self.refresh_indexes_from_disk()

    def has_chunks(self) -> bool:
        return any(self.chunk_dir.glob("*.json"))

    def ingest_paths(self, paths: list[str]) -> dict:
        summary = self.pipeline.ingest_paths(paths)
        self.refresh_indexes_from_disk()
        return summary

    def ingest_documents(self, documents: list[dict]) -> dict:
        prepared = []
        for item in documents:
            prepared.append(
                {
                    "name": item["name"],
                    "path": item.get("path", item["name"]),
                    "ext": Path(item["name"]).suffix.lower() or ".txt",
                    "content": item.get("content", ""),
                    "size_kb": round(len(item.get("content", "").encode("utf-8")) / 1024, 2),
                }
            )
        summary = self.pipeline.ingest_document_payloads(prepared)
        self.refresh_indexes_from_disk()
        return summary

    def refresh_indexes_from_disk(self) -> None:
        chunks = []
        for path in sorted(self.chunk_dir.glob("*.json")):
            try:
                chunks.append(json.loads(path.read_text(encoding="utf-8")))
            except json.JSONDecodeError:
                continue
        self._indexed_chunk_count = len(chunks)
        self.retriever.build(chunks)

    def get_knowledge_tree(self) -> dict:
        documents: dict[str, dict] = {}
        type_nodes: dict[tuple[str, str], dict] = {}
        entity_counts: dict[tuple[str, str, str], int] = defaultdict(int)

        for path in sorted(self.chunk_dir.glob("*.json")):
            try:
                chunk = json.loads(path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                continue

            metadata = chunk.get("metadata", {}) or {}
            doc_name = metadata.get("doc_name") or chunk.get("source") or "Unknown document"
            stem = Path(doc_name).stem
            doc_node = documents.setdefault(
                doc_name,
                {
                    "name": doc_name,
                    "kind": "document",
                    "chunk_count": 0,
                    "wiki_url": f"/wiki/{stem}.md",
                    "children": [],
                },
            )
            doc_node["chunk_count"] += 1

            chunk_type = chunk.get("chunk_type", "evidence")
            type_key = (doc_name, chunk_type)
            type_node = type_nodes.get(type_key)
            if type_node is None:
                type_node = {
                    "name": chunk_type,
                    "kind": "chunk_type",
                    "chunk_count": 0,
                    "children": [],
                }
                type_nodes[type_key] = type_node
                doc_node["children"].append(type_node)
            type_node["chunk_count"] += 1

            entities = chunk.get("entities") or ["unlabeled"]
            for entity in entities[:6]:
                entity_counts[(doc_name, chunk_type, entity)] += 1

            preview = chunk.get("text", "").replace("\n", " ")[:180]
            type_node["children"].append(
                {
                    "name": chunk.get("chunk_id", path.stem),
                    "kind": "chunk",
                    "chunk_type": chunk_type,
                    "source": chunk.get("source", ""),
                    "preview": preview,
                    "entities": chunk.get("entities", []),
                }
            )

        for (doc_name, chunk_type, entity), count in entity_counts.items():
            type_node = type_nodes[(doc_name, chunk_type)]
            type_node["children"].insert(
                0,
                {
                    "name": entity,
                    "kind": "entity",
                    "chunk_count": count,
                },
            )

        return {
            "name": "Knowledge Base",
            "kind": "root",
            "document_count": len(documents),
            "chunk_count": sum(node["chunk_count"] for node in documents.values()),
            "children": sorted(documents.values(), key=lambda item: item["name"]),
        }

    def refresh_provider_status(self) -> bool:
        self._provider_available = self.provider.check_connection()
        return self._provider_available

    def retrieve(self, query: str, top_k: int | None = None) -> dict:
        if not self.has_chunks():
            demo_docs = list_demo_documents()
            if demo_docs:
                self.ingest_paths(demo_docs)

        top_k = top_k or self.config.get("retrieval", {}).get("top_k", 8)
        route = self.router.route(query)
        results = self.retriever.search(
            query,
            top_k=top_k,
            rerank_top_n=self.config.get("retrieval", {}).get("rerank_top_n", 12),
            min_score=self.config.get("retrieval", {}).get("min_score", 0.0),
        )
        return {
            "query": query,
            "route": route.to_dict(),
            "retrieval_results": results,
            "indexed_chunk_count": self._indexed_chunk_count,
        }

    def generate(self, query: str, top_k: int | None = None, use_llm: bool | None = None) -> dict:
        route = self.router.route(query)
        if route.use_agentic:
            from src.agentic.agentic_retrieval import AgenticRetrievalEngine

            result = AgenticRetrievalEngine(self).run(
                query,
                max_steps=self.config.get("agentic", {}).get("max_steps", 3),
            )
            result["route"] = route.to_dict()
            result["llm_used"] = False
            result["agentic_used"] = True
            return result

        retrieval = self.retrieve(query, top_k=top_k)
        llm_allowed = self._provider_available if use_llm is None else bool(use_llm and self._provider_available)
        generated = self.generator.generate(query, retrieval["retrieval_results"], use_llm=llm_allowed)
        retrieval.update(generated)
        retrieval["llm_used"] = llm_allowed
        retrieval["agentic_used"] = False
        return retrieval
