from __future__ import annotations


class EvidenceGroundedGenerator:
    def __init__(self, provider=None, config: dict | None = None) -> None:
        self.provider = provider
        self.config = config or {}

    def generate(self, query: str, retrieval_results: list[dict], use_llm: bool = True) -> dict:
        citations = list(dict.fromkeys(item.get("doc_name", "") for item in retrieval_results if item.get("doc_name")))
        context_blocks = []
        for item in retrieval_results[:3]:
            context_blocks.append(f"[{item.get('doc_name', 'unknown')}]\n{item.get('text', '')[:600]}")
        context = "\n\n---\n\n".join(context_blocks)

        answer = self._fallback_answer(query, retrieval_results, citations)
        if use_llm and self.provider and retrieval_results:
            try:
                prompt = (
                    "Answer only from the provided evidence. "
                    "Cite source filenames inline in square brackets.\n\n"
                    f"Question: {query}\n\nEvidence:\n{context}"
                )
                system = "You are a grounded RAG answerer. Never answer without citing the evidence filenames."
                answer = self.provider.generate(prompt, system=system)
                if citations and not any(citation in answer for citation in citations):
                    answer += "\n\nSources: " + ", ".join(citations)
            except Exception:
                pass

        return {"answer": answer, "citations": citations}

    def _fallback_answer(self, query: str, retrieval_results: list[dict], citations: list[str]) -> str:
        if not retrieval_results:
            return "No evidence was retrieved, so the system cannot answer this question yet."
        top = retrieval_results[0]
        lines = [
            f"Query: {query}",
            f"Primary evidence: {top.get('doc_name', 'unknown')} ({top.get('chunk_type', 'evidence')})",
            top.get("text", "")[:700],
        ]
        if citations:
            lines.append("Sources: " + ", ".join(citations))
        return "\n".join(lines)
