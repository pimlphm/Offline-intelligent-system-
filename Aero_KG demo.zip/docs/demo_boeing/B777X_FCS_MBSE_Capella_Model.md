# B777X 飞行控制系统 MBSE建模报告
## 基于Capella/Arcadia方法论的四层架构设计

**文档编号**: B777X-FCS-MBSE-001  
**版本**: Rev B  
**ATA章节**: ATA 27 - 飞行控制  
**适用型号**: B777-9/8  
**编制单位**: Boeing - Digital Engineering Center  
**工具链**: Capella 6.x + DOORS Next + Cameo

---

## 1. Arcadia方法论应用

B777X飞控系统采用Capella/Arcadia方法论进行基于模型的系统工程(MBSE)：

### 1.1 四层架构概览

| 层级 | Arcadia阶段 | 关注点 | 交付物 |
|------|-------------|--------|--------|
| L1 | 运行分析(OA) | 飞机在运营环境中的使用场景 | 运行场景/活动图 |
| L2 | 系统分析(SA) | 飞控系统的功能需求和行为 | 功能链/模式状态机 |
| L3 | 逻辑架构(LA) | 飞控功能的逻辑分配和接口 | 逻辑组件/数据流 |
| L4 | 物理架构(PA) | 硬件/软件/机械的物理实现 | LRU分配/线缆拓扑 |

---

## 2. L1 运行分析(OA)

### 2.1 运行场景
| 场景编号 | 运行场景 | 参与者 | 飞控系统角色 |
|----------|----------|--------|-------------|
| OA-FCS-01 | 正常起飞滑跑→离地→初始爬升 | 飞行员+ATC+飞机 | 提供操纵响应+包线保护 |
| OA-FCS-02 | 巡航自动驾驶 | 自动飞行系统+飞机 | 姿态保持+气动配平 |
| OA-FCS-03 | 进近着陆(CAT III自动着陆) | 飞行员+ILS+飞机 | 精密引导+自动着陆 |
| OA-FCS-04 | 发动机失效(单发) | 飞行员+飞机 | 自动不对称补偿 |
| OA-FCS-05 | 极端天气(严重湍流) | 飞行员+飞机 | 载荷减缓+阵风抑制 |
| OA-FCS-06 | 系统降级(液压失效) | 飞行员+飞机 | 切换到EHA/EBHA驱动 |

### 2.2 运行需求
| 需求编号 | 运行需求 | 来源场景 |
|----------|----------|----------|
| OR-FCS-001 | 飞控系统应在所有飞行阶段提供可预测的操纵特性 | OA-FCS-01~06 |
| OR-FCS-002 | 飞控系统应在任何单一失效后保持安全飞行能力 | OA-FCS-04,06 |
| OR-FCS-003 | 飞控系统应支持CAT IIIB自动着陆(DH=0ft) | OA-FCS-03 |
| OR-FCS-004 | 飞控系统应在严重湍流中保护结构载荷 | OA-FCS-05 |

---

## 3. L2 系统分析(SA)

### 3.1 系统功能分解
```
SF-FCS: 飞行控制系统功能
├── SF-FCS-PRI: 主飞行控制
│   ├── SF-PITCH: 俯仰控制
│   │   ├── SF-PITCH-CMD: 驾驶杆指令处理
│   │   ├── SF-PITCH-LAW: 控制律计算
│   │   ├── SF-PITCH-ACT: 升降舵驱动
│   │   └── SF-PITCH-TRIM: 安定面配平
│   ├── SF-ROLL: 滚转控制
│   │   ├── SF-ROLL-CMD: 驾驶盘指令处理
│   │   ├── SF-ROLL-LAW: 副翼/扰流板分配
│   │   └── SF-ROLL-ACT: 副翼/扰流板驱动
│   └── SF-YAW: 偏航控制
│       ├── SF-YAW-CMD: 方向舵脚蹬处理
│       ├── SF-YAW-DAMP: 偏航阻尼
│       └── SF-YAW-ACT: 方向舵驱动
├── SF-FCS-SEC: 二级飞行控制
│   ├── SF-FLAP: 襟翼控制
│   ├── SF-SLAT: 缝翼控制
│   └── SF-SPDBRK: 减速板控制
├── SF-FCS-PROT: 包线保护
│   ├── SF-AOA-PROT: 迎角保护
│   ├── SF-SPD-PROT: 速度保护
│   ├── SF-LOAD-PROT: 载荷保护
│   └── SF-GLA: 阵风载荷减缓
└── SF-FCS-MON: 系统监控与切换
    ├── SF-RECONFIG: 余度管理/重构
    ├── SF-BITE: 机内自检测
    └── SF-MAINT: 维护接口
```

### 3.2 功能链(Functional Chain)
**FC-PITCH-NORMAL**: 正常俯仰控制链
```
[驾驶杆位置] → SF-PITCH-CMD → [俯仰指令] → SF-PITCH-LAW → [升降舵偏转指令] → SF-PITCH-ACT → [升降舵偏转]
                                    ↑                              ↑
                              [空速/迎角/姿态]               [SF-AOA-PROT限幅]
                                  来自ADC                      来自保护功能
```

### 3.3 系统模式状态机
```
             ┌──────────┐
             │  地面待命  │ ←─── 上电启动
             └────┬─────┘
                  │ 起飞构型确认
                  ↓
             ┌──────────┐     ELAC失效      ┌──────────┐
             │ Normal Law│ ──────────────→  │Alternate │
             │  正常法则  │                   │  备选法则  │
             └────┬─────┘                   └────┬─────┘
                  │ 双ELAC失效                    │ SEC失效
                  ↓                               ↓
             ┌──────────┐     全电失效      ┌──────────┐
             │Direct Law │ ──────────────→  │Mechanical│
             │  直接法则  │                   │  机械备份  │
             └──────────┘                   └──────────┘
```

---

## 4. L3 逻辑架构(LA)

### 4.1 逻辑组件
| 逻辑组件 | 功能分配 | 接口 |
|----------|----------|------|
| LC-PFC: 主飞控计算 | SF-PITCH-LAW, SF-ROLL-LAW, SF-YAW-DAMP | 双冗余, ARINC 664 |
| LC-ACE: 作动器控制 | SF-*-ACT (所有作动器驱动) | 四冗余 |
| LC-SFCC: 缝翼襟翼控制 | SF-FLAP, SF-SLAT | 双冗余 |
| LC-PROT: 保护计算 | SF-AOA-PROT, SF-SPD-PROT, SF-LOAD-PROT | 异构冗余 |
| LC-RECONF: 余度管理 | SF-RECONFIG | 独立监控 |

### 4.2 逻辑接口定义(ICD)
| 接口 | 源组件 | 目标组件 | 数据 | 速率 | 协议 |
|------|--------|----------|------|------|------|
| IF-01 | LC-PFC | LC-ACE | 舵面指令 | 50Hz | ARINC 664 |
| IF-02 | ADC | LC-PFC | 空速/迎角/高度 | 50Hz | ARINC 429 |
| IF-03 | IRS | LC-PFC | 姿态/角速率 | 50Hz | ARINC 429 |
| IF-04 | LC-PFC | LC-PROT | 飞行状态 | 50Hz | ARINC 664 |
| IF-05 | LC-PROT | LC-PFC | 保护指令 | 50Hz | ARINC 664 |
| IF-06 | 操纵装置 | LC-PFC | 驾驶杆/脚蹬 | 50Hz | LVDT/RVDT |

---

## 5. L4 物理架构(PA)

### 5.1 LRU到逻辑组件映射
| LRU (件号) | 逻辑组件 | 安装位置 | DAL | 供应商 |
|-----------|----------|----------|-----|--------|
| PFC-1 (P/N 777-FC-001) | LC-PFC (通道1) | E&E舱 机架1 | A | Collins |
| PFC-2 (P/N 777-FC-002) | LC-PFC (通道2) | E&E舱 机架2 | A | Collins |
| ACE-1~4 | LC-ACE (4通道) | 分布式 翼根/尾部 | A | Moog |
| SFCC-1/2 | LC-SFCC | E&E舱 | B | Parker |
| FCMC (P/N 777-FC-010) | LC-RECONF | E&E舱 | A | Boeing |

### 5.2 作动器分配
| 舵面 | 作动器类型 | 液压源 | 备用 |
|------|-----------|--------|------|
| 升降舵(内) | EHA | 电动液压 | 气动锁定 |
| 升降舵(外) | EBHA | 液压+电动 | 电动备份 |
| 副翼(内) | SHA | 液压1 | 液压2 |
| 副翼(外) | EBHA | 液压2 | 电动备份 |
| 方向舵(上) | SHA | 液压1 | 液压3 |
| 方向舵(下) | SHA | 液压2 | 液压3 |
| 安定面 | 电动+液压 | 双电机+液压 | 三冗余 |

---

## 6. 追溯矩阵: OA→SA→LA→PA

```
运行场景 OA-FCS-03 (CAT III自动着陆)
  └── 运行需求 OR-FCS-003
      └── 系统功能 SF-PITCH-LAW + SF-ROLL-LAW + SF-PROT
          └── 逻辑组件 LC-PFC + LC-PROT
              └── 物理LRU: PFC-1/2 (DAL A) + FCMC (DAL A)
                  └── 软件 HLR-PFC-CAT3-001 ~ HLR-PFC-CAT3-015
                      └── 测试 TC-FCS-CATIII-001 ~ TC-FCS-CATIII-025

运行场景 OA-FCS-05 (严重湍流)
  └── 运行需求 OR-FCS-004
      └── 系统功能 SF-GLA (阵风载荷减缓)
          └── 逻辑组件 LC-PFC + LC-ACE
              └── 物理LRU: PFC-1/2 + ACE-1~4
                  └── 软件 HLR-GLA-001 ~ HLR-GLA-008
                      └── 测试 TC-GLA-001 ~ TC-GLA-012
                          └── 结构载荷验证: DTS-GLA-001 (飞行试验数据)
```
