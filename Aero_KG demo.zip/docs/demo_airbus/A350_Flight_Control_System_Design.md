# Airbus A350 XWB - 飞行控制系统设计文档 (公开资料整理)

**文档编号**: A350-FCS-DD-001  
**版本**: Issue 4  
**日期**: 2026-02-20  
**分类**: 系统设计描述 (System Design Description)  
**参考标准**: ARP4754A, DO-178C, DO-254, EUROCAE ED-12C

---

## 1. 系统架构概述

A350 XWB飞行控制系统采用全数字电传飞控(Fly-By-Wire, FBW)架构，继承并优化了A380的设计经验。

### 1.1 架构特征
- **三余度飞行控制计算机**: 3台FCPC (Flight Control Primary Computer)
- **双余度备份**: 2台FCSC (Flight Control Secondary Computer)
- **异构冗余**: FCPC和FCSC采用不同处理器架构和不同供应商
- **通讯总线**: AFDX (Avionics Full-Duplex Switched Ethernet)

## 2. 系统需求

### REQ-FCS-001: 正常控制律
- **描述**: 正常法则下，系统应提供C*控制律，飞行员输入与飞机响应之间满足特性时间常数<1.5s
- **优先级**: Critical
- **DAL等级**: DAL A
- **依据**: CS 25.143 Controllability and Manoeuvrability

### REQ-FCS-002: 飞行包线保护
- **描述**: 系统应提供以下保护功能：
  - 迎角保护 (Alpha Protection)
  - 过载保护 (Load Factor Protection): -1g ~ +2.5g
  - 俯仰姿态保护 (Pitch Attitude Protection)
  - 坡度保护 (Bank Angle Protection): ±67°
  - 速度保护 (High/Low Speed Protection)
- **优先级**: Critical
- **DAL等级**: DAL A

### REQ-FCS-003: 故障降级
- **描述**: 系统应支持以下降级模式:
  1. 正常法则 (Normal Law) → 备用法则 (Alternate Law) → 直接法则 (Direct Law)
  2. 任何单一故障不应导致从正常法则直接降级到直接法则
- **优先级**: Critical
- **DAL等级**: DAL A
- **安全要求**: 极度危险故障概率 < 10⁻⁹/飞行小时

### REQ-FCS-004: 舵面控制响应
- **描述**: 舵面伺服控制响应时间：
  - 副翼/升降舵: <40ms (指令到运动开始)
  - 方向舵: <60ms
  - 扰流板: <80ms
- **优先级**: High

### REQ-FCS-005: 自动配平
- **描述**: 系统应在正常法则下自动管理飞机配平，无需飞行员手动操作
- **优先级**: High

### REQ-FCS-006: AFDX通讯完整性
- **描述**: 飞行控制数据通讯应满足ARINC 664 Part 7确定性要求，端到端延迟<10ms
- **优先级**: Critical

## 3. 架构设计

### DES-FCS-001: FCPC架构
- **实现需求**: REQ-FCS-001, REQ-FCS-002, REQ-FCS-003
- **设计方案**:
  - 双核锁步处理器 (COM/MON架构)
  - COM通道: 命令计算
  - MON通道: 独立监控
  - 不一致检测与表决逻辑
- **处理器**: PowerPC e500 (来源: 公开信息)
- **实时操作系统**: ARINC 653 分区架构

### DES-FCS-002: 舵面控制电子设备(ACE)
- **实现需求**: REQ-FCS-004
- **设计方案**: 
  - 靠近舵面安装的分布式控制单元
  - 电液伺服阀 + LVDT反馈
  - 双余度控制回路

### DES-FCS-003: AFDX端系统
- **实现需求**: REQ-FCS-006
- **设计方案**:
  - 虚拟链路(VL)带宽分配
  - 冗余交换网络
  - BAG (Bandwidth Allocation Gap) 调度

### DES-FCS-004: 飞行包线保护算法
- **实现需求**: REQ-FCS-002
- **设计方案**:
  - Alpha Protection: 基于AoA传感器多数表决 + 合成AoA
  - Load Factor: 基于加速度计的实时监控
  - Speed Protection: 马赫数/CAS综合保护

## 4. 软件架构 (DO-178C)

### MODULE-FCS-001: 控制律计算模块
- **追溯到设计**: DES-FCS-001
- **语言**: Ada (SPARK子集，支持形式化验证)
- **周期**: 20ms主循环
- **MCDC覆盖率要求**: 100%

### MODULE-FCS-002: 飞行包线保护模块
- **追溯到设计**: DES-FCS-004
- **输入**: AoA, 马赫数, 载荷因子, 姿态角
- **输出**: 保护指令增量

### MODULE-FCS-003: 表决与监控模块
- **追溯到设计**: DES-FCS-001
- **功能**: COM/MON不一致检测，跨通道数据比较

### FUNC-FCS-001: alpha_protection()
- **描述**: 迎角保护核心算法，三传感器中值滤波 + α限制
- **追溯到设计**: DES-FCS-004
- **验证需求**: REQ-FCS-002

### FUNC-FCS-002: control_law_cstar()
- **描述**: C*控制律主函数，混合正常加速度和俯仰角速率反馈
- **追溯到设计**: DES-FCS-001
- **验证需求**: REQ-FCS-001

## 5. 测试策略

### TEST-FCS-001: 铁鸟测试 (Iron Bird)
- **验证需求**: REQ-FCS-001, REQ-FCS-002, REQ-FCS-004
- **方法**: 全尺寸飞控系统集成台架测试
- **覆盖**: 正常/备用/直接法则全工况

### TEST-FCS-002: 故障注入测试
- **验证需求**: REQ-FCS-003
- **方法**: 系统性故障注入，验证降级逻辑
- **覆盖**: 所有FMEA识别的故障模式

### TEST-FCS-003: MC/DC覆盖率验证
- **验证需求**: REQ-SW (所有DAL A软件)
- **方法**: 结构覆盖率分析 + 测试用例补充

---

**适用标准参考**:
- ARP4754A: Development of Civil Aircraft and Systems
- ARP4761: Safety Assessment Process
- DO-178C / ED-12C: Software Considerations
- ARINC 653: Avionics Application Software Standard Interface
- ARINC 664 Part 7: Avionics Full-Duplex Switched Ethernet (AFDX)
- CS 25.143, CS 25.1309: Airworthiness requirements
