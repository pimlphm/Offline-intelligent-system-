# A320neo 电传飞控系统 DO-178C适航认证包
## 需求-设计-代码-测试 完整追溯文档

**文档编号**: A320-FBW-CERT-002  
**版本**: Issue 5  
**ATA章节**: ATA 27 - 飞行控制  
**适用型号**: A320neo/A321neo/A319neo  
**认证基础**: CS 25.1309, CS 25.671, CS 25.672  
**编制单位**: Airbus - Flight Control System Design Authority  
**DAL等级**: **DAL A** (灾难级失效状态)

---

## 1. 系统概述

A320neo电传飞控系统(FBW)由以下计算机组成：
- **ELAC** (Elevator Aileron Computer) × 2
- **SEC** (Spoiler Elevator Computer) × 3  
- **FAC** (Flight Augmentation Computer) × 2

### 1.1 法则降级策略
| 优先级 | 控制法则 | 可用计算机 | 保护功能 |
|--------|----------|-----------|----------|
| 1 | Normal Law正常法则 | ELAC1或ELAC2 | 全包线保护 |
| 2 | Alternate Law备选法则 | SEC1/2/3 | 部分保护 |
| 3 | Direct Law直接法则 | 任一SEC | 无自动保护 |
| 4 | Mechanical Backup机械备份 | 无 | 仅俯仰配平+方向舵 |

---

## 2. 需求层级体系 (DOORS中的层级)

### 2.1 飞机级需求 (来自CS-25条款)
| 需求编号 | 来源条款 | 需求描述 |
|----------|----------|----------|
| AREQ-27-001 | CS 25.671(a) | 飞行控制系统应确保安全飞行和着陆 |
| AREQ-27-002 | CS 25.672(a) | 主飞行控制系统的故障不得导致飞机不可控 |
| AREQ-27-003 | CS 25.672(b) | 任何单一失效不得导致主飞控功能完全丧失 |
| AREQ-27-004 | CS 25.1309(b) | 灾难性失效概率<1×10⁻⁹/fh |

### 2.2 系统级需求 (ARP4754A分解)
| 需求编号 | 上游追溯 | 需求描述 | DAL |
|----------|----------|----------|-----|
| SYSREQ-FBW-001 | AREQ-27-001 | ELAC应提供Normal Law控制 | A |
| SYSREQ-FBW-002 | AREQ-27-003 | 单一ELAC失效后SEC接管为Alternate Law | A |
| SYSREQ-FBW-003 | AREQ-27-002 | ELAC+SEC全部失效后保留机械备份 | A |
| SYSREQ-FBW-010 | AREQ-27-004 | FBW系统完全失效概率<1×10⁻⁹/fh | A |
| SYSREQ-FBW-020 | AREQ-27-001 | Normal Law应提供迎角保护(AOA Protection) | A |
| SYSREQ-FBW-021 | AREQ-27-001 | Normal Law应提供过载保护(Load Factor Limit) | A |
| SYSREQ-FBW-022 | AREQ-27-001 | Normal Law应提供坡度限制(Bank Angle Limit) | B |
| SYSREQ-FBW-023 | AREQ-27-001 | Normal Law应提供俯仰姿态保护 | A |

### 2.3 高层需求HLR (DO-178C)
| 需求编号 | 上游追溯 | 需求描述 | 验证方法 |
|----------|----------|----------|----------|
| HLR-ELAC-001 | SYSREQ-FBW-001 | ELAC应以50Hz采样侧杆输入 | T |
| HLR-ELAC-002 | SYSREQ-FBW-001 | ELAC应在20ms内计算控制指令 | T |
| HLR-ELAC-010 | SYSREQ-FBW-020 | 迎角达到αprot时启动保护 | T |
| HLR-ELAC-011 | SYSREQ-FBW-020 | 迎角达到αmax时输出最大低头指令 | T |
| HLR-ELAC-020 | SYSREQ-FBW-021 | 过载因子限制在-1g~+2.5g (干净构型) | T |
| HLR-ELAC-030 | SYSREQ-FBW-010 | ELAC应每100ms向SEC发送健康状态 | T |
| HLR-ELAC-031 | SYSREQ-FBW-010 | ELAC检测到COM/MON不一致应触发切换 | T |
| HLR-ELAC-040 | SYSREQ-FBW-022 | 坡度限制33°(正常)/67°(全偏杆) | T |
| HLR-ELAC-SAF-001 | SO-FBW-001 | COM/MON双通道交叉比较周期≤20ms | T/A |
| HLR-ELAC-SAF-002 | SO-FBW-002 | 检测到不一致后100ms内切换到备份通道 | T |

### 2.4 低层需求LLR (DO-178C)
| 需求编号 | 上游HLR | 需求描述 |
|----------|---------|----------|
| LLR-ELAC-001.1 | HLR-ELAC-001 | ADC采样定时器配置为50Hz中断 |
| LLR-ELAC-001.2 | HLR-ELAC-001 | 侧杆位置经四阶Butterworth低通滤波 |
| LLR-ELAC-010.1 | HLR-ELAC-010 | AOA保护触发阈值αprot计算公式 |
| LLR-ELAC-010.2 | HLR-ELAC-010 | AOA保护输出为升降舵偏转增量 |
| LLR-ELAC-020.1 | HLR-ELAC-020 | 过载因子PID控制器比例系数Kp |
| LLR-ELAC-020.2 | HLR-ELAC-020 | 过载因子积分器限幅和抗饱和逻辑 |
| LLR-ELAC-031.1 | HLR-ELAC-031 | COM/MON比较容差阈值定义 |
| LLR-ELAC-031.2 | HLR-ELAC-031 | 不一致持续3个周期触发切换 |
| LLR-ELAC-SAF-001.1 | HLR-ELAC-SAF-001 | 心跳报文格式: {seq, timestamp, crc32} |
| LLR-ELAC-SAF-001.2 | HLR-ELAC-SAF-001 | 心跳丢失计数器阈值=5(100ms) |

---

## 3. 软件架构设计

### 3.1 ARINC 653分区
| 分区 | 功能 | DAL | 时间窗口 |
|------|------|-----|----------|
| P1-CONTROL | Normal Law控制律 | A | 20ms主周期 |
| P2-MONITOR | 交叉监控 | A | 20ms |
| P3-IO | ARINC 429收发 | B | 10ms |
| P4-BITE | 自检测 | C | 100ms |

### 3.2 软件组件层级
```
ELAC应用软件 (CSC-ELAC-APP, DAL A)
├── CSC-CTRL: 控制律计算
│   ├── CSU-NLAW: Normal Law模块
│   │   ├── func: aoa_protection_compute()
│   │   ├── func: load_factor_limit()
│   │   ├── func: bank_angle_limit()
│   │   └── func: pitch_attitude_protect()
│   ├── CSU-ALAW: Alternate Law模块
│   └── CSU-DLAW: Direct Law模块
├── CSC-MON: 监控模块
│   ├── CSU-XMON: 交叉比较
│   ├── CSU-VOTE: 表决逻辑
│   └── CSU-SWITCH: 通道切换
├── CSC-IO: 输入输出
│   ├── CSU-ADC: ADC采集
│   ├── CSU-A429: ARINC 429通信
│   └── CSU-DISC: 离散量IO
└── CSC-BITE: 自检测
    ├── CSU-PBIT: 上电自检
    ├── CSU-CBIT: 连续自检
    └── CSU-IBIT: 人工启动自检
```

---

## 4. 验证与确认

### 4.1 测试用例追溯
| 测试编号 | 追溯需求 | 测试类型 | 覆盖要求 |
|----------|----------|----------|----------|
| TC-ELAC-NL-001 | HLR-ELAC-010 | 需求级 | AOA保护功能 |
| TC-ELAC-NL-002 | HLR-ELAC-011 | 需求级 | αmax低头指令 |
| TC-ELAC-NL-003 | HLR-ELAC-020 | 需求级 | 过载保护 |
| TC-ELAC-NL-004 | HLR-ELAC-040 | 需求级 | 坡度限制 |
| TC-ELAC-SAF-001 | HLR-ELAC-SAF-001 | 需求级 | 交叉监控 |
| TC-ELAC-SAF-002 | HLR-ELAC-SAF-002 | 需求级 | 通道切换 |
| TC-ELAC-ROB-001 | LLR-ELAC-031.1 | 鲁棒性 | 异常输入 |
| SC-ELAC-MCDC-001 | CSU-NLAW | 结构覆盖 | MC/DC 100% |
| SC-ELAC-MCDC-002 | CSU-XMON | 结构覆盖 | MC/DC 100% |

### 4.2 覆盖率分析
| 覆盖类型 | 目标 | 实际 | DAL要求 |
|----------|------|------|---------|
| 语句覆盖 | 100% | 99.8% | A,B,C |
| 判定覆盖 | 100% | 99.5% | A,B |
| MC/DC覆盖 | 100% | 99.2% | **仅DAL A** |
| 数据耦合 | 分析完成 | 已完成 | A |
| 控制耦合 | 分析完成 | 已完成 | A |

### 4.3 偏差处理
- SC-ELAC-MCDC-001中0.8%未覆盖: 已提交偏差分析，确认为死代码(编译器生成)，提交DER审查
- 派生需求LLR-ELAC-020.2: 已通过安全评估，非安全性降级

---

## 5. 认证里程碑

| SOI节点 | 计划日期 | 交付物 | 状态 |
|---------|----------|--------|------|
| SOI#1 计划评审 | 2023-Q1 | PSAC, SDP, SVP, SCMP | 已通过 |
| SOI#2 开发评审 | 2023-Q3 | SRS, SDD, 追溯矩阵 | 已通过 |
| SOI#3 验证评审 | 2024-Q1 | STD, STR, 覆盖率报告 | 已通过 |
| SOI#4 认证评审 | 2024-Q2 | SAS, SCI, 符合性矩阵 | **审查中** |

---

## 6. 派生需求清单

| 派生需求 | 来源 | 安全评估 | 状态 |
|----------|------|----------|------|
| LLR-ELAC-020.2 积分器抗饱和 | 设计优化 | 已完成 | 已批准 |
| LLR-ELAC-001.2 滤波器参数 | 信号处理需要 | 已完成 | 已批准 |
| LLR-ELAC-031.2 三周期确认 | 抗干扰设计 | **待完成** | 待审 |
