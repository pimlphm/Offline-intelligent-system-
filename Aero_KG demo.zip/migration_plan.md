# Migration Plan

## Objective

Move from the current desktop-only knowledge assistant to a layered RAG platform without breaking the current user workflow.

## Migration Rules

- Never remove the legacy desktop path until the new API path passes the benchmark.
- Introduce new capabilities behind `feature_flags`.
- Version every index and model transition.
- Record each phase instruction and outcome in `orchestrator_log.json`.

## Phase Sequence

### Phase 0

- Completed.
- Outputs: `as_is_system_audit.md`, `inventory.json`, `output/reports/run_current_report.json`
- Gate result: `PROCEED`

### Phase 1

Add architecture artifacts only.

- Publish target architecture, migration strategy, and risk matrix.
- Do not touch the legacy GUI code path.
- Define service boundaries and rollback points.

Rollback point:

- none needed, documentation-only phase

### Phase 2

Add evaluation assets before major code changes go live.

- create benchmark queries with gold sources and citation requirements
- add an evaluation harness that can execute against the current pipeline
- separate retrieval errors from generation errors in reports

Rollback point:

- if the benchmark schema or runner proves unstable, revert to the Phase 0 smoke path only

### Phase 3

Introduce the baseline RAG 2.0 service path.

- add `src/backend/` API scaffolding
- add `knowledge/ingestion/` structured chunk pipeline
- add `src/retrieval/` sparse + dense + hybrid modules
- keep the desktop app untouched until the API path is validated

Compatibility points:

- reuse `core/doc_parser.py`
- reuse Ollama endpoint settings from `config.yaml`
- preserve current docs corpus under `docs/`

Rollback points:

- switch off `ENABLE_DENSE_RETRIEVAL`, `ENABLE_HYBRID_RETRIEVAL`, `ENABLE_RERANKER`
- point service back to the current lexical-only path

### Phase 4

Introduce agentic retrieval behind `ENABLE_AGENTIC`.

- only enable on complex-query slices
- compare against baseline latency and faithfulness

Rollback point:

- disable `ENABLE_AGENTIC`

### Phase 5

Introduce compiled wiki and graph retrieval behind `ENABLE_COMPILED_KNOWLEDGE` and `ENABLE_GRAPH_LAYER`.

- publish compiled pages and graph outputs
- require benchmark lift before production use

Rollback points:

- disable graph and compiled-knowledge flags
- keep raw retrieval as the serving default

### Phase 6

Harden for production.

- add CI/CD
- add monitoring
- add rollback scripts
- add security approval hooks

Rollback point:

- revert deployment wiring while preserving the service code

## Workstream Map

### Workstream A: Platform

- backend service
- providers
- configuration
- deployment

### Workstream B: Knowledge

- parsing
- segmentation
- chunk persistence
- wiki compilation
- graph outputs

### Workstream C: Retrieval

- sparse retrieval
- dense retrieval
- fusion
- reranking
- routing

### Workstream D: Governance

- orchestrator logs
- versioning
- security approval
- evaluation reports

## Entry Criteria For Each Phase

- deliverables from the previous phase exist
- orchestrator packet has been logged
- known rollback point is documented

## Exit Criteria For Each Phase

- deliverables exist
- acceptance criteria are evaluated
- decision is written as `PROCEED`, `REWAIT`, or `REVERT`

## Near-Term Build Order

1. Architecture package
2. Benchmark + evaluation harness
3. Backend service and ingestion/retrieval baseline
4. Agentic retrieval
5. Compiled knowledge
6. Hardening and production operations
